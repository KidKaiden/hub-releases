// Settings come from environment variables or server/.env. Secrets never live in the code or in git.
import { readFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
export function loadConfig(overrides = {}) {
  const env = { ...process.env };
  const file = resolve(here, '..', '.env');
  if (existsSync(file)) {
    for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*(#.*)?$/);
      if (m && env[m[1]] === undefined) env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  }
  const c = {
    port: Number(env.PORT ?? 8787),
    // Empty = every network (phones on the home Wi-Fi can reach it). 127.0.0.1 = this PC only.
    host: env.HOST || undefined,
    // Folders: relative paths start from the server folder. On the home PC they sit beside the project
    // (HUB\Data, HUB\Backups\Server, HUB\Builds\Windows), so the data never mixes with the code.
    dataDir: resolve(here, '..', env.DATA_DIR || './data'),
    backupDir: env.BACKUP_DIR ? resolve(here, '..', env.BACKUP_DIR) : undefined,
    backupDays: Math.max(1, Number(env.BACKUP_DAYS) || 30),
    // Signed PC app updates (latest.json + installer), made by tools/build-windows.ps1 -Publish
    updatesDir: resolve(here, '..', env.UPDATES_DIR || './updates'),
    // Android APKs; the newest is offered at /phone for the phone to download over Wi-Fi
    phoneDir: env.PHONE_DIR ? resolve(here, '..', env.PHONE_DIR) : undefined,
    // The web Hub (tools/build-web.ps1), opened on iPhones at http://<PC address>:8787/ and added to the Home Screen
    webDir: env.WEB_DIR ? resolve(here, '..', env.WEB_DIR) : undefined,
    // The assistant's Notion Inbox (or set by the owner in Hub > Settings > Assistant). Never in git.
    notion: { token: env.NOTION_TOKEN || '', database: env.NOTION_DATABASE_ID || '' },
    notionBase: env.NOTION_API || undefined,
    // The outside link (Tailscale Funnel -> this port, this PC only), its https address, and its shortest password
    // (6, the same as at home, Kaiden 2026-11-08; the home minimum in Hub > Admin wins when it's higher)
    publicPort: env.PUBLIC_PORT ? Number(env.PUBLIC_PORT) : undefined,
    publicUrl: (env.PUBLIC_URL || '').replace(/\/+$/, ''),
    publicPasswordMin: Math.max(4, Number(env.PUBLIC_PASSWORD_MIN) || 6),
    // The public release site (RELEASE_REPO=owner/name, GitHub Pages): where phones install Hub from anywhere
    releaseSite: /^[\w.-]+\/[\w.-]+$/.test(env.RELEASE_REPO ?? '') ? `https://${env.RELEASE_REPO.split('/')[0].toLowerCase()}.github.io/${env.RELEASE_REPO.split('/')[1]}/` : '',
    allowSignup: (env.ALLOW_SIGNUP ?? '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean),
    origins: (env.ALLOWED_ORIGINS ?? '*').split(',').map((s) => s.trim()),
    email: { provider: env.EMAIL_PROVIDER || 'console', from: env.EMAIL_FROM || 'Reminders <reminders@example.com>', brevoKey: env.BREVO_API_KEY, resendKey: env.RESEND_API_KEY },
    sms: { provider: env.SMS_PROVIDER || 'console', from: env.SMS_FROM, twilioSid: env.TWILIO_ACCOUNT_SID, twilioToken: env.TWILIO_AUTH_TOKEN, brevoKey: env.BREVO_API_KEY },
    // The Hub network: empty on the main server (Kaiden's). A person's own server (made with the Hub Server package)
    // has the main server's address here; it registers with it and checks in (name, owner, how many people, version).
    mainUrl: (env.MAIN_URL || '').replace(/\/+$/, ''),
    // Where Admin > Banking keeps the Enable Banking key file (beside the project, never in it): HUB\Keys by default
    keysDir: env.KEYS_DIR ? resolve(here, '..', env.KEYS_DIR) : undefined,
    // Finance > Business bank feed (Enable Banking). Only on the home PC. The application id, and the PATH to its
    // private key file (kept outside the project, never in git). The bank sends people back to EB_REDIRECT_URL, or
    // to PUBLIC_URL/bank/callback; that address must be listed in the Enable Banking application too.
    bank: { appId: env.EB_APP_ID || '', keyFile: env.EB_KEY_FILE || '', base: env.EB_API || undefined, redirect: env.EB_REDIRECT_URL || '', pollHours: Number(env.EB_POLL_HOURS) || 6 },
    tickMs: 30_000,
    ...overrides
  };
  return c;
}
