// HTTP API. Every route except health, register, login and forgot-password needs a Bearer token.
import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import { sessionFor } from './auth.mjs';
import { validMessage, tick, providers } from './messages.mjs';
import { accountRoutes, findUser, pub } from './accounts.mjs';
import { adminRoutes } from './admin.mjs';
import { fileRoutes } from './files.mjs';
import { assistant } from './assistant.mjs';
import { pushRoutes } from './push.mjs';
import { friendRoutes } from './friends.mjs';
import { hasClock, mergeFields, same } from './merge.mjs';
import { businessRoutes, bizAccess, bizMayWrite } from './business.mjs';
import { bankFeed } from './bank.mjs';
import { receiptRoutes } from './receipt.mjs';
import { space } from './space.mjs';
import { network } from './network.mjs';
import { record, recordError, summarise, stamp, addr, plural } from './history.mjs';

const key = (r) => `${r.col}/${r.id}`;
// Mine, shared with me, or a business I'm a partner in (Finance > Business)
const canSee = (rec, uid, db) => rec.owner === uid || (rec.shared ?? []).includes(uid) || (!!db && rec.col === 'business' && !!bizAccess(db, rec, uid));
// Linked in To Do > People, or friends (Hub > Sharing): either lets two accounts share things they choose
const linked = (db, a, b) => db.data.links.some((l) => l.status === 'accepted' && ((l.from === a && l.to === b) || (l.from === b && l.to === a)))
  || (db.data.friends ?? []).some((f) => f.status === 'accepted' && ((f.from === a && f.to === b) || (f.from === b && f.to === a)));
// Messages: a chat's people can share its messages with each other (in a group not everyone is friends with
// everyone). Null when this person isn't in the chat.
function chatMembers(db, r, uid) {
  if (r.data?.kind === 'chat') return null;
  const chat = db.data.recs[`chats/${r.data?.chat}`]?.rec;
  if (!chat || chat.deleted) return null;
  const members = Array.isArray(chat.data?.members) ? chat.data.members : [];
  return members.includes(uid) ? members : null;
}
// The bank callback opens without a sign-in: the bank sends the person there, with a one-time code tied to them
const OPEN = new Set(['/api/health', '/api/register', '/api/login', '/api/forgot', '/api/forgot/reset', '/bank/callback', '/api/net/register', '/api/net/checkin']);
// What a paused or banned own server stops (its people's apps keep their own copy, to use and to save)
const PAUSABLE = /^\/api\/(sync|live|bank\/|messages)/;

export function createApp(cfg, db, log = console.log) {
  const out = providers(cfg, log);
  const started = Date.now();

  function json(res, code, body, origin, headers = {}) {
    res.writeHead(code, {
      'content-type': 'application/json',
      'access-control-allow-origin': cfg.origins.includes('*') ? '*' : (cfg.origins.includes(origin) ? origin : 'null'),
      'access-control-allow-headers': 'content-type, authorization',
      'access-control-allow-methods': 'GET, POST, OPTIONS',
      'access-control-expose-headers': 'content-disposition',
      vary: 'origin',
      ...headers
    });
    res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
  }
  async function body(req) {
    let s = '';
    for await (const c of req) { s += c; if (s.length > 6_000_000) throw Object.assign(new Error('Too large'), { code: 413 }); }
    return s ? JSON.parse(s) : {};
  }

  const ctx = { db, cfg, log, stamp, started };
  // Live: each open device keeps one quiet connection (/api/live). When something it can see changes, it's told to
  // sync at once (a chat message arrives in a second, not a minute). Only the word "sync" ever goes down it.
  const live = new Map(); // account id -> open responses
  const audience = (rec) => {
    if (!rec) return [];
    const who = [rec.owner, ...(rec.shared ?? [])];
    if (rec.col === 'business') for (const p of db.data.bizPartners ?? []) if (p.status === 'accepted' && p.from === rec.owner) who.push(p.to);
    return who;
  };
  const poke = (ids) => { for (const id of new Set(ids)) for (const res of live.get(id) ?? []) { try { res.write('data: sync\n\n'); } catch { /* closed */ } } };
  ctx.poke = poke;
  const asst = assistant(ctx);
  ctx.assistant = asst;
  const push = pushRoutes(ctx);
  const sp = space(ctx);
  ctx.space = sp;
  const net = network(ctx);
  ctx.net = net;
  const bank = bankFeed(ctx);
  // Texts and emails go through the providers; push messages (to your own devices) through web push
  const send = (m) => (m.channel === 'push' ? push.sendToUser(m.by, { title: m.subject, body: m.body, route: m.route, tag: m.ref }) : out.send(m));
  const routes = {
    ...accountRoutes(ctx),
    ...adminRoutes(ctx),
    ...asst.routes,
    ...push.routes,
    ...friendRoutes(ctx),
    ...businessRoutes(ctx),
    ...bank.routes,
    ...receiptRoutes(ctx),
    ...sp.routes,
    ...net.routes,

    // Sync: push my changes, get everything I can see that changed since my cursor. The device also says what it
    // is (for the owner's console) and which apps were opened; the server notes simple actions ("added a task").
    'POST /api/sync': (b, u, { ip, session }) => {
      // A device that knows which server it belongs to never pushes its data into a different one
      if (b.server && b.server !== db.data.server.id) return [409, { error: 'This is a different server than before', code: 'different' }];
      const since = Number(b.since ?? 0);
      const accepted = [];
      const bounce = [];
      const actions = [];
      const sent = []; // new chat messages, for phone notifications
      // What the owner's console notes: messages yes (never their words), read marks and chat settings no
      const act = (verb, r) => { if (r.col !== 'chats' || r.data?.kind === 'msg') actions.push({ verb, col: r.col, app: r.app }); };
      // Space: a change that doesn't fit stays waiting on the device (never lost), and the device is told it's full
      const room = sp.meter(u);
      const refused = [];
      const full = (k, rec, prev) => { if (room.fits(rec, prev) || rec.deleted) return false; refused.push(k); return true; };
      for (const r of Array.isArray(b.changes) ? b.changes.slice(0, 5000) : []) {
        if (!r || typeof r.col !== 'string' || typeof r.id !== 'string' || !Number.isFinite(r.updatedAt)) continue;
        const k = key(r);
        const cur = db.data.recs[k];
        if (cur) {
          if (!canSee(cur.rec, u.id, db)) continue; // not mine: ignore
          const newer = r.updatedAt > cur.rec.updatedAt || (r.updatedAt === cur.rec.updatedAt && r.rev > cur.rec.rev);
          accepted.push(k);
          // A business partner can only change what their role allows: otherwise they get the real copy back
          if (r.col === 'business' && !bizMayWrite(db, { ...r, owner: cur.rec.owner }, cur.rec, u.id)) { bounce.push(cur.rec); continue; }
          // A message (or read mark) can only be changed by the person who wrote it
          if (r.col === 'chats' && cur.rec.owner !== u.id) { bounce.push(cur.rec); continue; }
          // Both copies say when each field changed (shopping items): keep every change, from both sides
          if (!r.deleted && !cur.rec.deleted && hasClock(r.data) && hasClock(cur.rec.data)) {
            const data = mergeFields(cur.rec.data, r.data, !newer);
            // Sharing can only be changed by the owner, and only with linked people or friends
            const members = r.col === 'chats' ? chatMembers(db, r, u.id) : null;
            const shared = cur.rec.owner === u.id && Array.isArray(r.shared) ? r.shared.filter((x) => x === u.id || linked(db, x, u.id) || !!members?.includes(x)) : cur.rec.shared;
            // Nothing new here: the device gets the server's copy if its own was missing something
            if (same(data, cur.rec.data) && same([...(shared ?? [])].sort(), [...(cur.rec.shared ?? [])].sort())) { if (!same(data, r.data)) bounce.push(cur.rec); continue; }
            const rec = { ...cur.rec, data, app: r.app, rev: Math.max(r.rev, cur.rec.rev) + 1, updatedAt: Math.max(r.updatedAt, cur.rec.updatedAt) + 1, shared };
            if (full(k, rec, cur.rec)) { accepted.pop(); continue; }
            db.data.recs[k] = { rec, seq: db.nextSeq(), by: u.id };
            act('changed', r);
            if (!same(data, r.data)) bounce.push(rec);
            continue;
          }
          if (!newer) { bounce.push(cur.rec); continue; }
          // Owner and sharing can only be changed by the owner
          const rec = { ...r, owner: cur.rec.owner, shared: cur.rec.owner === u.id && Array.isArray(r.shared) ? r.shared : cur.rec.shared };
          const verb = r.deleted && !cur.rec.deleted ? 'deleted' : r.data?.doneAt && !cur.rec.data?.doneAt ? 'completed' : 'changed';
          if (full(k, rec, cur.rec)) { accepted.pop(); continue; }
          db.data.recs[k] = { rec, seq: db.nextSeq(), by: u.id };
          act(verb, r);
          asst.changed(rec); // a task or note that came from Notion: send the change back
        } else {
          const owner = r.owner ?? u.id;
          // A partner adding to someone's business: only with add-and-edit or full control (it belongs to the owner)
          if (r.col === 'business' && owner !== u.id) { if (!bizMayWrite(db, { ...r, owner }, null, u.id)) continue; }
          else if (r.col === 'chats' && owner !== u.id) continue; // messages are only ever your own
          else if (owner !== u.id && !linked(db, owner, u.id)) continue; // can only give tasks to linked people
          const members = r.col === 'chats' ? chatMembers(db, r, u.id) : null;
          const shared = (r.shared ?? []).filter((x) => x === u.id || linked(db, x, u.id) || x === owner || !!members?.includes(x));
          if (full(k, { ...r, owner }, null)) continue;
          db.data.recs[k] = { rec: { ...r, owner, shared }, seq: db.nextSeq(), by: u.id };
          accepted.push(k);
          if (!r.deleted) act('added', r);
          if (r.col === 'chats' && r.data?.kind === 'msg' && !r.deleted) sent.push(db.data.recs[k].rec);
        }
      }
      // What this device is and when it last synced, for the owner's console
      if (session) {
        session.lastSeen = Date.now(); session.ip = addr(ip);
        if (b.device) session.device = { ...session.device, ...pick(b.device) };
        session.sync = { at: Date.now(), waiting: Number(b.waiting ?? 0) || 0 };
      }
      const device = [session?.device?.name, session?.device?.platform].filter(Boolean).join(' · ');
      for (const e of Array.isArray(b.events) ? b.events.slice(0, 50) : []) {
        if (e?.kind === 'open' && typeof e.app === 'string') record(db, { user: u.id, username: u.username, kind: 'open', what: `opened ${String(e.name ?? e.app).slice(0, 40)}`, app: e.app, device, ip });
      }
      const byApp = new Map();
      for (const a of actions) { const l = byApp.get(a.app) ?? []; l.push(a); byApp.set(a.app, l); }
      for (const [app, list] of byApp) for (const what of summarise(list)) record(db, { user: u.id, username: u.username, kind: 'action', what, app, device, ip });
      db.save();
      // Tell everyone who can see these (their other open devices too) to fetch them now, not in a minute
      if (accepted.length) poke(accepted.flatMap((k) => audience(db.data.recs[k]?.rec)));
      // A new message: a phone notification for the others in the chat (when they turned those on), unless muted
      for (const m of sent) {
        for (const to of m.shared ?? []) {
          if (to === u.id || db.data.recs[`chats/pref~${m.data.chat}~${to}`]?.rec?.data?.muted) continue;
          ctx.sendPush?.(to, { title: u.name, body: String(m.data.text ?? '').slice(0, 140) || 'Sent you a message', route: `messages/chat/${m.data.chat}`, tag: `chat-${m.data.chat}` })?.catch?.(() => {});
        }
      }
      const changes = [];
      for (const { rec, seq } of Object.values(db.data.recs)) if (seq > since && canSee(rec, u.id, db)) changes.push(rec);
      if (actions.length || (since === 0 && changes.length)) {
        log(`${stamp()} ${u.name} synced from ${addr(ip)}: ${plural(actions.length, 'change')} saved` +
          (since === 0 ? `, ${plural(changes.length, 'item')} sent to this device` : ''));
      }
      return [200, { accepted, changes: [...changes, ...bounce], cursor: db.data.seq, server: { id: db.data.server.id, name: db.data.server.name }, space: room.info(), refused: refused.length ? refused : undefined, network: net.status() }];
    },

    // People: link two accounts (both must agree) so they can send each other reminders.
    'POST /api/link': (b, u) => {
      const other = findUser(db, b.username ?? b.email);
      if (!other) return [404, { error: 'No account with that username on this server' }];
      if (other.id === u.id) return [400, { error: "That's you" }];
      const back = db.data.links.find((l) => l.from === other.id && l.to === u.id && l.status === 'pending');
      if (back) { back.status = 'accepted'; db.save(); return [200, { status: 'accepted', person: pub(other) }]; }
      if (!db.data.links.some((l) => l.from === u.id && l.to === other.id)) db.data.links.push({ from: u.id, to: other.id, status: 'pending', at: Date.now() });
      db.save();
      return [200, { status: 'pending', person: pub(other) }];
    },
    'GET /api/links': (_b, u) => [200, {
      links: db.data.links.filter((l) => l.from === u.id || l.to === u.id).map((l) => {
        const o = db.data.users[l.from === u.id ? l.to : l.from];
        return { status: l.status, incoming: l.to === u.id, person: o ? pub(o) : null };
      })
    }],

    // Texts and emails to anyone, sent by the server at the right time.
    'POST /api/messages': (b, u) => {
      const err = validMessage(b);
      if (err) return [400, { error: err }];
      if (db.data.messages.filter((m) => m.by === u.id && m.status === 'queued').length >= 500) return [429, { error: 'Too many waiting messages' }];
      const m = { id: randomUUID(), by: u.id, channel: b.channel, to: { email: b.to?.email, phone: b.to?.phone, name: b.to?.name }, subject: b.subject ? String(b.subject).slice(0, 200) : undefined, body: b.body.trim(), sendAt: b.sendAt, ref: b.ref, route: typeof b.route === 'string' ? b.route.slice(0, 80) : undefined, status: 'queued', created: Date.now() };
      db.data.messages.push(m); db.save();
      return [200, { id: m.id, status: m.status }];
    },
    'GET /api/messages': (_b, u) => [200, { messages: db.data.messages.filter((m) => m.by === u.id).slice(-200) }],
    'POST /api/messages/cancel': (b, u) => {
      const m = db.data.messages.find((x) => x.id === b.id && x.by === u.id);
      if (!m) return [404, { error: 'Not found' }];
      if (m.status === 'queued') { m.status = 'cancelled'; db.save(); }
      return [200, { status: m.status }];
    }
  };
  const pick = (d) => ({ name: String(d.name ?? '').slice(0, 60), platform: String(d.platform ?? '').slice(0, 30), version: String(d.version ?? '').slice(0, 20) });
  ctx.routes = routes;

  const notFound = (res, msg = 'Not found') => json(res, 404, { error: msg }, '');
  const files = fileRoutes(cfg, log, notFound);

  // The outside link (Part 7): Tailscale Funnel gives the PC a public https address and passes requests to a
  // second listener on this PC only (PUBLIC_PORT). Requests through it get the stricter rules: longer passwords to
  // sign in, a lockout after wrong tries, rate limits, no owner sign-up, Admin only for a recent owner sign-in,
  // and security headers. The home-network address keeps the household's own settings.
  const SEC = { 'strict-transport-security': 'max-age=31536000', 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer', 'x-frame-options': 'SAMEORIGIN' };
  const hits = new Map(); // ip -> { n, until, auth }
  function tooFast(ip, auth) {
    const now = Date.now();
    let h = hits.get(ip);
    if (!h || h.until < now) { h = { n: 0, auth: 0, until: now + 5 * 60_000 }; hits.set(ip, h); }
    h.n++; if (auth) h.auth++;
    if (hits.size > 5000) for (const [k, v] of hits) if (v.until < now) hits.delete(k);
    return h.n > 600 || h.auth > 25;
  }
  const AUTH = new Set(['/api/login', '/api/register', '/api/forgot', '/api/forgot/reset']);

  const handler = (isPublic) => async (req, res) => {
    const origin = req.headers.origin ?? '';
    if (isPublic) for (const [k, v] of Object.entries(SEC)) res.setHeader(k, v);
    if (req.method === 'OPTIONS') return json(res, 204, {}, origin);
    const url = new URL(req.url, 'http://x');
    const path = url.pathname;
    // Through the outside link every request arrives from this PC: the visitor's address is in X-Forwarded-For
    const ip = isPublic ? String(req.headers['x-forwarded-for'] ?? req.socket.remoteAddress ?? '').split(',')[0].trim() : req.socket.remoteAddress ?? '';
    if (isPublic && path.startsWith('/api/') && tooFast(ip, AUTH.has(path))) return json(res, 429, { error: 'Too many requests from your address. Wait a few minutes', code: 'slow' }, origin);
    if (net.blocked() && PAUSABLE.test(path)) return json(res, 423, { error: db.data.net.status === 'banned' ? 'This server has been stopped by Hub. Your things are still on your devices: save a copy in Hub > Updates and backup' : 'This server is paused by Hub for now. Your things are still on your devices, and you can save a copy in Hub > Updates and backup', code: 'paused' }, origin);
    if (req.method === 'GET' && path === '/api/live') {
      const s = sessionFor(db, (req.headers.authorization ?? '').replace(/^Bearer\s+/i, ''));
      if (!s?.user) return json(res, 401, { error: 'Signed out. Sign in again', code: 'signedout' }, origin);
      res.writeHead(200, {
        'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive', 'x-accel-buffering': 'no',
        'access-control-allow-origin': cfg.origins.includes('*') ? '*' : (cfg.origins.includes(origin) ? origin : 'null'), vary: 'origin'
      });
      res.write(': ok\n\n');
      const id = s.user.id;
      const set = live.get(id) ?? new Set();
      set.add(res); live.set(id, set);
      const ping = setInterval(() => { try { res.write(': ping\n\n'); } catch { /* closed */ } }, 25_000);
      req.on('close', () => { clearInterval(ping); set.delete(res); if (!set.size) live.delete(id); });
      return;
    }
    const fn = routes[`${req.method} ${path}`];
    if (!fn) {
      if (files(req, res, path)) return;
      return json(res, 404, { error: 'Not found' }, origin);
    }
    let user = null;
    try {
      const token = (req.headers.authorization ?? '').replace(/^Bearer\s+/i, '');
      const s = OPEN.has(path) ? null : sessionFor(db, token);
      // The assistant inbox also takes a personal inbox token
      user = s?.user ?? (path === '/api/inbox' ? asst.inboxUser(token) : null);
      if (!OPEN.has(path) && !user) return json(res, 401, { error: 'Signed out. Sign in again', code: 'signedout' }, origin);
      if (isPublic && path.startsWith('/api/admin/') && (!s || Date.now() - s.session.created > 12 * 3600_000)) {
        return json(res, 403, { error: 'From outside, Admin needs a fresh sign-in (in the last 12 hours). Sign out and in again', code: 'fresh' }, origin);
      }
      const b = req.method === 'POST' ? await body(req) : {};
      const [code, result, headers] = await fn(b, user, { ip, token, session: s?.session, q: url.searchParams, req, public: isPublic });
      if (code >= 400 && path.startsWith('/api/') && code !== 401) recordError(db, { method: req.method, path, status: code, ip, user: user?.id, msg: result?.error });
      json(res, code, result, origin, headers);
    } catch (e) {
      recordError(db, { method: req.method, path, status: e.code === 413 ? 413 : 400, ip, user: user?.id, msg: e.message });
      json(res, e.code === 413 ? 413 : 400, { error: e.code === 413 ? 'Too large' : 'Bad request' }, origin);
    }
  };
  const server = createServer(handler(false));
  const publicServer = cfg.publicPort != null ? createServer(handler(true)) : null;
  let iv = null;
  return {
    server,
    ctx: Object.assign(ctx, { db }),
    tick: () => tick(db, send),
    start(port = cfg.port) {
      iv = setInterval(() => tick(db, send), cfg.tickMs);
      tick(db, send);
      bank.start();
      net.start();
      // The outside listener only ever listens on this PC: Tailscale Funnel is the one way in from outside
      if (publicServer) publicServer.listen(cfg.publicPort, '127.0.0.1', () => log(`  Outside link: 127.0.0.1:${publicServer.address().port}${cfg.publicUrl ? ` -> ${cfg.publicUrl}` : ''}`));
      return new Promise((r) => server.listen(port, cfg.host, () => r(server.address().port)));
    },
    publicServer,
    bank,
    stop() { for (const set of live.values()) for (const r of set) r.end(); live.clear(); clearInterval(iv); bank.stop(); net.stop(); asst.stop(); db.saveNow(); publicServer?.close(); return new Promise((r) => server.close(r)); }
  };
}
