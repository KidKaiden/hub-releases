// The Hub network. One main server (Kaiden's: no MAIN_URL setting) and people's own servers (made with the Hub
// Server package, which sets MAIN_URL to the main server's outside link). An own server registers with the main one
// and checks in every few hours, sending only its name, its owner's name, how many people it has and its version:
// never accounts, chats, money or anything else in it. The main server's owner sees the list (Admin > Servers) and
// can pause a server's link to Hub (it keeps working for its people), pause it completely (its people can't sync
// until it's unpaused; their data stays on their devices to save), or ban it. If the main server can't be reached,
// an own server just carries on and tries again later.
import { randomBytes, randomUUID, createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const VERSION = (() => { try { return JSON.parse(readFileSync(join(here, '..', 'package.json'), 'utf8')).version; } catch { return '?'; } })();
const sha = (s) => createHash('sha256').update(String(s)).digest('hex');
const STATUS = ['ok', 'paused-link', 'paused', 'banned'];
export const STATUS_WORDS = { ok: 'Connected', 'paused-link': 'Link to Hub paused', paused: 'Paused', banned: 'Banned' };

export function network(ctx) {
  const { db, cfg, log, stamp } = ctx;
  const main = !cfg.mainUrl;
  db.data.servers ??= {};
  db.data.net ??= {};
  const isAdmin = (u) => !!db.data.roles?.[u.role]?.admin;
  const me = () => ({
    id: db.data.server.id, name: db.data.server.name,
    owner: Object.values(db.data.users).find((u) => u.role === 'owner')?.name ?? '',
    members: Object.values(db.data.users).filter((u) => !u.disabled).length, version: VERSION
  });
  const view = (s) => ({ id: s.id, name: s.name, owner: s.owner, members: s.members, version: s.version, first: s.first, lastSeen: s.lastSeen, status: s.status });

  // ---------- An own server: register, then check in ----------
  async function checkIn() {
    if (main) return;
    const n = db.data.net;
    try {
      const path = n.token ? '/api/net/checkin' : '/api/net/register';
      const r = await fetch(`${cfg.mainUrl}${path}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...me(), token: n.token }), signal: AbortSignal.timeout(20_000) });
      const j = await r.json().catch(() => ({}));
      if (j.token) n.token = j.token;
      if (typeof j.latest === 'string') n.latest = j.latest.slice(0, 20);
      if (STATUS.includes(j.status)) {
        if (j.status !== n.status) log(`${stamp()} Hub network: ${STATUS_WORDS[j.status]}`);
        n.status = j.status;
      }
      n.lastCheck = Date.now(); n.error = r.ok ? null : j.error ?? `The main server said ${r.status}`;
    } catch (e) {
      n.error = "Couldn't reach the main server (it will try again)";
    }
    db.save();
  }

  const routes = {
    // The main server: an own server says hello (once) and gets its check-in token
    'POST /api/net/register': (b) => {
      if (!main) return [404, { error: 'Not found' }];
      const id = String(b.id ?? '');
      if (!/^[0-9a-f-]{20,}$/i.test(id)) return [400, { error: 'Bad server id' }];
      const old = db.data.servers[id];
      if (old?.status === 'banned') return [403, { error: 'This server is banned from Hub', status: 'banned' }];
      if (old && old.tokenHash && sha(b.token ?? '') !== old.tokenHash) return [409, { error: 'This server is already registered' }];
      const token = randomBytes(24).toString('base64url');
      db.data.servers[id] = { ...(old ?? { first: Date.now(), status: 'ok' }), id, name: String(b.name ?? 'Hub server').slice(0, 60), owner: String(b.owner ?? '').slice(0, 60), members: Math.max(0, Number(b.members) || 0), version: String(b.version ?? '').slice(0, 20), lastSeen: Date.now(), tokenHash: sha(token) };
      db.save();
      log(`${stamp()} Hub network: a new server joined (${db.data.servers[id].name})`);
      ctx.poke?.(Object.values(db.data.users).filter(isAdmin).map((x) => x.id));
      return [200, { token, status: db.data.servers[id].status, latest: VERSION }];
    },
    'POST /api/net/checkin': (b) => {
      if (!main) return [404, { error: 'Not found' }];
      const s = db.data.servers[String(b.id ?? '')];
      if (!s || sha(b.token ?? '') !== s.tokenHash) return [401, { error: 'Unknown server' }];
      Object.assign(s, { name: String(b.name ?? s.name).slice(0, 60), owner: String(b.owner ?? s.owner).slice(0, 60), members: Math.max(0, Number(b.members) || 0), version: String(b.version ?? '').slice(0, 20), lastSeen: Date.now() });
      db.save();
      return [200, { status: s.status, latest: VERSION }];
    },
    // The main server's owner: every server made with Hub
    'GET /api/admin/servers': (_b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      if (!main) return [200, { main: false, servers: [] }];
      return [200, { main: true, servers: Object.values(db.data.servers).map(view).sort((a, b) => b.lastSeen - a.lastSeen) }];
    },
    'POST /api/admin/servers/set': (b, u) => {
      if (!isAdmin(u) || !main) return [403, { error: 'Only the main server\'s owner can do this', code: 'owner' }];
      const s = db.data.servers[String(b.id ?? '')];
      if (!s) return [404, { error: 'No such server' }];
      if (b.remove) { delete db.data.servers[s.id]; db.save(); log(`${stamp()} Hub network: ${u.name} removed ${s.name} from the list`); return [200, { ok: true }]; }
      if (!STATUS.includes(b.status)) return [400, { error: 'Unknown status' }];
      s.status = b.status;
      db.save();
      log(`${stamp()} Hub network: ${u.name} set ${s.name} to ${STATUS_WORDS[s.status]}`);
      return [200, { server: view(s) }];
    },
    // This server, as the Hub network sees it (for its own Admin)
    'GET /api/admin/network': (_b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      return [200, { main, mainUrl: cfg.mainUrl || null, status: db.data.net.status ?? 'ok', lastCheck: db.data.net.lastCheck ?? null, error: db.data.net.error ?? null, registered: !!db.data.net.token, me: me(), latest: db.data.net.latest ?? null }];
    },
    'POST /api/admin/network/check': async (_b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      await checkIn();
      return [200, { status: db.data.net.status ?? 'ok', lastCheck: db.data.net.lastCheck ?? null, error: db.data.net.error ?? null }];
    }
  };

  let iv = null, first = null;
  return {
    routes,
    main,
    /** For every device on this server: whether it's the main one, and its standing */
    status: () => ({ main, status: main ? 'ok' : db.data.net.status ?? 'ok' }),
    /** Paused or banned (an own server): its people can't sync until it's unpaused */
    blocked: () => !main && (db.data.net.status === 'paused' || db.data.net.status === 'banned'),
    start() { if (main) return; first = setTimeout(() => void checkIn(), 5_000); iv = setInterval(() => void checkIn(), 6 * 3600_000); first.unref?.(); iv.unref?.(); },
    stop() { clearTimeout(first); clearInterval(iv); },
    checkIn,
    newId: randomUUID
  };
}
