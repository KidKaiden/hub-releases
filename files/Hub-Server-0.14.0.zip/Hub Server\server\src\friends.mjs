// Friends and the leaderboard (Update 2, D9). Friendship is between Hub accounts, not one app: someone asks, the
// other accepts, and only then do they see each other on the leaderboard. The leaderboard shares numbers only
// (level, points, streak, badges): never bills, balances, notes or tasks. Either side can remove the friendship.
import { randomUUID } from 'node:crypto';
import { findUser } from './accounts.mjs';
import { record } from './history.mjs';

const person = (u) => ({ accountId: u.id, username: u.username, name: u.name || u.username });
const num = (v, max = 1e9) => Math.max(0, Math.min(max, Math.round(Number(v) || 0)));

export function friendRoutes(ctx) {
  const { db } = ctx;
  const list = () => (db.data.friends ??= []);
  const stats = () => (db.data.stats ??= {});
  const between = (a, b) => list().find((f) => (f.from === a && f.to === b) || (f.from === b && f.to === a));
  const friendsOf = (id) => list().filter((f) => f.status === 'accepted' && (f.from === id || f.to === id)).map((f) => (f.from === id ? f.to : f.from));
  const note = (u, what) => record(db, { user: u.id, username: u.username, kind: 'action', what });

  return {
    'GET /api/friends': (_b, u) => {
      const users = db.data.users;
      const friends = list().filter((f) => f.status === 'accepted' && (f.from === u.id || f.to === u.id))
        .map((f) => users[f.from === u.id ? f.to : f.from]).filter(Boolean).map((x) => ({ ...person(x), since: between(u.id, x.id)?.answered ?? null }));
      const incoming = list().filter((f) => f.status === 'pending' && f.to === u.id && users[f.from]).map((f) => ({ id: f.id, from: person(users[f.from]), created: f.created }));
      const outgoing = list().filter((f) => f.status === 'pending' && f.from === u.id && users[f.to]).map((f) => ({ id: f.id, to: person(users[f.to]), created: f.created }));
      return [200, { friends, incoming, outgoing }];
    },
    'POST /api/friends/request': (b, u) => {
      const to = findUser(db, String(b.username ?? '').trim().toLowerCase());
      if (!to || to.disabled) return [404, { error: `No account called "${String(b.username ?? '').trim()}" on this Hub`, field: 'username' }];
      if (to.id === u.id) return [400, { error: "That's you", field: 'username' }];
      const f = between(u.id, to.id);
      if (f?.status === 'accepted') return [409, { error: `You and ${to.name || to.username} are already friends` }];
      if (f?.status === 'pending' && f.from === u.id) return [409, { error: `You asked ${to.name || to.username} already. Waiting for them to accept` }];
      if (f?.status === 'pending' && f.to === u.id) {
        // They already asked you: asking back is a yes
        f.status = 'accepted'; f.answered = Date.now(); db.save();
        note(u, `became friends with ${to.username}`);
        return [200, { status: 'accepted', friend: person(to) }];
      }
      list().push({ id: randomUUID(), from: u.id, to: to.id, status: 'pending', created: Date.now() });
      db.save();
      note(u, `asked ${to.username} to be friends`);
      return [200, { status: 'pending', to: person(to) }];
    },
    'POST /api/friends/answer': (b, u) => {
      const f = list().find((x) => x.id === b.id && x.to === u.id && x.status === 'pending');
      if (!f) return [404, { error: 'That request has gone' }];
      const from = db.data.users[f.from];
      if (b.accept) { f.status = 'accepted'; f.answered = Date.now(); note(u, `became friends with ${from?.username ?? 'someone'}`); }
      else { db.data.friends = list().filter((x) => x !== f); note(u, `said no to a friend request`); }
      db.save();
      return [200, { ok: true }];
    },
    /** Remove a friend, or take back a request (either side) */
    'POST /api/friends/remove': (b, u) => {
      const f = between(u.id, String(b.accountId ?? ''));
      if (!f) return [404, { error: 'You are not friends with them' }];
      db.data.friends = list().filter((x) => x !== f);
      db.save();
      note(u, f.status === 'accepted' ? 'removed a friend' : 'took back a friend request');
      return [200, { ok: true }];
    },
    /** My leaderboard numbers (sent by the Finance app). Numbers only: nothing else is accepted. overall: how far
     *  through all my debts and goals I am, in % (never pounds); the server keeps where it stood when the month began,
     *  so the leaderboard can rank by how much each person moved this month. */
    'POST /api/stats': (b, u) => {
      const prev = stats()[u.id] ?? {};
      // An older Finance that doesn't send it keeps the last one
      const overall = b.overall == null ? (Number(prev.overall) || 0) : Math.max(0, Math.min(100, Number(b.overall) || 0));
      const month = new Date().toISOString().slice(0, 7);
      const base = prev.month === month && Number.isFinite(prev.base) ? prev.base : (Number.isFinite(prev.overall) ? prev.overall : overall);
      stats()[u.id] = { points: num(b.points), level: num(b.level, 1e6), streak: num(b.streak, 1e5), badges: num(b.badges, 100), overall, month, base, updated: Date.now() };
      db.save();
      return [200, { ok: true }];
    },
    /** Me and my friends, most points first; moved: % of their goals moved this month */
    'GET /api/leaderboard': (_b, u) => {
      const ids = [u.id, ...friendsOf(u.id)];
      const rows = ids.map((id) => db.data.users[id]).filter(Boolean).map((x) => {
        const st = stats()[x.id] ?? { points: 0, level: 1, streak: 0, badges: 0, updated: null };
        const moved = st.month === new Date().toISOString().slice(0, 7) ? Math.round(((st.overall ?? 0) - (st.base ?? 0)) * 10) / 10 : 0;
        return { ...person(x), me: x.id === u.id, points: st.points, level: st.level, streak: st.streak, badges: st.badges, updated: st.updated, moved };
      });
      rows.sort((a, b) => b.points - a.points || a.name.localeCompare(b.name));
      return [200, { rows }];
    },

    // ---------- The friends' feed (Kaiden, 2026-11-13: "like Strava"): wins, kudos and comments. A win says what
    // happened in words and percent, never pounds. Only you and your friends see yours. ----------
    'GET /api/feed': (_b, u) => {
      const ids = new Set([u.id, ...friendsOf(u.id)]);
      const items = feed().filter((x) => ids.has(x.user) && db.data.users[x.user]).slice(-60).reverse().slice(0, 40).map((x) => view(x, u.id));
      return [200, { items }];
    },
    'POST /api/feed/post': (b, u) => {
      const kind = String(b.kind ?? '');
      if (!KINDS.has(kind)) return [400, { error: 'Unknown kind of win' }];
      const key = String(b.key ?? '').slice(0, 80);
      if (!key) return [400, { error: 'Missing key' }];
      const had = feed().find((x) => x.user === u.id && x.key === key);
      if (had) return [200, { item: view(had, u.id), existed: true }];
      const x = { id: randomUUID(), user: u.id, key, kind, title: clean(b.title, 70), pct: b.pct == null ? null : Math.max(0, Math.min(100, Math.round(Number(b.pct) || 0))), created: Date.now(), kudos: [], comments: [] };
      feed().push(x);
      if (feed().length > 2000) db.data.feed = feed().slice(-2000);
      db.save();
      return [200, { item: view(x, u.id) }];
    },
    'POST /api/feed/kudos': (b, u) => {
      const x = seen(b.id, u.id);
      if (!x) return [404, { error: 'That post has gone' }];
      if (x.user === u.id) return [400, { error: "You can't give yourself kudos" }];
      x.kudos = x.kudos.includes(u.id) ? x.kudos.filter((k) => k !== u.id) : [...x.kudos, u.id];
      db.save();
      return [200, { item: view(x, u.id) }];
    },
    'POST /api/feed/comment': (b, u) => {
      const x = seen(b.id, u.id);
      if (!x) return [404, { error: 'That post has gone' }];
      const text = clean(b.text, 200);
      if (!text) return [400, { error: 'Write something first', field: 'text' }];
      x.comments.push({ id: randomUUID(), user: u.id, text, created: Date.now() });
      if (x.comments.length > 100) x.comments = x.comments.slice(-100);
      db.save();
      return [200, { item: view(x, u.id) }];
    },
    'POST /api/feed/remove': (b, u) => {
      const x = feed().find((y) => y.id === b.id && y.user === u.id);
      if (!x) return [404, { error: 'That post has gone' }];
      db.data.feed = feed().filter((y) => y !== x);
      db.save();
      return [200, { ok: true }];
    },

    // ---------- Challenges between friends: "who moves the most of their goals in 14 days", or the longest
    // on-time streak. Progress is in percent (or a count for streaks), from the same numbers as the leaderboard. ----------
    'GET /api/challenges': (_b, u) => {
      const now = Date.now();
      const list = challenges().filter((c) => c.members[u.id] && c.members[u.id].status !== 'left' && c.ends > now - 7 * 86_400_000);
      return [200, { challenges: list.map((c) => cview(c, u.id)) }];
    },
    'POST /api/challenges/new': (b, u) => {
      const title = clean(b.title, 50);
      if (!title) return [400, { error: 'Give it a name', field: 'title' }];
      const kind = b.kind === 'streak' ? 'streak' : 'move';
      const days = Math.max(3, Math.min(90, Math.round(Number(b.days) || 14)));
      const mine = new Set(friendsOf(u.id));
      const invite = [...new Set((Array.isArray(b.invite) ? b.invite : []).map(String))].filter((id) => mine.has(id)).slice(0, 20);
      if (!invite.length) return [400, { error: 'Pick at least one friend', field: 'invite' }];
      const members = { [u.id]: { status: 'in', base: baseFor(kind, u.id), joined: Date.now() } };
      for (const id of invite) members[id] = { status: 'invited', base: null, joined: null };
      const c = { id: randomUUID(), by: u.id, title, kind, created: Date.now(), ends: Date.now() + days * 86_400_000, members };
      challenges().push(c);
      db.save();
      note(u, `started a challenge with ${invite.length} friend${invite.length === 1 ? '' : 's'}`);
      return [200, { challenge: cview(c, u.id) }];
    },
    'POST /api/challenges/answer': (b, u) => {
      const c = challenges().find((x) => x.id === b.id && x.members[u.id]?.status === 'invited');
      if (!c) return [404, { error: 'That challenge has gone' }];
      c.members[u.id] = b.join ? { status: 'in', base: baseFor(c.kind, u.id), joined: Date.now() } : { status: 'left', base: null, joined: null };
      db.save();
      return [200, { challenge: cview(c, u.id) }];
    },
    'POST /api/challenges/leave': (b, u) => {
      const c = challenges().find((x) => x.id === b.id && x.members[u.id]);
      if (!c) return [404, { error: 'That challenge has gone' }];
      c.members[u.id].status = 'left';
      db.save();
      return [200, { ok: true }];
    }
  };

  // ---- feed and challenge helpers ----
  function feed() { return (db.data.feed ??= []); }
  function challenges() { return (db.data.challenges ??= []); }
  function seen(id, me) { const x = feed().find((y) => y.id === id); return x && (x.user === me || friendsOf(me).includes(x.user)) ? x : null; }
  function nameOf(id) { const x = db.data.users[id]; return x ? x.name || x.username : 'Someone'; }
  function view(x, me) {
    return {
      id: x.id, kind: x.kind, title: x.title, pct: x.pct, created: x.created, me: x.user === me,
      who: { accountId: x.user, name: nameOf(x.user) },
      kudos: x.kudos.length, mine: x.kudos.includes(me), kudosFrom: x.kudos.slice(-3).map(nameOf),
      comments: x.comments.slice(-20).map((c) => ({ id: c.id, name: nameOf(c.user), me: c.user === me, text: c.text, created: c.created }))
    };
  }
  function baseFor(kind, id) { const st = stats()[id] ?? {}; return kind === 'streak' ? 0 : Number(st.overall) || 0; }
  function cview(c, me) {
    const standings = Object.entries(c.members)
      .filter(([id, m]) => m.status !== 'left' && db.data.users[id])
      .map(([id, m]) => {
        const st = stats()[id] ?? {};
        const progress = m.status !== 'in' ? null : c.kind === 'streak' ? Number(st.streak) || 0 : Math.round(((Number(st.overall) || 0) - (m.base ?? 0)) * 10) / 10;
        return { accountId: id, name: nameOf(id), me: id === me, status: m.status, progress };
      })
      .sort((a, b) => (b.progress ?? -1e9) - (a.progress ?? -1e9) || a.name.localeCompare(b.name));
    return { id: c.id, title: c.title, kind: c.kind, created: c.created, ends: c.ends, over: c.ends < Date.now(), byMe: c.by === me, by: nameOf(c.by), myStatus: c.members[me]?.status ?? null, standings };
  }
}

const KINDS = new Set(['debt-cleared', 'debt-half', 'goal-done', 'goal-half', 'streak', 'level', 'badge', 'challenge-won']);
/** Plain text only, one line, trimmed to a length */
function clean(v, max) { return String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max); }
