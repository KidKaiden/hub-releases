// Finance > Business: reading a receipt photo. Free and private: the text is read here on the home PC (Tesseract, an
// open-source reader, with its English data shipped in the package: nothing is downloaded and nothing goes to another
// company). The app shows what was found and the person checks it before saving; the photo stays attached either way.
import { join } from 'node:path';
import { mkdirSync } from 'node:fs';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const MON = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
const pad = (n) => String(n).padStart(2, '0');
function day(y, m, d, today) {
  if (y < 100) y += 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31 || y < 2000) return null;
  const t = new Date(y, m - 1, d);
  if (t.getMonth() !== m - 1) return null;
  const s = `${y}-${pad(m)}-${pad(d)}`;
  return s <= today ? s : null; // a receipt is never from the future
}
const money = (s) => Number(s.replace(/[ ,](?=\d{3}\b)/g, '').replace(',', '.'));

/** Amount (the total), date, shop and VAT from a receipt's text. Missing ones are left out; the person checks them. */
export function parseReceipt(text, today = new Date().toISOString().slice(0, 10)) {
  const lines = String(text ?? '').split(/\r?\n/).map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const AMT = /(?:£|€|\$|GBP|EUR)?\s?(-?\d{1,6}(?:[ ,]\d{3})*[.,]\d{2})(?!\d)/g;
  const amounts = (l) => [...l.matchAll(AMT)].map((m) => money(m[1])).filter((n) => Number.isFinite(n) && n > 0 && n < 1e6);
  const out = {};
  // The total: a line that says so (not a subtotal, VAT, saving or change), the last one on the receipt
  const totalish = /\b(total|amount due|balance due|to pay|grand total|amount|card payment|paid|visa|mastercard|contactless|debit)\b/i;
  const not = /\b(sub ?-?total|vat|tax|saving|discount|change|cash tendered|items?|qty|points)\b/i;
  const strong = lines.filter((l) => /\btotal\b|amount due|balance due|to pay/i.test(l) && !not.test(l) && amounts(l).length);
  const weak = lines.filter((l) => totalish.test(l) && !not.test(l) && amounts(l).length);
  const pick = strong.length ? strong : weak;
  if (pick.length) out.amount = Math.max(...amounts(pick[pick.length - 1]));
  else { const all = lines.filter((l) => !not.test(l)).flatMap(amounts); if (all.length) out.amount = Math.max(...all); }
  // VAT: a line that names it, smaller than the total
  for (const l of lines) {
    if (!/\bvat\b/i.test(l) || /vat (no|number|reg)/i.test(l)) continue;
    const a = amounts(l).filter((n) => !out.amount || n < out.amount * 0.5);
    if (a.length) { out.vat = a[a.length - 1]; break; }
  }
  // The date
  for (const l of lines) {
    let m = l.match(/\b(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})\b/);
    let d = m && day(+m[1], +m[2], +m[3], today);
    if (!d) { m = l.match(/\b(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})\b/); d = m && day(+m[3], +m[2], +m[1], today); }
    if (!d) { m = l.match(/\b(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]{3,})\.?,?\s+(\d{2,4})\b/); const mi = m ? MON.indexOf(m[2].slice(0, 3).toLowerCase()) : -1; d = mi >= 0 ? day(+m[3], mi + 1, +m[1], today) : null; }
    if (d) { out.date = d; break; }
  }
  // The shop: the first line with real words near the top (not an address, phone, web or receipt heading)
  const shop = lines.slice(0, 8).find((l) => /[A-Za-z]{3,}/.test(l) && !/(receipt|invoice|tel|phone|vat|www\.|http|@|\d{3,}|street|road|\bst\b|\brd\b|welcome|thank)/i.test(l) && l.length <= 40);
  if (shop) out.shop = shop.replace(/[^A-Za-z0-9&'. -]/g, '').trim().toLowerCase().replace(/\b[a-z]/g, (c) => c.toUpperCase());
  return out;
}

export function receiptRoutes(ctx) {
  const { cfg, log, stamp } = ctx;
  let worker = null, idle = null, queue = Promise.resolve();
  async function reader() {
    clearTimeout(idle);
    if (!worker) {
      const { createWorker } = await import('tesseract.js');
      const langPath = join(require.resolve('@tesseract.js-data/eng/package.json'), '..', '4.0.0_best_int');
      const cachePath = join(cfg.dataDir, 'ocr');
      mkdirSync(cachePath, { recursive: true });
      worker = await createWorker('eng', 1, { langPath, cachePath, gzip: true, logger: () => {}, errorHandler: () => {} });
    }
    // Let it go after 5 quiet minutes (it uses memory)
    idle = setTimeout(() => { const w = worker; worker = null; void w?.terminate(); }, 5 * 60_000);
    idle.unref?.();
    return worker;
  }
  return {
    'POST /api/receipt/read': async (b) => {
      const m = String(b.image ?? '').match(/^data:image\/(jpeg|png|webp);base64,(.+)$/);
      if (!m) return [400, { error: 'Send a photo of the receipt' }];
      const img = Buffer.from(m[2], 'base64');
      if (img.length > 5_000_000) return [413, { error: 'That photo is too big' }];
      try {
        // One at a time
        const job = queue.then(async () => (await reader()).recognize(img));
        queue = job.catch(() => {});
        const { data } = await job;
        const got = parseReceipt(data.text);
        log(`${stamp()} Receipt read on this PC (${got.amount ? 'total found' : 'no total found'})`);
        return [200, { ...got, sure: (data.confidence ?? 0) > 70 }];
      } catch (e) {
        log(`${stamp()} Receipt reader could not run: ${e.message}`);
        return [501, { error: "The receipt reader isn't working on the PC yet (double-click update.cmd there)" }];
      }
    }
  };
}
