// Logins: passwords and security answers are hashed with scrypt; sessions are random tokens stored only as hashes.
import { scryptSync, randomBytes, timingSafeEqual, createHash } from 'node:crypto';

const sha = (s) => createHash('sha256').update(s).digest('hex');
/** How a session token is stored (only its hash is kept). */
export const tokenKey = (t) => sha(String(t ?? ''));
export function hashPassword(pw) {
  const salt = randomBytes(16);
  const h = scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('hex')}$${h.toString('hex')}`;
}
export function checkPassword(pw, stored) {
  const [, salt, hex] = String(stored).split('$');
  if (!salt || !hex) return false;
  const h = scryptSync(String(pw), Buffer.from(salt, 'hex'), 64, { N: 16384, r: 8, p: 1 });
  const want = Buffer.from(hex, 'hex');
  return want.length === h.length && timingSafeEqual(h, want);
}

/** Security answers: same hashing, compared ignoring case and extra spaces. */
export const normAnswer = (a) => String(a ?? '').trim().replace(/\s+/g, ' ').toLowerCase();
export const hashAnswer = (a) => hashPassword(normAnswer(a));
export const checkAnswer = (a, stored) => !!stored && checkPassword(normAnswer(a), stored);

// ---------- Rules (the hub shows the same ones live, from packages/core/src/accounts.ts) ----------
const squash = (s) => String(s ?? '').replace(/\s+/g, '').toLowerCase();
/** A new password: at least `min` characters, and not the username or display name. Null when fine. */
export function passwordProblem(pw, { username = '', name = '' } = {}, min = 6) {
  const p = String(pw ?? '');
  if (p.length < min) return `Use at least ${min} characters`;
  if (squash(p) === squash(username) || (name && squash(p) === squash(name))) return "Don't use your username or name as the password";
  return null;
}
/** Usernames: 2 to 32 letters, numbers, dots, dashes or underscores. Stored lower case. */
export const cleanUsername = (u) => String(u ?? '').trim().toLowerCase();
export function usernameProblem(u) {
  const s = cleanUsername(u);
  if (s.length < 2) return 'Use at least 2 characters for the username';
  if (s.length > 32) return 'Use at most 32 characters for the username';
  if (!/^[a-z0-9._-]+$/.test(s)) return 'Use only letters, numbers, dots, dashes or underscores in the username';
  return null;
}

// ---------- Sessions ----------
export function newToken(db, userId, days = 365, device = {}, ip = '') {
  const t = randomBytes(32).toString('base64url');
  const now = Date.now();
  db.data.tokens[sha(t)] = {
    userId, expires: now + days * 86400000, created: now, lastSeen: now, ip,
    device: { name: String(device.name ?? '').slice(0, 60), platform: String(device.platform ?? '').slice(0, 30), version: String(device.version ?? '').slice(0, 20) }
  };
  db.save();
  return t;
}
export function sessionFor(db, token) {
  if (!token) return null;
  const rec = db.data.tokens[sha(token)];
  const now = Date.now();
  if (!rec || rec.expires < now) return null;
  // Unused for a long time (a lost or forgotten device): signed out (security plan A5). In use, it stays signed in.
  const idle = (db.data.settings.idleDays ?? 90) * 86400000;
  if (rec.lastSeen && now - rec.lastSeen > idle) { delete db.data.tokens[sha(token)]; db.save(); return null; }
  const user = db.data.users[rec.userId];
  if (!user || user.disabled) return null;
  if (now - (rec.lastSeen ?? 0) > 60_000) rec.lastSeen = now;
  return { user, session: rec };
}
export function userFor(db, token) { return sessionFor(db, token)?.user ?? null; }
export function revoke(db, token) { delete db.data.tokens[sha(token)]; db.save(); }
/** Sign one account out of every device. */
export function revokeAll(db, userId) {
  for (const [k, v] of Object.entries(db.data.tokens)) if (v.userId === userId) delete db.data.tokens[k];
  db.save();
}
/** Drop sessions that ran out, so the list stays short. */
export function pruneTokens(db) {
  const now = Date.now();
  for (const [k, v] of Object.entries(db.data.tokens)) if (v.expires < now) delete db.data.tokens[k];
}
