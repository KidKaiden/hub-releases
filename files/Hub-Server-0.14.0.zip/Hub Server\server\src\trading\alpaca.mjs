// Trading: talking to Alpaca (the broker), from the PC server only. Paper (practice money) unless the owner has
// switched to real money himself. Keys are typed by the owner in Hub > Trading > Connect, at home, and kept in the
// Keys folder beside the project (never in git, never sent back, never logged). Alpaca's REST API v2:
// https://docs.alpaca.markets/reference (account, positions, orders, clock; market data for daily prices).
export const BASES = { paper: 'https://paper-api.alpaca.markets', live: 'https://api.alpaca.markets', data: 'https://data.alpaca.markets' };

export function alpaca({ key, secret, mode = 'paper', base, dataBase, fetchFn = fetch }) {
  const root = (base || BASES[mode === 'live' ? 'live' : 'paper']).replace(/\/+$/, '');
  const data = (dataBase || BASES.data).replace(/\/+$/, '');
  async function call(method, url, body) {
    const r = await fetchFn(url, {
      method,
      headers: { 'APCA-API-KEY-ID': key, 'APCA-API-SECRET-KEY': secret, accept: 'application/json', ...(body ? { 'content-type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(20_000)
    });
    const t = await r.text();
    let j = null;
    try { j = t ? JSON.parse(t) : null; } catch { j = null; }
    if (!r.ok) throw Object.assign(new Error(j?.message || `Alpaca said ${r.status}`), { status: r.status });
    return j;
  }
  const num = (v) => Number(v ?? 0);
  return {
    mode,
    async account() {
      const a = await call('GET', `${root}/v2/account`);
      return { id: a.id, status: a.status, currency: a.currency || 'USD', equity: num(a.equity), cash: num(a.cash), lastEquity: num(a.last_equity), buyingPower: num(a.buying_power),
        multiplier: num(a.multiplier || 1), shorting: !!a.shorting_enabled, blocked: !!(a.trading_blocked || a.account_blocked), patternDayTrader: !!a.pattern_day_trader };
    },
    async positions() {
      const list = await call('GET', `${root}/v2/positions`);
      return (list ?? []).map((p) => ({ symbol: p.symbol, qty: num(p.qty), value: num(p.market_value), cost: num(p.cost_basis), price: num(p.current_price), side: p.side, assetClass: p.asset_class, pl: num(p.unrealized_pl), plPct: num(p.unrealized_plpc) * 100 }));
    },
    async orders(status = 'all', limit = 50) {
      const list = await call('GET', `${root}/v2/orders?status=${status}&limit=${limit}&direction=desc`);
      return (list ?? []).map((o) => ({ id: o.id, symbol: o.symbol, side: o.side, qty: o.qty ? num(o.qty) : null, notional: o.notional ? num(o.notional) : null, filledQty: num(o.filled_qty), filledPrice: o.filled_avg_price ? num(o.filled_avg_price) : null, status: o.status, at: Date.parse(o.submitted_at || o.created_at) || Date.now(), clientId: o.client_order_id }));
    },
    // Plain market orders only, for the day: a dollar amount (fractional shares) for buys, a number of shares for sells
    submit({ symbol, side, notional, qty, clientId }) {
      const body = { symbol, side, type: 'market', time_in_force: 'day', ...(notional != null ? { notional: notional.toFixed(2) } : { qty: String(qty) }), ...(clientId ? { client_order_id: clientId } : {}) };
      return call('POST', `${root}/v2/orders`, body);
    },
    cancelAll() { return call('DELETE', `${root}/v2/orders`); },
    closeAll() { return call('DELETE', `${root}/v2/positions?cancel_orders=true`); },
    clock() { return call('GET', `${root}/v2/clock`).then((c) => ({ open: !!c.is_open, nextOpen: c.next_open, nextClose: c.next_close })); },
    async bars(symbol, days = 400) {
      const start = new Date(Date.now() - Math.ceil(days * 1.5) * 86_400_000).toISOString().slice(0, 10);
      const out = [];
      let token = null, n = 0;
      do {
        const q = new URLSearchParams({ timeframe: '1Day', start, limit: '1000', adjustment: 'all', feed: 'iex', ...(token ? { page_token: token } : {}) });
        const r = await call('GET', `${data}/v2/stocks/${encodeURIComponent(symbol)}/bars?${q}`);
        for (const b of r?.bars ?? []) out.push({ t: String(b.t).slice(0, 10), o: num(b.o), h: num(b.h), l: num(b.l), c: num(b.c) });
        token = r?.next_page_token || null;
      } while (token && ++n < 10);
      return out.slice(-days);
    },
    async lastPrice(symbol) {
      const r = await call('GET', `${data}/v2/stocks/${encodeURIComponent(symbol)}/trades/latest?feed=iex`);
      return num(r?.trade?.p);
    }
  };
}
