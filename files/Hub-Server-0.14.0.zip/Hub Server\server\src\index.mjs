// Start the ecosystem server: node src/index.mjs (or npm start in this folder).
import { loadConfig } from './config.mjs';
import { openDb } from './db.mjs';
import { openKeyring } from './keyring.mjs';
import { createApp } from './app.mjs';
import { lockedServer } from './locked.mjs';

const cfg = loadConfig();
// The master key (Windows locks it on the PC): the database, backups and the Keys folder are encrypted with it
const keys = openKeyring(cfg.dataDir);
if (keys.locked) {
  const port = await lockedServer(cfg, keys).start();
  console.log(`Hub is LOCKED (Windows couldn't open its key). On this PC open http://localhost:${port}/unlock and type the recovery key.`);
} else {
  const db = openDb(cfg.dataDir, { backupDir: cfg.backupDir, keep: cfg.backupDays, keys });
  const app = createApp(cfg, db);
  const port = await app.start();
  console.log(`Ecosystem server on port ${port}. Email: ${cfg.email.provider}, text: ${cfg.sms.provider}.`);
  console.log(`  Data:    ${cfg.dataDir} (encrypted, key ${keys.id}, ${keys.how === 'windows' ? 'locked by Windows' : 'NOT locked by Windows: not the home PC'})`);
  console.log(`  Backups: ${cfg.backupDir ?? cfg.dataDir + '\\backups'} (one a day, last ${cfg.backupDays} days, encrypted)`);
  console.log(`  Updates: ${cfg.updatesDir}`);
  if (!keys.recovery.has) console.log('  No recovery key yet: make one in Hub > Settings > Security and keep it safe');
  if (cfg.phoneDir) console.log(`  Phone app: ${cfg.phoneDir} (download on the phone at http://<this PC's address>:${port}/phone)`);
  if (cfg.webDir) console.log(`  Web Hub: ${cfg.webDir} (iPhone: Safari at http://<this PC's address>:${port}, then Add to Home Screen)`);
  for (const s of ['SIGINT', 'SIGTERM']) process.on(s, async () => { await app.stop(); process.exit(0); });
}
