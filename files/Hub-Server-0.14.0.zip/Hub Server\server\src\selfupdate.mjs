// Update this server from the Hub (Kaiden, 2026-11-14: "so I don't need to go to the files looking for the update
// file"). Hub > Updates shows this server's code, what's new on GitHub, and Update now. The work is done by
// tools/update-server.ps1, started in the background: get the code, packages, build the web Hub, restart, check
// the new server answers. If a step fails, or the new server doesn't answer, it goes back to the code it had.
// Only the owner, only after typing the password again, a backup first, and every update in the history.
import { execFile, spawn } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkPassword } from './auth.mjs';
import { record } from './history.mjs';
import { SERVER_VERSION } from './admin.mjs';

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = resolve(here, '..', '..');
const CHECK_EVERY = 6 * 3600_000;

const run = (cmd, args, cwd) => new Promise((ok) => {
  execFile(cmd, args, { cwd, timeout: 90_000, windowsHide: true, maxBuffer: 4 << 20 }, (e, stdout, stderr) => ok({ ok: !e, out: String(stdout ?? '').trim(), err: String(stderr ?? e?.message ?? '').trim() }));
});

/** The code this server started with (read once at start, so it says what's really running). */
export function startedCommit(root = ROOT) {
  try {
    const head = readFileSync(join(root, '.git', 'HEAD'), 'utf8').trim();
    if (!head.startsWith('ref:')) return head.slice(0, 7);
    const ref = head.slice(5).trim();
    const loose = join(root, '.git', ...ref.split('/'));
    if (existsSync(loose)) return readFileSync(loose, 'utf8').trim().slice(0, 7);
    const packed = readFileSync(join(root, '.git', 'packed-refs'), 'utf8').split('\n').find((l) => l.endsWith(` ${ref}`));
    return packed ? packed.slice(0, 7) : null;
  } catch { return null; }
}

export function selfUpdate(ctx, impl = {}) {
  const { db, cfg, log, stamp } = ctx;
  const root = impl.root ?? ROOT;
  const git = impl.git ?? ((...args) => run('git', args, root));
  const statusFile = join(cfg.dataDir, 'update-status.json');
  const commit = impl.commit ?? ctx.commit ?? startedCommit(root);
  let timer = null;

  const status = () => { try { return JSON.parse(readFileSync(statusFile, 'utf8').replace(/^﻿/, '')); } catch { return null; } };
  const running = () => { const s = status(); return s?.state === 'running' && Date.now() - (s.updated ?? 0) < 15 * 60_000; };

  /** Looks at GitHub (a fetch only: nothing changes here) and remembers what's new. */
  async function check() {
    const st = (db.data.serverUpdate ??= {});
    const f = await git('fetch', '--quiet', 'origin');
    st.checkedAt = Date.now();
    if (!f.ok) { st.error = 'Could not reach GitHub. Is the internet on?'; db.save(); return st; }
    const [head, up, list, dirty] = await Promise.all([
      git('rev-parse', '--short', 'HEAD'),
      git('rev-list', '--count', 'HEAD..@{u}'),
      git('log', '--format=%h%x09%ct%x09%s', '-n', '25', 'HEAD..@{u}'),
      git('status', '--porcelain', '-uno')
    ]);
    st.error = up.ok ? undefined : 'This folder is not following GitHub';
    st.head = head.out || null;
    st.behind = Number(up.out) || 0;
    st.changes = list.out ? list.out.split('\n').map((l) => { const [id, t, ...s] = l.split('\t'); return { id, at: Number(t) * 1000, text: s.join('\t').slice(0, 200) }; }) : [];
    // A changed package-lock.json is made by npm itself and is put back before updating; anything else blocks
    st.changed = dirty.out ? dirty.out.split('\n').map((l) => l.slice(3).trim()).filter((f) => f && f !== 'package-lock.json') : [];
    db.save();
    return st;
  }

  function info() {
    const st = db.data.serverUpdate ?? {};
    return {
      running: commit, version: SERVER_VERSION, checkedAt: st.checkedAt ?? null, error: st.error ?? null,
      head: st.head ?? null, behind: st.behind ?? 0, changes: st.changes ?? [], changed: st.changed ?? [],
      job: status(), busy: running(), available: impl.spawn ? true : process.platform === 'win32' && existsSync(join(root, '.git'))
    };
  }

  function start(u, ip) {
    const name = db.backupNow();
    record(db, { user: u.id, username: u.username, kind: 'admin', what: `updated the server (backup ${name} first)`, ip });
    log(`${stamp()} ${u.name} started a server update (backup ${name})`);
    const args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', join(root, 'tools', 'update-server.ps1'), '-Status', statusFile, '-Port', String(cfg.port)];
    if (impl.spawn) return impl.spawn(args);
    const child = spawn('powershell.exe', args, { cwd: root, detached: true, stdio: 'ignore', windowsHide: true });
    child.unref();
  }

  const owner = (fn) => (b, u, meta) => (db.data.roles[u.role]?.admin ? fn(b, u, meta) : [403, { error: 'Only the owner can do this', code: 'owner' }]);
  return {
    info, check,
    start() { timer = setInterval(() => check().catch(() => {}), CHECK_EVERY); timer.unref?.(); setTimeout(() => check().catch(() => {}), 60_000).unref?.(); },
    stop() { clearInterval(timer); },
    routes: {
      'GET /api/admin/server-update': owner(() => [200, info()]),
      'POST /api/admin/server-update/check': owner(async () => { await check(); return [200, info()]; }),
      'POST /api/admin/server-update': owner(async (b, u, { ip }) => {
        if (!checkPassword(String(b.password ?? ''), u.pw)) return [403, { error: 'That password is not right', field: 'password', code: 'password' }];
        if (!info().available) return [400, { error: 'Updating from the Hub works on the Windows PC that runs the server' }];
        if (running()) return [409, { error: 'An update is already running' }];
        const st = await check();
        if (st.error) return [502, { error: st.error }];
        if (!st.behind) return [200, { ...info(), note: 'Already up to date' }];
        if (st.changed.length) return [409, { error: `Files were changed on this PC (${st.changed.slice(0, 3).join(', ')}${st.changed.length > 3 ? '…' : ''}). Save them to GitHub first, then update`, code: 'changed' }];
        start(u, ip);
        return [200, { ...info(), busy: true, job: { state: 'running', steps: [], started: Date.now() } }];
      })
    }
  };
}
