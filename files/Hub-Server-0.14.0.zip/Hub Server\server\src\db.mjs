// The database (security plan A1 + B1, 2026-11-14): SQLite (built into Node, nothing to install), every part
// encrypted with the server's master key (keyring.mjs). Only what changed is written, in one step that survives a
// power cut. A copy each day in the backup folder (last `keep` days kept), also encrypted, carrying the key locked by
// the recovery key, so a backup and the recovery key are enough on a new PC.
// The rest of the server still sees one object (db.data) and calls save(): the parts that changed are worked out
// when saving, so nothing else had to change.
// The first start after the update moves an old db.json in (checked by reading it back), then wipes the plain
// files: db.json and the plain backups (they become encrypted backups first).
import {
  mkdirSync, readFileSync, writeFileSync, renameSync, existsSync, readdirSync, unlinkSync, statSync, utimesSync,
  openSync, writeSync, fsyncSync, closeSync
} from 'node:fs';
import { join } from 'node:path';
import { randomUUID, createHash } from 'node:crypto';
import { hostname } from 'node:os';
import { gzipSync, gunzipSync } from 'node:zlib';
import { DatabaseSync } from 'node:sqlite';
import { openKeyring, open, unwrapWithCode, idOf } from './keyring.mjs';

export const DB_VERSION = 3;
const EMPTY = () => ({
  version: DB_VERSION, seq: 0, users: {}, tokens: {}, recs: {}, links: [], messages: [],
  server: null, settings: {}, roles: {}, events: [], errors: [], friends: [], stats: {}
});
export const DEFAULT_SETTINGS = { passwordMin: 6, securityLevel: 'home', sessionDays: 365 };
/** Roles are data, so more can be added later without code changes elsewhere. */
export const DEFAULT_ROLES = { owner: { label: 'Owner', admin: true }, user: { label: 'User', admin: false } };

const stamp = () => new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
const slug = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9._-]+/g, '').slice(0, 32);

/** Brings an older database up to date. Never drops a user, a password hash or a record. */
export function migrate(input) {
  const data = { ...EMPTY(), ...input };
  if ((input.version ?? 1) < 2) {
    // 1 -> 2: accounts get usernames and roles (the oldest account becomes the owner)
    const taken = new Set();
    const users = Object.values(data.users).sort((a, b) => (a.created ?? 0) - (b.created ?? 0));
    const hasOwner = users.some((u) => u.role === 'owner');
    users.forEach((u, i) => {
      if (!u.username) {
        let base = slug(u.name) || slug(String(u.email ?? '').split('@')[0]) || 'user';
        if (base.length < 2) base = `${base}u`;
        let name = base, n = 2;
        while (taken.has(name) || users.some((o) => o !== u && o.username === name)) name = `${base}${n++}`;
        u.username = name;
      }
      taken.add(u.username);
      u.role ??= !hasOwner && i === 0 ? 'owner' : 'user';
    });
  }
  if ((input.version ?? 1) < 3 && data.settings?.passwordMin === 7) {
    // 2 -> 3: the shortest password is 6 (Kaiden, 2026-11-08; was 7). A minimum the owner changed stays as it is.
    data.settings = { ...data.settings, passwordMin: 6 };
  }
  data.version = DB_VERSION;
  data.server ??= { id: randomUUID(), name: `${hostname() || 'Home'} server`, created: Date.now() };
  data.settings = { ...DEFAULT_SETTINGS, ...data.settings };
  data.roles = { ...DEFAULT_ROLES, ...data.roles };
  data.friends = Array.isArray(data.friends) ? data.friends : [];
  data.stats = data.stats && typeof data.stats === 'object' ? data.stats : {};
  return data;
}

/** Writes and flushes to the disk before returning, so a sudden power-off can't leave a file of zeros
 * (that happened on 2026-11-10: db.json was all zeros after a restart and the server couldn't start). */
function writeDurable(path, data) {
  const fd = openSync(path, 'w');
  try { writeSync(fd, data); fsyncSync(fd); } finally { closeSync(fd); }
}
/** A plain file that held data: written over with zeros before it is removed (as far as a disk allows). */
export function wipe(path) {
  try { const n = statSync(path).size; writeDurable(path, Buffer.alloc(n)); unlinkSync(path); } catch { /* gone already */ }
}

/** Reads an old plain database file; null if it is missing, empty, zeros or not valid JSON. */
function readJson(path) {
  try {
    const text = readFileSync(path, 'utf8');
    if (!text.replace(/[\s\0]/g, '')) return null;
    const v = JSON.parse(text);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : null;
  } catch { return null; }
}

// ---------- Backups: HUBBAK1, a line of facts, then the encrypted, compressed database ----------
const MAGIC = 'HUBBAK1\n';
export function packBackup(keys, data) {
  const head = JSON.stringify({ v: 1, id: keys.id, made: Date.now(), recovery: keys.recoveryWrap });
  return Buffer.concat([Buffer.from(MAGIC + head + '\n'), keys.seal(gzipSync(JSON.stringify(data)), 'hub-backup')]);
}
/** A backup's database: with this server's key, or (one from another PC) with its recovery key. Old plain .json too. */
export function unpackBackup(buf, { keys, code } = {}) {
  const b = Buffer.from(buf);
  if (b.subarray(0, MAGIC.length).toString() !== MAGIC) {
    const text = b.toString('utf8');
    if (!text.replace(/[\s\0]/g, '')) throw new Error('That backup is empty');
    const v = JSON.parse(text);
    if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error("That file isn't a Hub backup");
    return v;
  }
  const nl = b.indexOf(10, MAGIC.length);
  const head = JSON.parse(b.subarray(MAGIC.length, nl).toString());
  let key = keys && !keys.locked && keys.id === head.id ? keys.key : null;
  if (!key) {
    if (!code) throw Object.assign(new Error('This backup is from another key: type its recovery key'), { code: 'needs-code' });
    if (!head.recovery) throw new Error("This backup has no recovery key, so it can only be opened on the PC that made it");
    try { key = unwrapWithCode(head.recovery, code); } catch { throw Object.assign(new Error('That recovery key is not right for this backup'), { code: 'wrong-code' }); }
    if (idOf(key) !== head.id) throw new Error('That recovery key is not right for this backup');
  }
  return JSON.parse(gunzipSync(open(key, b.subarray(nl + 1), 'hub-backup')).toString('utf8'));
}

// ---------- The database file ----------
const hash = (s) => createHash('sha1').update(s).digest('base64');
function openSql(file) {
  const sql = new DatabaseSync(file);
  try { sql.exec('SELECT count(*) FROM sqlite_master'); } catch (e) { sql.close(); throw e; }
  sql.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v BLOB NOT NULL); CREATE TABLE IF NOT EXISTS recs (k TEXT PRIMARY KEY, v BLOB NOT NULL);');
  return sql;
}
/** Everything in the database file, opened; with what each part was, to know later what changed. */
function readAll(sql, keys) {
  const data = {}, hashes = new Map();
  for (const { k, v } of sql.prepare('SELECT k, v FROM meta').all()) { const s = keys.open(v, `m:${k}`).toString('utf8'); data[k] = JSON.parse(s); hashes.set(`m:${k}`, hash(s)); }
  if (!Object.keys(data).length) return null;
  data.recs = {};
  for (const { k, v } of sql.prepare('SELECT k, v FROM recs').all()) { const s = keys.open(v, `r:${k}`).toString('utf8'); data.recs[k] = JSON.parse(s); hashes.set(`r:${k}`, hash(s)); }
  return { data, hashes };
}

/**
 * Opens the database in `dir` (hub.db). `keys` is the server's keyring (keyring.mjs); without one, a key kept in
 * the folder unlocked (tests, machines that aren't the home PC). Throws { code: 'locked' } when the key is locked.
 */
export function openDb(dir, { backupDir = join(dir, 'backups'), keep = 30, keys } = {}) {
  mkdirSync(dir, { recursive: true });
  mkdirSync(backupDir, { recursive: true });
  keys ??= openKeyring(dir, { lock: 'local' });
  if (keys.locked) throw Object.assign(new Error('The database key is locked: type the recovery key'), { code: 'locked' });
  const file = join(dir, 'hub.db');
  const legacy = join(dir, 'db.json');
  let raw = null, hashes = new Map(), sql = null, fromJson = false;

  if (existsSync(file)) {
    try { sql = openSql(file); const r = readAll(sql, keys); if (r) ({ data: raw, hashes } = r); }
    catch (e) {
      try { sql?.close(); } catch { /* already */ }
      sql = null;
      const broken = `db-broken-${stamp()}.db`;
      renameSync(file, join(backupDir, broken));
      for (const x of ['-wal', '-shm']) if (existsSync(file + x)) unlinkSync(file + x);
      console.error(`hub.db could not be read (${e.message}); kept as ${broken}.`);
    }
  }
  if (!raw && existsSync(legacy)) { raw = readJson(legacy); fromJson = !!raw; }
  const backupName = (f) => /^db-[\w-]+\.(json|hubbak)$/.test(f);
  if (!raw && (existsSync(legacy) || existsSync(join(backupDir, '.had-data')) || readdirSync(backupDir).some(backupName))) {
    // Damaged: keep it aside, then start from the newest backup that opens, instead of not starting at all
    if (existsSync(legacy)) { const broken = `db-broken-${stamp()}.json`; renameSync(legacy, join(backupDir, broken)); }
    const copies = readdirSync(backupDir).filter((f) => backupName(f) && !f.startsWith('db-broken-'))
      .map((name) => ({ name, time: statSync(join(backupDir, name)).mtimeMs })).sort((a, b) => b.time - a.time);
    const good = copies.find((c) => { try { raw = unpackBackup(readFileSync(join(backupDir, c.name)), { keys }); return true; } catch { return false; } });
    console.error(`The database could not be read; started from ${good ? good.name : 'an empty database'}.`);
  }
  raw ??= EMPTY();
  sql ??= openSql(file);

  if ((raw.version ?? 1) < DB_VERSION && Object.keys(raw.users ?? {}).length) {
    // Keep the old one as it was before changing its shape: this is what a roll back restores
    writeDurable(join(backupDir, `db-before-v${DB_VERSION}-${stamp()}.hubbak`), packBackup(keys, raw));
  }
  let data = migrate(raw);
  let timer = null;
  const upsert = { m: sql.prepare('INSERT INTO meta (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v'), r: sql.prepare('INSERT INTO recs (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v') };
  const remove = { m: sql.prepare('DELETE FROM meta WHERE k = ?'), r: sql.prepare('DELETE FROM recs WHERE k = ?') };

  /** Writes only the parts that changed since the last save, in one transaction. */
  function writeChanges() {
    const seen = new Set();
    const put = (kind, k, value) => {
      const id = `${kind}:${k}`;
      seen.add(id);
      const s = JSON.stringify(value);
      const h = hash(s);
      if (hashes.get(id) === h) return;
      upsert[kind].run(k, keys.seal(s, id));
      hashes.set(id, h);
    };
    sql.exec('BEGIN');
    try {
      for (const [k, v] of Object.entries(data)) if (k !== 'recs' && v !== undefined) put('m', k, v);
      for (const [k, v] of Object.entries(data.recs ?? {})) if (v !== undefined) put('r', k, v);
      for (const id of [...hashes.keys()]) if (!seen.has(id)) { remove[id[0]].run(id.slice(2)); hashes.delete(id); }
      sql.exec('COMMIT');
    } catch (e) { sql.exec('ROLLBACK'); hashes = new Map(); throw e; }
  }

  const isBackup = backupName;
  function saveNow() {
    clearTimeout(timer); timer = null;
    writeChanges();
    const day = new Date().toISOString().slice(0, 10);
    const bk = join(backupDir, `db-${day}.hubbak`);
    if (!existsSync(bk) && Object.keys(data.users).length) {
      writeDurable(bk, packBackup(keys, data));
      writeFileSync(join(backupDir, '.had-data'), '');
      const all = readdirSync(backupDir).filter((f) => /^db-\d{4}-\d\d-\d\d\.(json|hubbak)$/.test(f)).sort();
      for (const f of all.slice(0, -keep)) unlinkSync(join(backupDir, f));
    }
  }

  // Moved in from db.json: write it all, read it back to be sure, then the plain files go
  if (fromJson || !hashes.size) saveNow();
  if (fromJson) {
    const back = readAll(sql, keys)?.data;
    if (!back || JSON.stringify(back.recs) !== JSON.stringify(data.recs) || JSON.stringify(back.users) !== JSON.stringify(data.users)) {
      throw new Error('Moving the database into hub.db did not read back the same: db.json is kept as it was');
    }
    writeDurable(join(backupDir, `db-before-encryption-${stamp()}.hubbak`), packBackup(keys, data));
    wipe(legacy);
    console.log('The database is now encrypted (hub.db). The old plain db.json was wiped.');
  }
  // Plain backups (from before) become encrypted ones, keeping their dates; the plain copies are wiped
  for (const f of readdirSync(backupDir).filter((x) => x.endsWith('.json') && x.startsWith('db-'))) {
    const p = join(backupDir, f);
    const v = readJson(p);
    const t = statSync(p);
    // One that can't be read is kept (it may be saved by hand), but encrypted too
    const to = v ? p.replace(/\.json$/, '.hubbak') : `${p}.enc`;
    writeDurable(to, v ? packBackup(keys, v) : keys.seal(readFileSync(p), 'hub-broken'));
    utimesSync(to, t.atime, t.mtime);
    wipe(p);
  }
  for (const f of readdirSync(dir).filter((x) => /^db-(corrupt|broken)-.*\.json$/.test(x))) {
    const p = join(dir, f);
    const v = readJson(p);
    if (v) writeDurable(join(backupDir, f.replace(/\.json$/, '.hubbak')), packBackup(keys, v));
    wipe(p);
  }

  return {
    get data() { return data; },
    keys,
    save() { if (!timer) timer = setTimeout(saveNow, 200); },
    saveNow,
    nextSeq() { return ++data.seq; },
    /** Every copy in the backup folder, newest first. */
    backups() {
      return readdirSync(backupDir).filter(isBackup).map((name) => {
        const st = statSync(join(backupDir, name));
        return { name, size: st.size, time: st.mtimeMs };
      }).sort((a, b) => b.time - a.time);
    },
    /** A copy now (kept apart from the daily ones; the newest 20 are kept). */
    backupNow() {
      saveNow();
      const name = `db-manual-${stamp()}.hubbak`;
      writeDurable(join(backupDir, name), packBackup(keys, data));
      const manual = readdirSync(backupDir).filter((f) => f.startsWith('db-manual-')).sort();
      for (const f of manual.slice(0, -20)) unlinkSync(join(backupDir, f));
      return name;
    },
    backupPath(name) { return isBackup(name) ? join(backupDir, name) : null; },
    /** Roll back to a backup (one from another PC needs its recovery key). What is here now is saved first. */
    restore(name, code) {
      if (!isBackup(name) || !existsSync(join(backupDir, name))) throw new Error('No such backup');
      const incoming = unpackBackup(readFileSync(join(backupDir, name)), { keys, code });
      writeDurable(join(backupDir, `db-before-restore-${stamp()}.hubbak`), packBackup(keys, data));
      data = migrate(incoming);
      saveNow();
    },
    /** A backup file brought from elsewhere (another PC): put in the backup folder, then restore as above. */
    addBackup(buf) {
      const name = `db-imported-${stamp()}.hubbak`;
      writeDurable(join(backupDir, name), buf);
      return name;
    },
    close() { clearTimeout(timer); try { sql.close(); } catch { /* closed */ } },
    file
  };
}
