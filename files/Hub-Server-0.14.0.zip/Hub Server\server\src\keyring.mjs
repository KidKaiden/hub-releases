// The server's master key (security plan A1, 2026-11-14). One random key encrypts the database, every backup and
// the Keys folder (AES-256-GCM). The key itself is kept in HUB\Data\hub.key, locked by Windows (DPAPI, tied to
// Kaiden's Windows account) so the server starts by itself after a restart. A recovery key (shown once, kept by
// Kaiden) also unlocks it: the only way back if Windows is reinstalled or the PC dies. Backups carry the key locked
// by the recovery key, so a backup plus the recovery key is everything needed on a new PC.
// Away from Windows (tests, a Chromebook) the key is kept unlocked in the file ("local"), and says so.
import { randomBytes, createCipheriv, createDecipheriv, scryptSync, createHash, timingSafeEqual } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync, renameSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';

const SECRET = 'HUBENC1:'; // marks an encrypted file in the Keys folder
const ALPHA = 'ABCDEFGHJKMNPQRSTVWXYZ23456789'; // no 0/O, 1/I/L, U
const SCRYPT = { N: 1 << 15, r: 8, p: 1, maxmem: 128 << 20 };

/** AES-256-GCM: iv (12) | tag (16) | data. `aad` ties the box to where it belongs (a record can't be moved). */
export function seal(key, plain, aad = '') {
  const iv = randomBytes(12);
  const c = createCipheriv('aes-256-gcm', key, iv);
  if (aad) c.setAAD(Buffer.from(aad));
  const ct = Buffer.concat([c.update(Buffer.isBuffer(plain) ? plain : Buffer.from(String(plain))), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), ct]);
}
export function open(key, box, aad = '') {
  const b = Buffer.from(box);
  const d = createDecipheriv('aes-256-gcm', key, b.subarray(0, 12));
  if (aad) d.setAAD(Buffer.from(aad));
  d.setAuthTag(b.subarray(12, 28));
  return Buffer.concat([d.update(b.subarray(28)), d.final()]);
}

/** A recovery key: 25 letters and numbers in five groups (about 120 bits), easy to write down and type. */
export function newRecoveryCode() {
  const b = randomBytes(25);
  const s = [...b].map((x) => ALPHA[x % ALPHA.length]).join('');
  return s.match(/.{5}/g).join('-');
}
export const cleanCode = (c) => String(c ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '');

/** The master key locked by a recovery key (kept in hub.key and in every backup). */
export function wrapWithCode(master, code, N = SCRYPT.N) {
  const salt = randomBytes(16);
  const k = scryptSync(cleanCode(code), salt, 32, { ...SCRYPT, N });
  return { salt: salt.toString('base64'), box: seal(k, master, 'hub-recovery').toString('base64'), check: idOf(master), N };
}
export function unwrapWithCode(wrap, code) {
  const k = scryptSync(cleanCode(code), Buffer.from(wrap.salt, 'base64'), 32, { ...SCRYPT, N: wrap.N ?? SCRYPT.N });
  return open(k, Buffer.from(wrap.box, 'base64'), 'hub-recovery'); // throws when the code is wrong
}
/** A short name for a key (never the key): tells backups and key files apart */
export const idOf = (key) => createHash('sha256').update(key).update('hub-key-id').digest('hex').slice(0, 12);

// Windows DPAPI through PowerShell (Node has no DPAPI of its own). Only ever the key goes through, via stdin.
const ps = (script, input) => execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { input, encoding: 'utf8', windowsHide: true, timeout: 30_000 }).trim();
const DPAPI = (op) => `Add-Type -AssemblyName System.Security; $b=[Convert]::FromBase64String([Console]::In.ReadToEnd().Trim()); [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::${op}($b,$null,'CurrentUser'))`;
export const windowsLock = {
  available: () => process.platform === 'win32',
  protect: (key) => ps(DPAPI('Protect'), key.toString('base64')),
  unprotect: (text) => Buffer.from(ps(DPAPI('Unprotect'), text), 'base64')
};

/**
 * Opens (or makes, the first time) the master key in `dir`/hub.key.
 *   lock: 'windows' (the real server) or 'local' (tests and machines that aren't the home PC)
 * Returns { key, id, locked, how, recovery: { has, made }, makeRecovery(), unlock(code), readSecret(), writeSecret() }.
 * `locked` is true when the key exists but Windows can't open it (a new Windows, a different account): then only
 * the recovery key opens it.
 */
export function openKeyring(dir, { lock = windowsLock.available() ? 'windows' : 'local', win = windowsLock } = {}) {
  mkdirSync(dir, { recursive: true });
  const file = join(dir, 'hub.key');
  let doc = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : null;
  let key = null;
  const write = () => { writeFileSync(file + '.tmp', JSON.stringify(doc, null, 1)); renameSync(file + '.tmp', file); };
  const lockKey = (k) => (lock === 'windows' ? { dpapi: win.protect(k) } : { local: k.toString('base64') });

  if (!doc) {
    key = randomBytes(32);
    doc = { v: 1, id: idOf(key), made: Date.now(), ...lockKey(key), recovery: null };
    write();
  } else {
    try {
      if (doc.dpapi && lock === 'windows') key = win.unprotect(doc.dpapi);
      else if (doc.local) key = Buffer.from(doc.local, 'base64');
      if (key && idOf(key) !== doc.id) key = null;
      // A key that was made away from Windows gets Windows' lock once it runs on the home PC
      if (key && lock === 'windows' && !doc.dpapi) { doc = { ...doc, ...lockKey(key), local: undefined }; write(); }
    } catch { key = null; }
  }

  const ring = {
    get key() { return key; },
    get id() { return doc.id; },
    get locked() { return !key; },
    how: lock,
    get recovery() { return { has: !!doc.recovery, made: doc.recovery?.made ?? null }; },
    /** The master key locked by the recovery key, to put in each backup (null until one is made) */
    get recoveryWrap() { return doc.recovery ? { salt: doc.recovery.salt, box: doc.recovery.box, check: doc.recovery.check, N: doc.recovery.N } : null; },
    /** A new recovery key (the old one stops working). Shown once; only its lock is kept. */
    makeRecovery() {
      const code = newRecoveryCode();
      // Away from the home PC (tests) a lighter lock: those keys never guard real data
      doc.recovery = { ...wrapWithCode(key, code, lock === 'windows' ? SCRYPT.N : 1 << 10), made: Date.now() };
      delete doc.pending;
      write();
      return code;
    },
    /** The recovery key made by itself on the first start, until the owner says it's saved (then only its lock stays) */
    get pendingCode() { try { return doc.pending ? open(key, Buffer.from(doc.pending, 'base64'), 'hub-pending').toString() : null; } catch { return null; } },
    markPending(code) { doc.pending = seal(key, code, 'hub-pending').toString('base64'); write(); },
    confirmSaved() { delete doc.pending; doc.recovery && (doc.recovery.saved = Date.now()); write(); },
    get saved() { return !!doc.recovery?.saved; },
    /** Locked: the recovery key opens it, and Windows locks it again for next time. False when the code is wrong. */
    unlock(code) {
      if (!doc.recovery) return false;
      try {
        const k = unwrapWithCode(doc.recovery, code);
        if (idOf(k) !== doc.id) return false;
        key = k; doc = { ...doc, ...lockKey(k) }; write();
        return true;
      } catch { return false; }
    },
    seal: (plain, aad) => seal(key, plain, aad),
    open: (box, aad) => open(key, box, aad),
    /** A file in the Keys folder, encrypted. An older plain file is read once and encrypted in place. */
    readSecret(path) {
      if (!existsSync(path)) return null;
      const raw = readFileSync(path, 'utf8');
      if (!raw.startsWith(SECRET)) { if (key) ring.writeSecret(path, raw); return raw; }
      return open(key, Buffer.from(raw.slice(SECRET.length).trim(), 'base64'), 'hub-secret').toString('utf8');
    },
    writeSecret(path, text) {
      writeFileSync(path + '.tmp', SECRET + seal(key, text, 'hub-secret').toString('base64'));
      renameSync(path + '.tmp', path);
    },
    /** True when the code matches this key (for "check your recovery key") */
    checkCode(code) {
      if (!doc.recovery) return false;
      try { const k = unwrapWithCode(doc.recovery, code); return k.length === key.length && timingSafeEqual(k, key); } catch { return false; }
    }
  };
  // There is always a recovery key from the first start, so the data is never only behind Windows' lock. Until the
  // owner has written it down (Hub > Settings > Security), it is kept here, locked by the master key, to show them.
  if (key && !doc.recovery) {
    ring.markPending(ring.makeRecovery());
  }
  return ring;
}
export const isSecretFile = (text) => String(text).startsWith(SECRET);
