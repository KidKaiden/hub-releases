# Hub Server: keeps it running. Starts the server, and starts it again if it ever stops.
# Windows runs this hidden when you sign in (set up by setup.ps1). The log is in <your Hub Server folder>\Data\server.log
param([Parameter(Mandatory = $true)][string]$Root)
$ErrorActionPreference = 'Continue'
$server = Join-Path $Root 'app\server'
$dataDir = Join-Path $Root 'Data'
New-Item -ItemType Directory -Force $dataDir | Out-Null
$log = Join-Path $dataDir 'server.log'
function Note($t) { [IO.File]::AppendAllText($log, "$(Get-Date -Format s) $t`r`n") }
$env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) { Note 'Node.js not found; the server did not start. Run "Set up Hub Server" again.'; exit 1 }

$port = 8787
$m = Select-String -Path (Join-Path $server '.env') -Pattern '^\s*PORT\s*=\s*(\d+)' -ErrorAction SilentlyContinue | Select-Object -First 1
if ($m) { $port = [int]$m.Matches[0].Groups[1].Value }

while ($true) {
  if ((Test-Path $log) -and (Get-Item $log).Length -gt 5MB) { Move-Item $log "$log.old" -Force }
  if (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue) { Start-Sleep 60; continue }
  Note 'starting'
  $p = Start-Process cmd.exe -ArgumentList "/d /c `"`"$node`" src\index.mjs >> `"$log`" 2>&1`"" -WorkingDirectory $server -WindowStyle Hidden -PassThru -Wait
  Note "stopped (code $($p.ExitCode)), starting again in 10 seconds"
  Start-Sleep 10
}
