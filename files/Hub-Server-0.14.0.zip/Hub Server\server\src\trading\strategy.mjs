// Trading: the strategy. Code makes the signals, never the AI (Kaiden's rule, 2026-11-11): a moving-average
// crossover on daily closes. A fast average crossing above the slow one says "buy"; crossing back below says "sell".
// Plain functions, tested in server/test/trading.test.mjs. Bars: [{ t: 'YYYY-MM-DD', o, h, l, c }], oldest first.

export const DEFAULT_STRATEGY = { kind: 'sma-cross', fast: 20, slow: 50 };

export function sma(values, n) {
  const out = new Array(values.length).fill(null);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= n) sum -= values[i - n];
    if (i >= n - 1) out[i] = sum / n;
  }
  return out;
}

/** The signal on each day (null on most days): 'buy' when fast crosses above slow, 'sell' when it crosses below. */
export function signals(bars, { fast = 20, slow = 50 } = {}) {
  const c = bars.map((b) => b.c);
  const f = sma(c, fast), s = sma(c, slow);
  return bars.map((_, i) => {
    if (i === 0 || f[i] == null || s[i] == null || f[i - 1] == null || s[i - 1] == null) return null;
    if (f[i - 1] <= s[i - 1] && f[i] > s[i]) return 'buy';
    if (f[i - 1] >= s[i - 1] && f[i] < s[i]) return 'sell';
    return null;
  });
}

/** Where things stand on the last day: the trend (fast above slow = up), and today's signal if there is one. */
export function latest(bars, cfg = DEFAULT_STRATEGY) {
  if (bars.length < cfg.slow + 1) return { signal: null, trend: null, why: `Needs ${cfg.slow + 1} days of prices (has ${bars.length})` };
  const sig = signals(bars, cfg);
  const c = bars.map((b) => b.c);
  const f = sma(c, cfg.fast).at(-1), s = sma(c, cfg.slow).at(-1);
  const last = bars.at(-1);
  return {
    signal: sig.at(-1), trend: f > s ? 'up' : 'down', day: last.t, close: last.c, fast: round(f), slow: round(s),
    why: `${cfg.fast}-day average ${round(f)} is ${f > s ? 'above' : 'below'} the ${cfg.slow}-day average ${round(s)}${sig.at(-1) ? ` and crossed today: ${sig.at(-1)}` : ''}`
  };
}

/** How far this stock usually jumps overnight (open against the day before's close): the 90th percentile, as a
 *  fraction. Used as an extra buffer on top of the stop loss, because a stop can be skipped past when it jumps. */
export function gapSize(bars, days = 120) {
  const g = [];
  for (let i = Math.max(1, bars.length - days); i < bars.length; i++) if (bars[i - 1].c > 0) g.push(Math.abs(bars[i].o / bars[i - 1].c - 1));
  if (g.length < 10) return 0.02;
  g.sort((a, b) => a - b);
  return Math.min(0.25, Math.max(0.002, g[Math.floor(g.length * 0.9)]));
}

const round = (v) => Math.round(v * 100) / 100;

/** Made-up practice prices (a seeded random walk), for trying the backtest before a broker is connected. Always
 *  labelled as made up wherever it's shown. */
export function practiceBars(symbol, days = 500, end = new Date()) {
  let seed = [...symbol].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) >>> 0, 7);
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
  const drift = symbol === 'SPY' ? 0.0004 : 0.0002 + (rnd() - 0.5) * 0.0008, vol = symbol === 'SPY' ? 0.01 : 0.014 + rnd() * 0.012;
  let p = 50 + rnd() * 300;
  const out = [];
  const d = new Date(end); d.setUTCHours(0, 0, 0, 0);
  const dates = [];
  while (dates.length < days) { if (d.getUTCDay() % 6 !== 0) dates.unshift(d.toISOString().slice(0, 10)); d.setUTCDate(d.getUTCDate() - 1); }
  for (const t of dates) {
    const gap = (rnd() - 0.5) * vol * 0.8;
    const o = p * (1 + gap);
    const move = drift + (rnd() - 0.5) * 2 * vol + (rnd() < 0.02 ? (rnd() - 0.6) * vol * 6 : 0);
    const c = Math.max(1, o * (1 + move));
    const h = Math.max(o, c) * (1 + rnd() * vol * 0.6), l = Math.min(o, c) * (1 - rnd() * vol * 0.6);
    out.push({ t, o: round(o), h: round(h), l: round(l), c: round(c) });
    p = c;
  }
  return out;
}
