// Plain files the server hands out without sign-in: PC app updates, the Android app, and the web Hub.
// None of them hold secrets: the apps check every update's signature themselves.
import { createReadStream, statSync, readdirSync } from 'node:fs';
import { join, resolve, sep, extname } from 'node:path';
import { stamp, addr } from './history.mjs';

export const apkVer = (f) => f.match(/^Hub-(\d+)\.(\d+)\.(\d+)\.apk$/)?.slice(1).map(Number);
export function newestApk(dir) {
  let files = [];
  try { files = readdirSync(dir ?? '').filter((f) => apkVer(f)); } catch { /* no folder yet */ }
  return files.sort((a, b) => { const x = apkVer(a), y = apkVer(b); return x[0] - y[0] || x[1] - y[1] || x[2] - y[2]; }).at(-1);
}

const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.txt': 'text/plain; charset=utf-8', '.wasm': 'application/wasm' };

export function fileRoutes(cfg, log, notFound) {
  // PC app updates and the release notes: plain files from the updates folder
  function update(req, res, name) {
    if (!/^[\w][\w.\-]*$/.test(name) || !cfg.updatesDir) return notFound(res);
    const file = join(cfg.updatesDir, name);
    let st;
    try { st = statSync(file); } catch { return notFound(res, 'No update here'); }
    if (!st.isFile()) return notFound(res);
    res.writeHead(200, {
      'content-type': name.endsWith('.json') ? 'application/json' : name.endsWith('.apk') ? 'application/vnd.android.package-archive' : 'application/octet-stream',
      'content-length': st.size, 'cache-control': 'no-store', 'access-control-allow-origin': '*'
    });
    if (req.method === 'HEAD') return res.end();
    createReadStream(file).pipe(res);
  }

  // The Android app for a phone on the home Wi-Fi: http://<PC address>:8787/phone is a page with a download
  // button and the install steps; /phone/Hub-<version>.apk is the file. Each visit is logged with the phone's
  // address, so the PC shows whether the phone got there.
  function phonePage(req, res) {
    const name = newestApk(cfg.phoneDir);
    log(`${stamp()} phone page opened from ${addr(req.socket.remoteAddress)}${name ? '' : ' (no app built yet)'}`);
    const mb = name ? (statSync(join(cfg.phoneDir, name)).size / 1048576).toFixed(1) : '';
    const host = String(req.headers.host ?? '').replace(/[^\w.:\-\[\]]/g, '');
    const html = `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Hub for Android</title>
<style>
:root{color-scheme:dark}body{margin:0;font:17px/1.5 system-ui,sans-serif;background:#16121F;color:#EEEAF6}
main{max-width:520px;margin:0 auto;padding:28px 20px 40px}h1{font-size:26px;margin:0 0 4px}
.sub{color:#A79FBA;margin:0 0 22px}.btn{display:block;text-align:center;padding:16px;border-radius:14px;
background:#8B5CF6;color:#fff;font-weight:600;font-size:19px;text-decoration:none}
ol{padding-left:22px;margin:26px 0 0}li{margin:0 0 14px}b{color:#fff}.note{color:#A79FBA;font-size:15px;margin-top:22px}
</style></head><body><main>
<h1>Hub for Android</h1>
${name ? `<p class="sub">Version ${name.slice(4, -4)}, ${mb} MB. Your phone reached the PC.</p>
<a class="btn" href="/phone/${name}" download>Download Hub</a>
<ol>
<li>Tap <b>Download Hub</b>. If Chrome warns the file might be harmful or isn't secure, tap <b>Download anyway</b> (it's your own app, from your PC).</li>
<li>When it finishes, tap <b>Open</b>. If the phone asks, switch on <b>Allow from this source</b> for Chrome, then go back.</li>
<li>Tap <b>Install</b> (or <b>Update</b>). If Play Protect asks, tap <b>More details</b> then <b>Install anyway</b>.</li>
<li>Blocked by <b>Auto Blocker</b>? Settings &gt; Security and privacy &gt; Auto Blocker: turn it off, install, then turn it back on.</li>
</ol>
<p class="note">Then open Hub. The server address is <b>http://${host}</b>. Sign in with your username and password.</p>`
    : `<p class="sub">Your phone reached the PC, but there's no Android app built yet.</p>`}
</main></body></html>`;
    res.writeHead(name ? 200 : 404, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    res.end(req.method === 'HEAD' ? undefined : html);
  }
  function phoneFile(req, res, name) {
    let st;
    try { st = apkVer(name) && statSync(join(cfg.phoneDir ?? '', name)); } catch { /* not there */ }
    if (!st?.isFile?.()) return notFound(res);
    if (req.method === 'GET') log(`${stamp()} phone app ${name} sent to ${addr(req.socket.remoteAddress)}`);
    res.writeHead(200, {
      'content-type': 'application/vnd.android.package-archive',
      'content-disposition': `attachment; filename="${name}"`,
      'content-length': st.size, 'cache-control': 'no-store', 'access-control-allow-origin': '*'
    });
    if (req.method === 'HEAD') return res.end();
    createReadStream(join(cfg.phoneDir, name)).pipe(res);
  }

  // The web Hub (apps/hub built, in WEB_DIR) at http://<PC address>:8787/, for iPhones and browsers.
  // Only files inside that folder; the bundle holds no secrets (the same as in the apps).
  function web(req, res, path) {
    const root = cfg.webDir;
    let file;
    try { file = resolve(root, '.' + decodeURIComponent(path === '/' ? '/index.html' : path)); } catch { return notFound(res); }
    if (!file.startsWith(root + sep) || /[\\/]\./.test(file.slice(root.length))) return notFound(res);
    let st;
    try { st = statSync(file); } catch { /* not there */ }
    if (!st?.isFile()) {
      // Paths with no file ending open the app itself (it routes with #, so this is only a safety net)
      if (extname(path)) return notFound(res);
      file = join(root, 'index.html');
      try { st = statSync(file); } catch { return notFound(res, 'Hub web version not built yet'); }
    }
    res.writeHead(200, {
      'content-type': types[extname(file).toLowerCase()] ?? 'application/octet-stream',
      'content-length': st.size,
      // Built files have a hash in their name and never change; everything else is checked each time
      'cache-control': /[\\/]assets[\\/]/.test(file.slice(root.length)) ? 'public, max-age=31536000, immutable' : 'no-cache'
    });
    if (req.method === 'HEAD') return res.end();
    createReadStream(file).pipe(res);
  }

  /** Handles the request if it is for a plain file; returns false otherwise. */
  return function files(req, res, path) {
    const read = req.method === 'GET' || req.method === 'HEAD';
    if (!read) return false;
    if (path.startsWith('/updates/')) { update(req, res, path.slice(9)); return true; }
    if (path === '/phone' || path === '/phone/') { phonePage(req, res); return true; }
    if (path.startsWith('/phone/')) { phoneFile(req, res, path.slice(7)); return true; }
    if (cfg.webDir && !path.startsWith('/api/')) { web(req, res, path); return true; }
    return false;
  };
}
