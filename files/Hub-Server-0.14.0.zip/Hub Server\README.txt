HUB SERVER: your own Hub, for your family or group
====================================================

1. Unzip this folder anywhere (right-click > Extract All).
2. Double-click "Set up Hub Server.cmd" and answer its questions. Why: it puts the server on this PC, makes it
   start with Windows, and opens Hub so you can make your account.
3. The first account you make is the owner: unlimited space and your own Admin. Make everyone else's account in
   Admin > People.

What it shares with the main Hub: its name, your name, how many people it has, and its version. Never accounts,
messages, notes, tasks or money.

Update: download the newer Hub Server and run "Set up Hub Server.cmd" again. People, data and settings are kept,
and the version before stays in the app.old folder.
Stop it: "Set up Hub Server.cmd" -Remove (from a command window), or delete the "Hub Server" shortcut in your
Startup folder. Your data stays in the Data folder.
