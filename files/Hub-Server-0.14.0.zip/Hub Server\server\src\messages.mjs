// Scheduled texts and emails to other people. Queued on the server, so they go out at the right
// time even when the sender's phone is off. While the server itself is off, they wait and go out
// as soon as it starts again (late ones are marked late, never dropped silently).
const MAX_TRIES = 5;

export function providers(cfg, log = console.log) {
  const email = {
    async console(m) { log(`[email to ${m.to.email}] ${m.body}`); },
    async brevo(m) {
      if (!cfg.email.brevoKey) throw new Error('BREVO_API_KEY not set');
      const from = parseFrom(cfg.email.from);
      const r = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST', headers: { 'api-key': cfg.email.brevoKey, 'content-type': 'application/json', accept: 'application/json' },
        body: JSON.stringify({ sender: from, to: [{ email: m.to.email, name: m.to.name }], subject: m.subject ?? 'Reminder', textContent: m.body })
      });
      if (!r.ok) throw new Error(`Brevo ${r.status}: ${await r.text()}`);
    },
    async resend(m) {
      if (!cfg.email.resendKey) throw new Error('RESEND_API_KEY not set');
      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST', headers: { authorization: `Bearer ${cfg.email.resendKey}`, 'content-type': 'application/json' },
        body: JSON.stringify({ from: cfg.email.from, to: [m.to.email], subject: m.subject ?? 'Reminder', text: m.body })
      });
      if (!r.ok) throw new Error(`Resend ${r.status}: ${await r.text()}`);
    }
  };
  const sms = {
    async console(m) { log(`[text to ${m.to.phone}] ${m.body}`); },
    async twilio(m) {
      const { twilioSid: sid, twilioToken: tok, from } = cfg.sms;
      if (!sid || !tok || !from) throw new Error('Twilio settings missing');
      const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
        method: 'POST',
        headers: { authorization: 'Basic ' + Buffer.from(`${sid}:${tok}`).toString('base64'), 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ To: m.to.phone, From: from, Body: m.body })
      });
      if (!r.ok) throw new Error(`Twilio ${r.status}: ${await r.text()}`);
    },
    async brevo(m) {
      if (!cfg.sms.brevoKey || !cfg.sms.from) throw new Error('Brevo SMS settings missing');
      const r = await fetch('https://api.brevo.com/v3/transactionalSMS/sms', {
        method: 'POST', headers: { 'api-key': cfg.sms.brevoKey, 'content-type': 'application/json' },
        body: JSON.stringify({ sender: cfg.sms.from, recipient: m.to.phone, content: m.body, type: 'transactional' })
      });
      if (!r.ok) throw new Error(`Brevo SMS ${r.status}: ${await r.text()}`);
    }
  };
  return {
    send(m) {
      const fn = m.channel === 'email' ? email[cfg.email.provider] : sms[cfg.sms.provider];
      if (!fn) throw new Error(`Unknown ${m.channel} provider`);
      return fn(m);
    }
  };
}

function parseFrom(s) {
  const m = String(s).match(/^(.*)<(.+)>$/);
  return m ? { name: m[1].trim(), email: m[2].trim() } : { email: s };
}

export function validMessage(m) {
  if (!m || !['email', 'text', 'push'].includes(m.channel)) return 'Channel must be email, text or push';
  if (typeof m.body !== 'string' || !m.body.trim() || m.body.length > 1000) return 'Message must be 1 to 1000 characters';
  if (m.channel === 'email' && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(m.to?.email ?? '')) return 'A valid email address is needed';
  if (m.channel === 'text' && !/^\+[1-9]\d{6,14}$/.test(m.to?.phone ?? '')) return 'Phone numbers need the country code, like +447700900123';
  if (!Number.isFinite(m.sendAt)) return 'sendAt must be a time in milliseconds (UTC)';
  return null;
}

/** Send everything that is due. Returns how many went out. */
export async function tick(db, send, now = Date.now()) {
  let n = 0;
  for (const m of db.data.messages) {
    if (m.status !== 'queued' || m.sendAt > now || (m.retryAt && m.retryAt > now)) continue;
    try {
      await send(m);
      m.status = 'sent'; m.sentAt = Date.now(); m.late = now - m.sendAt > 10 * 60_000; n++;
    } catch (e) {
      m.tries = (m.tries ?? 0) + 1;
      m.error = String(e.message ?? e).slice(0, 300);
      if (m.tries >= MAX_TRIES) m.status = 'failed';
      else m.retryAt = now + 60_000 * 2 ** m.tries;
    }
    db.save();
  }
  return n;
}
