// The assistant connection: tasks and notes an AI assistant adds from a chat land straight in To Do and Notes
// (marked "from assistant", with Undo in the apps). The assistant can also edit, complete, move and delete them.
// Two swappable adapters feed the same inbox:
//  - Notion: the assistant writes rows in a Notion "Inbox" database; this server polls it every few minutes and
//    when an app opens, turns new rows into tasks or notes, and sends edits and completions back (deletions soft).
//  - HTTP inbox: POST /api/inbox with a personal inbox token (any assistant or script that can reach the server).
// The Notion token and database id live in server/.env (NOTION_TOKEN, NOTION_DATABASE_ID) or are set by the owner
// in Hub > Settings > Assistant (kept in the server's data folder). Never in git.
import { randomBytes, randomUUID, createHash } from 'node:crypto';
import { record, stamp } from './history.mjs';
import { findUser } from './accounts.mjs';

const sha = (s) => createHash('sha256').update(String(s)).digest('hex');
const POLL_MS = 3 * 60_000;

// ---------- One item in, whatever the source ----------
const TIER = { 'not urgent': 0, urgent: 1, 'very important': 2, asap: 3 };
export const tierOf = (v) => {
  const s = String(v ?? '').trim().toLowerCase();
  if (/^[0-3]$/.test(s)) return +s;
  return TIER[s] ?? (/asap|now|critical/.test(s) ? 3 : /very|high/.test(s) ? 2 : /urgent|soon/.test(s) ? 1 : 0);
};
export const TIER_NAMES = ['Not urgent', 'Urgent', 'Very important', 'ASAP'];
/** A date (YYYY-MM-DD, or a full date-time) to UTC ms; plain dates mean 09:00 on the server's (home) clock. */
export function dueOf(v) {
  if (!v) return { due: undefined, timed: false };
  const s = String(v);
  const m = s.match(/^(\d{4})-(\d\d)-(\d\d)$/);
  if (m) return { due: new Date(+m[1], +m[2] - 1, +m[3], 9).getTime(), timed: false };
  const t = Date.parse(s);
  return Number.isNaN(t) ? { due: undefined, timed: false } : { due: t, timed: true };
}
const ymd = (t) => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

function writeRec(db, owner, col, id, data, prev) {
  const now = Date.now();
  const rec = {
    id, col, owner, app: 'assistant', data,
    rev: (prev?.rev ?? 0) + 1, updatedAt: Math.max(now, (prev?.updatedAt ?? 0) + 1), shared: prev?.shared ?? []
  };
  db.data.recs[`${col}/${id}`] = { rec, seq: db.nextSeq(), by: owner };
  return rec;
}

/** Find one of the user's tasks or notes by id or by (part of) its title. */
function findItem(db, user, col, item) {
  const mine = Object.values(db.data.recs).map((x) => x.rec).filter((r) => r.col === col && r.owner === user.id && !r.deleted);
  if (item.id) return mine.find((r) => r.id === item.id);
  const q = String(item.match ?? item.title ?? '').trim().toLowerCase();
  if (!q) return undefined;
  return mine.find((r) => String(r.data?.title ?? '').toLowerCase() === q) ?? mine.find((r) => String(r.data?.title ?? '').toLowerCase().includes(q));
}

/**
 * Apply one item for a user. op: add (default), edit, complete, move, delete. type: task or note.
 * Returns { ok, op, col, id } or { ok: false, error }.
 */
export function applyItem(db, user, item, via = 'assistant') {
  const type = String(item.type ?? 'task').toLowerCase().startsWith('n') ? 'note' : 'task';
  const col = type === 'note' ? 'notes' : 'tasks';
  const op = String(item.op ?? 'add').toLowerCase();
  const now = Date.now();
  if (op === 'add' || op === 'create') {
    const title = String(item.title ?? '').trim().slice(0, 200);
    if (!title) return { ok: false, error: 'An item needs a title' };
    const id = `${type === 'note' ? 'n' : 't'}-as-${randomUUID().slice(0, 12)}`;
    const { due, timed } = dueOf(item.due);
    const data = type === 'note'
      ? { title, body: String(item.body ?? ''), notebook: item.notebook || undefined, tags: Array.isArray(item.tags) ? item.tags.map(String).slice(0, 10) : [], createdAt: now, updatedAt: now, history: [], source: via }
      : { title, notes: String(item.body ?? ''), tier: tierOf(item.importance), due, timed, repeat: 'none', reminders: [], alerts: true, intensity: 'nudge', steps: [], createdAt: now, touchedAt: now, history: [], source: via };
    writeRec(db, user.id, col, id, data);
    return { ok: true, op: 'add', col, id };
  }
  const cur = findItem(db, user, col, item);
  if (!cur) return { ok: false, error: `No ${type} like that${item.match || item.title ? `: "${item.match ?? item.title}"` : ''}` };
  const d = { ...cur.data };
  if (op === 'edit' || op === 'update') {
    if (item.title !== undefined && !item.match) d.title = String(item.title).slice(0, 200);
    if (item.newTitle !== undefined) d.title = String(item.newTitle).slice(0, 200);
    if (item.body !== undefined) { if (type === 'note') d.body = String(item.body); else d.notes = String(item.body); }
    if (item.due !== undefined) Object.assign(d, dueOf(item.due));
    if (item.importance !== undefined && type === 'task') d.tier = tierOf(item.importance);
    if (item.tags !== undefined && type === 'note') d.tags = Array.isArray(item.tags) ? item.tags.map(String) : [];
    if (type === 'note') d.updatedAt = now; else d.touchedAt = now;
  } else if (op === 'complete' || op === 'done') {
    if (type === 'note') return { ok: false, error: 'Notes can\'t be completed' };
    d.doneAt = now; d.touchedAt = now;
  } else if (op === 'move') {
    if (type === 'note') d.notebook = item.notebook ? String(item.notebook) : undefined;
    else { Object.assign(d, dueOf(item.due)); d.touchedAt = now; }
  } else if (op === 'delete' || op === 'remove') {
    // Soft: notes go to the trash, tasks are let go (both can be brought back in the apps)
    if (type === 'note') d.trashed = now; else { d.letGo = true; d.touchedAt = now; }
  } else return { ok: false, error: `Unknown op "${op}"` };
  writeRec(db, cur.owner, col, cur.id, d, cur);
  return { ok: true, op, col, id: cur.id };
}

// ---------- Notion adapter ----------
const plain = (rt) => (Array.isArray(rt) ? rt.map((x) => x.plain_text ?? x.text?.content ?? '').join('') : '');
const prop = (page, name) => {
  const p = page.properties?.[name] ?? Object.entries(page.properties ?? {}).find(([k]) => k.toLowerCase() === name.toLowerCase())?.[1];
  if (!p) return undefined;
  switch (p.type) {
    case 'title': return plain(p.title);
    case 'rich_text': return plain(p.rich_text);
    case 'select': return p.select?.name;
    case 'status': return p.status?.name;
    case 'date': return p.date?.start;
    case 'people': return p.people?.[0]?.name;
    case 'last_edited_time': return p.last_edited_time;
    default: return undefined;
  }
};
const propType = (page, name) => (page.properties?.[name] ?? Object.entries(page.properties ?? {}).find(([k]) => k.toLowerCase() === name.toLowerCase())?.[1])?.type;

export function notionAdapter({ token, database, base = 'https://api.notion.com', fetchFn = fetch }) {
  const call = async (method, path, body) => {
    const r = await fetchFn(`${base}/v1${path}`, {
      method, headers: { authorization: `Bearer ${token}`, 'notion-version': '2022-06-28', 'content-type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.message || `Notion said ${r.status}`);
    return j;
  };
  return {
    name: 'notion',
    /** Every row changed since `since` (or all rows), newest first. */
    async rows(since = 0) {
      const out = [];
      let cursor;
      do {
        const j = await call('POST', `/databases/${database}/query`, {
          page_size: 100, start_cursor: cursor,
          ...(since ? { filter: { timestamp: 'last_edited_time', last_edited_time: { on_or_after: new Date(since - 60_000).toISOString() } } } : {})
        });
        out.push(...(j.results ?? []));
        cursor = j.has_more ? j.next_cursor : undefined;
      } while (cursor && out.length < 1000);
      return out;
    },
    async setStatus(page, status) {
      const type = propType(page, 'Status') === 'status' ? 'status' : 'select';
      await call('PATCH', `/pages/${page.id}`, { properties: { Status: { [type]: { name: status } } } });
    },
    async update(pageId, page, d, col, status) {
      const props = { Title: { title: [{ text: { content: String(d.title ?? '').slice(0, 1900) } }] } };
      const st = propType(page, 'Status') === 'status' ? 'status' : 'select';
      if (status) props.Status = { [st]: { name: status } };
      if (col === 'tasks') {
        if (propType(page, 'Due date') === 'date') props['Due date'] = { date: d.due ? { start: d.timed ? new Date(d.due).toISOString() : ymd(d.due) } : null };
        if (propType(page, 'Importance') === 'select') props.Importance = { select: { name: TIER_NAMES[d.tier ?? 0] } };
      }
      const bodyText = col === 'notes' ? d.body : d.notes;
      if (propType(page, 'Body') === 'rich_text' && bodyText !== undefined) props.Body = { rich_text: [{ text: { content: String(bodyText).slice(0, 1900) } }] };
      await call('PATCH', `/pages/${pageId}`, { properties: props });
    },
    async archive(pageId) { await call('PATCH', `/pages/${pageId}`, { archived: true }); },
    async create(fields) {
      return call('POST', '/pages', {
        parent: { database_id: database },
        properties: {
          Title: { title: [{ text: { content: fields.title } }] },
          Type: { select: { name: fields.type } },
          Status: { select: { name: 'Inbox' } },
          Owner: { rich_text: [{ text: { content: fields.owner } }] },
          Source: { select: { name: 'app' } },
          ...(fields.body ? { Body: { rich_text: [{ text: { content: fields.body } }] } } : {})
        }
      });
    },
    /** The database's columns, to check the setup */
    async describe() { return call('GET', `/databases/${database}`); }
  };
}

// ---------- The assistant module on the server ----------
export function assistant(ctx) {
  const { db, cfg, log } = ctx;
  // Always read through the current database (a roll back from a backup swaps it)
  const ensure = () => {
    const x = (db.data.assistant ??= { notion: null, map: {}, lastPoll: 0, lastOk: 0, lastError: '', received: 0, outbox: [] });
    x.map ??= {}; x.outbox ??= [];
    db.data.inboxTokens ??= {};
    return x;
  };
  ensure();
  const a = new Proxy({}, { get: (_, k) => ensure()[k], set: (_, k, v) => { ensure()[k] = v; return true; } });
  const notionConf = () => (cfg.notion?.token && cfg.notion?.database ? { ...cfg.notion, from: 'env' } : a.notion?.token && a.notion?.database ? { ...a.notion, from: 'settings' } : null);
  let adapter = null;
  const getAdapter = () => {
    const c = notionConf();
    if (!c) return (adapter = null);
    if (!adapter || adapter.key !== `${c.token}|${c.database}|${cfg.notionBase ?? ''}`) {
      adapter = notionAdapter({ token: c.token, database: c.database, base: cfg.notionBase ?? 'https://api.notion.com', fetchFn: cfg.fetch ?? fetch });
      adapter.key = `${c.token}|${c.database}|${cfg.notionBase ?? ''}`;
    }
    return adapter;
  };
  const owners = () => Object.values(db.data.users).filter((u) => u.role === 'owner');
  let busy = null;

  /** Poll Notion: new rows in, Notion edits in, app edits out. Safe to call often. */
  async function poll(why = 'timer') {
    const n = getAdapter();
    if (!n) return { ok: false, error: 'Notion is not set up' };
    if (busy) return busy;
    busy = (async () => {
      const since = a.lastOk;
      const started = Date.now();
      let added = 0, changed = 0;
      try {
        // 1. App changes waiting to go back to Notion (completions, edits, soft deletes)
        const out = a.outbox.splice(0);
        for (const job of out) {
          try {
            if (job.archive) await n.archive(job.page);
            else await n.update(job.page, job.snapshot ?? { properties: {} }, job.data, job.col, job.status);
          } catch (e) { log(`${stamp()} assistant: couldn't update Notion (${e.message})`); }
        }
        // 2. Rows from Notion
        const rows = await n.rows(since);
        for (const page of rows) {
          const known = a.map[page.id];
          const status = String(prop(page, 'Status') ?? '').toLowerCase();
          if (page.archived || page.in_trash) {
            if (known) { const u = db.data.users[known.owner]; if (u) applyItem(db, u, { op: 'delete', type: known.col === 'notes' ? 'note' : 'task', id: known.id }); delete a.map[page.id]; changed++; }
            continue;
          }
          const ownerName = prop(page, 'Owner');
          const user = (ownerName && findUser(db, ownerName)) || owners()[0];
          if (!user) continue;
          const type = String(prop(page, 'Type') ?? 'Task').toLowerCase().startsWith('n') ? 'note' : 'task';
          const fields = { type, title: prop(page, 'Title') ?? prop(page, 'Name') ?? '', body: prop(page, 'Body') ?? '', due: prop(page, 'Due date') ?? prop(page, 'Due'), importance: prop(page, 'Importance') };
          if (!known) {
            if (status && status !== 'inbox') continue; // only new rows waiting in the Inbox
            if (String(prop(page, 'Source') ?? '').toLowerCase() === 'app' && !fields.title.startsWith('Test from Hub')) continue;
            const r = applyItem(db, user, fields);
            if (!r.ok) continue;
            a.map[page.id] = { col: r.col, id: r.id, owner: user.id, at: Date.now() };
            a.received++; added++;
            await n.setStatus(page, 'Synced').catch(() => {});
          } else if (Date.parse(page.last_edited_time) > (known.at ?? 0) + 2000) {
            // Edited in Notion after we last saw it: update the task or note; Done completes a task
            applyItem(db, user, { ...fields, op: 'edit', id: known.id });
            if (status === 'done' && type === 'task') applyItem(db, user, { op: 'complete', type, id: known.id });
            known.at = Date.now(); changed++;
          }
        }
        a.lastOk = started; a.lastError = '';
        if (added || changed) { db.save(); log(`${stamp()} assistant: ${added} new from Notion, ${changed} updated (${why})`); ctx.runs?.record('assistant', { text: `${added} new, ${changed} changed`, n: added + changed }); }
        return { ok: true, added, changed };
      } catch (e) {
        a.lastError = e.message;
        if (!a.lastFailRecorded || Date.now() - a.lastFailRecorded > 3600_000) { a.lastFailRecorded = Date.now(); ctx.runs?.record('assistant', { ok: false, text: "Couldn't reach Notion" }); }
        log(`${stamp()} assistant: Notion check failed (${e.message})`);
        return { ok: false, error: e.message };
      } finally { a.lastPoll = Date.now(); db.save(); busy = null; }
    })();
    return busy;
  }

  /** A record changed in an app: if it came from Notion, queue the change to go back. */
  function changed(rec) {
    const page = Object.entries(a.map).find(([, m]) => m.id === rec.id && m.col === rec.col)?.[0];
    if (!page) return;
    const d = rec.data ?? {};
    const gone = rec.deleted || d.trashed || d.letGo;
    a.outbox.push(gone ? { page, archive: true } : { page, col: rec.col, data: d, status: d.doneAt ? 'Done' : undefined });
    a.map[page].at = Date.now();
    if (gone) delete a.map[page];
  }

  const timer = setInterval(() => { if (getAdapter()) void poll(); }, cfg.assistantPollMs ?? POLL_MS);
  timer.unref?.();

  const status = (u) => {
    const c = notionConf();
    const tokens = Object.values(db.data.inboxTokens).filter((t) => t.userId === u.id);
    return {
      notion: c ? { connected: !a.lastError, from: c.from, database: c.database, lastPoll: a.lastPoll || null, lastOk: a.lastOk || null, error: a.lastError || null } : null,
      received: a.received, inboxTokens: tokens.map((t) => ({ label: t.label, created: t.created })),
      owner: u.role === 'owner'
    };
  };

  const routes = {
    'GET /api/assistant': (_b, u) => [200, status(u)],
    // Check Notion now (the apps call this when they open; at most once a minute)
    'POST /api/assistant/sync': async () => {
      if (!getAdapter()) return [200, { ok: false, error: 'Notion is not set up' }];
      if (Date.now() - a.lastPoll < 60_000) return [200, { ok: true, skipped: true }];
      return [200, await poll('app opened')];
    },
    // Owner: set or clear the Notion connection (kept in the server's data folder, never in git)
    'POST /api/assistant/notion': async (b, u) => {
      if (u.role !== 'owner') return [403, { error: 'Only the owner can set up the assistant' }];
      if (!b.token && !b.database) { a.notion = null; db.save(); return [200, status(u)]; }
      const database = String(b.database ?? '').replace(/^.*notion\.so\/(?:[^/]+\/)?/, '').replace(/[?#].*$/, '').replace(/^.*-([0-9a-f]{32})$/i, '$1').trim();
      a.notion = { token: String(b.token ?? '').trim(), database };
      a.lastOk = 0; a.lastError = '';
      db.save();
      try { await getAdapter().describe(); } catch (e) { a.lastError = e.message; }
      return [200, status(u)];
    },
    // Test: send a sample row to Notion, bring it in, report, then tidy it away
    'POST /api/assistant/test': async (_b, u) => {
      const n = getAdapter();
      if (!n) return [400, { error: 'Set up Notion first (token and database)' }];
      const steps = [];
      try {
        const db1 = await n.describe();
        const cols = Object.keys(db1.properties ?? {});
        const need = ['Title', 'Type', 'Status', 'Owner'];
        const missing = need.filter((x) => !cols.some((c) => c.toLowerCase() === x.toLowerCase()));
        steps.push(missing.length ? `The database is missing columns: ${missing.join(', ')}` : `Database found: ${plain(db1.title) || 'Inbox'}`);
        if (missing.length) return [200, { ok: false, steps }];
        const page = await n.create({ title: `Test from Hub ${new Date().toLocaleTimeString('en-GB')}`, type: 'Task', owner: u.username });
        steps.push('Sample row written to Notion');
        a.lastPoll = 0;
        const r = await poll('test');
        const m = a.map[page.id];
        steps.push(m ? 'It came back in as a task' : `It didn't come back in${r.error ? `: ${r.error}` : ''}`);
        if (m) { applyItem(db, u, { op: 'delete', type: 'task', id: m.id }); delete a.map[page.id]; }
        await n.archive(page.id).catch(() => {});
        steps.push('Test row tidied away');
        return [200, { ok: !!m, steps }];
      } catch (e) { steps.push(`Notion said: ${e.message}`); return [200, { ok: false, steps }]; }
    },
    // Personal inbox tokens for the HTTP adapter (shown once, stored only as a hash)
    'POST /api/assistant/token': (b, u) => {
      const t = `hub_${randomBytes(24).toString('base64url')}`;
      db.data.inboxTokens[sha(t)] = { userId: u.id, created: Date.now(), label: String(b.label ?? 'Assistant').slice(0, 40) };
      db.save();
      return [200, { token: t }];
    },
    'POST /api/assistant/token/revoke': (_b, u) => {
      for (const [k, v] of Object.entries(db.data.inboxTokens)) if (v.userId === u.id) delete db.data.inboxTokens[k];
      db.save();
      return [200, status(u)];
    }
  };

  // The HTTP inbox: an inbox token (or a normal sign-in) can add, edit, complete, move and delete
  const inboxUser = (token) => {
    const t = db.data.inboxTokens[sha(token)];
    return t ? db.data.users[t.userId] ?? null : null;
  };
  routes['POST /api/inbox'] = (b, u, { ip }) => {
    const user = u;
    const items = Array.isArray(b.items) ? b.items.slice(0, 200) : b.title || b.op ? [b] : [];
    if (!items.length) return [400, { error: 'Send { "items": [ { "type": "task", "title": "..." } ] }' }];
    const results = items.map((it) => applyItem(db, user, it));
    const ok = results.filter((r) => r.ok).length;
    if (ok) { a.received += results.filter((r) => r.ok && r.op === 'add').length; db.save(); record(db, { user: user.id, username: user.username, kind: 'action', what: `assistant inbox: ${ok} item${ok === 1 ? '' : 's'}`, app: 'assistant', ip }); }
    return [200, { results }];
  };
  routes['GET /api/inbox'] = (_b, u, { q }) => {
    const type = q.get('type') ?? '';
    const cols = type.startsWith('n') ? ['notes'] : type.startsWith('t') ? ['tasks'] : ['tasks', 'notes'];
    const items = Object.values(db.data.recs).map((x) => x.rec)
      .filter((r) => cols.includes(r.col) && r.owner === u.id && !r.deleted && !r.data?.trashed && !r.data?.letGo && !(r.col === 'tasks' && r.data?.doneAt))
      .map((r) => ({ id: r.id, type: r.col === 'notes' ? 'note' : 'task', title: r.data?.title ?? '', due: r.data?.due ? ymd(r.data.due) : undefined, importance: r.col === 'tasks' ? TIER_NAMES[r.data?.tier ?? 0] : undefined, notebook: r.data?.notebook, source: r.data?.source ?? 'app' }));
    return [200, { items }];
  };

  return { routes, poll, changed, inboxUser, stop: () => clearInterval(timer) };
}
