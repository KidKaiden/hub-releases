@echo off
rem Hub Server: set up (or update) your own Hub server on this PC. Double-click this file.
rem It runs setup.ps1 beside it. Nothing needs admin rights.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
echo.
pause
