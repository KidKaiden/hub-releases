// Trading: the backtest. The same strategy run twice over past daily prices, side by side, so the effect of the
// limits is measured, not guessed (Kaiden, 2026-11-11):
//  - "Strategy alone": buys on the signal with an equal share of the cash, sells on the signal. No stops, no floor.
//  - "With your limits": the same signals, sized and stopped by risk.mjs (floor, stops, caps, daily stop).
//  - "Just holding the index": everything in the index on day one, held to the end.
// Orders go in at the next day's open (a signal is only known after the close). A stop that the price jumps past
// fills at the open, below the stop: the backtest shows that loss honestly.
import { signals, gapSize } from './strategy.mjs';
import { checkOrder, dailyStopHit } from './risk.mjs';

const r2 = (v) => Math.round(v * 100) / 100;

function stats(curve, start, floor) {
  let peak = start, dd = 0, worstDay = 0, low = start;
  for (let i = 0; i < curve.length; i++) {
    const v = curve[i].v;
    peak = Math.max(peak, v); dd = Math.max(dd, (peak - v) / peak);
    low = Math.min(low, v);
    if (i) worstDay = Math.min(worstDay, v / curve[i - 1].v - 1);
  }
  const end = curve.at(-1)?.v ?? start;
  return { end: r2(end), returnPct: r2((end / start - 1) * 100), maxDrawdownPct: r2(dd * 100), worstDayPct: r2(worstDay * 100), lowest: r2(low), belowFloor: floor != null && low < floor };
}

/**
 * bars: { SYMBOL: [{ t, o, h, l, c }] } (same days), index: the index symbol (in bars). start: the starting money.
 * Returns the three curves (one point a day) and their numbers.
 */
export function backtest({ bars, symbols, index = 'SPY', start = 100, limits, strategy }) {
  const days = bars[index].map((b) => b.t);
  const at = Object.fromEntries(Object.entries(bars).map(([s, list]) => [s, new Map(list.map((b, i) => [b.t, i]))]));
  const sig = Object.fromEntries(symbols.map((s) => [s, signals(bars[s], strategy)]));
  const gaps = Object.fromEntries(symbols.map((s) => [s, gapSize(bars[s])]));
  const bar = (s, t) => bars[s][at[s].get(t)];

  function run(withLimits) {
    let cash = start, trades = 0, wins = 0, stopped = 0, gappedPast = 0, refused = 0, dayStart = start, locked = false, lockedOn = null;
    const pos = {}; // symbol -> { qty, cost, stop }
    const curve = [];
    const pending = []; // orders for the next open
    const value = (t, px = 'c') => cash + Object.entries(pos).reduce((s, [sym, p]) => s + p.qty * (bar(sym, t)?.[px] ?? 0), 0);
    for (let d = 0; d < days.length; d++) {
      const t = days[d];
      dayStart = value(days[Math.max(0, d - 1)]);
      let ordersToday = 0;
      // 1. Yesterday's orders at today's open
      for (const o of pending.splice(0)) {
        const b = bar(o.symbol, t); if (!b) continue;
        if (o.side === 'sell') {
          const p = pos[o.symbol]; if (!p) continue;
          cash += p.qty * b.o; trades++; if (p.qty * b.o > p.cost) wins++; delete pos[o.symbol];
          continue;
        }
        const equity = value(t, 'o');
        let notional;
        if (withLimits) {
          const state = { equity, cash, dayStart, ordersToday, positions: Object.entries(pos).map(([s, p]) => ({ symbol: s, qty: p.qty, value: p.qty * (bar(s, t)?.o ?? 0), stopPct: limits.stopPct, gap: gaps[s] })) };
          const c = checkOrder({ symbol: o.symbol, side: 'buy', stopPct: limits.stopPct, gap: gaps[o.symbol] }, state, { ...limits, symbols });
          if (!c.ok) { refused++; continue; }
          notional = c.order.notional; ordersToday++;
        } else {
          const free = symbols.length - Object.keys(pos).length;
          notional = free > 0 ? cash / free : 0;
          if (notional < 1) continue;
        }
        notional = Math.min(notional, cash);
        const qty = notional / b.o;
        cash -= notional;
        pos[o.symbol] = { qty, cost: notional, stop: withLimits ? b.o * (1 - limits.stopPct / 100) : null };
      }
      // 2. During the day: stops (a jump past the stop fills at the open)
      if (withLimits) for (const [s, p] of Object.entries(pos)) {
        const b = bar(s, t); if (!b || p.stop == null) continue;
        if (b.l <= p.stop) {
          const fill = b.o < p.stop ? b.o : p.stop;
          if (b.o < p.stop) gappedPast++;
          cash += p.qty * fill; trades++; stopped++; if (p.qty * fill > p.cost) wins++; delete pos[s];
        }
      }
      // 3. After the close: the signals for tomorrow
      const eq = value(t);
      const stopDay = withLimits && dailyStopHit(eq, dayStart, limits);
      for (const s of symbols) {
        const i = at[s].get(t); if (i == null) continue;
        const x = sig[s][i];
        if (x === 'sell' && pos[s]) pending.push({ symbol: s, side: 'sell' });
        if (x === 'buy' && !pos[s] && !stopDay && !locked) pending.push({ symbol: s, side: 'buy' });
      }
      // The floor: reached it, the bot stops buying (as the server does: it locks and tells you). Stops and sell
      // signals still close what's held.
      if (withLimits && !locked && limits.floor != null && eq <= limits.floor) {
        locked = true; lockedOn = t;
        for (let k = pending.length - 1; k >= 0; k--) if (pending[k].side === 'buy') pending.splice(k, 1);
      }
      curve.push({ t, v: r2(eq) });
    }
    return { curve, trades, wins, stopped, gappedPast, refused, lockedOn, ...stats(curve, start, withLimits ? limits.floor : null) };
  }
  const idx = bars[index];
  const shares = start / idx[0].o;
  const hold = idx.map((b) => ({ t: b.t, v: r2(shares * b.c) }));
  return { days: days.length, from: days[0], to: days.at(-1), start, alone: run(false), limited: run(true), index: { symbol: index, curve: hold, ...stats(hold, start, null) } };
}
