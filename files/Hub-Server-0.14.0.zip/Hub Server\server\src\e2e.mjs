// End-to-end encryption for Messages (Kaiden's choice, 2026-11-14: an option). Each account has a key pair made on
// its device; the server keeps only the public half, and the private half locked with the account's password (so
// every device that signs in can open it, and the server never can). Messages are locked on the sender's device for
// each person in the chat. Here: the keys, and who has the option on.
const okKey = (k) => k && typeof k === 'object' && k.kty === 'EC' && k.crv === 'P-256' && typeof k.x === 'string' && typeof k.y === 'string' && !k.d;

export function e2eRoutes(ctx) {
  const { db } = ctx;
  return {
    'GET /api/e2e/me': (_b, u) => [200, { on: !!u.e2e?.on, pub: u.e2e?.pub ?? null, locked: u.e2e?.locked ?? null }],
    // The device made (or re-locked) the key pair: the public half, and the private half locked with the password
    'POST /api/e2e/me': (b, u) => {
      if (!okKey(b.pub)) return [400, { error: 'Not a public key' }];
      const l = b.locked;
      if (!l || typeof l.salt !== 'string' || typeof l.iv !== 'string' || typeof l.ct !== 'string' || l.ct.length > 4000) return [400, { error: 'Not a locked key' }];
      u.e2e = { ...(u.e2e ?? {}), pub: { kty: 'EC', crv: 'P-256', x: b.pub.x, y: b.pub.y }, locked: { salt: l.salt, iv: l.iv, ct: l.ct, iter: Number(l.iter) || 310000 }, at: Date.now() };
      db.save();
      return [200, { ok: true }];
    },
    'POST /api/e2e/settings': (b, u) => { u.e2e = { ...(u.e2e ?? {}), on: !!b.on }; db.save(); return [200, { on: u.e2e.on }]; },
    // Public keys of the people in a chat (public on purpose: they can only lock things for that person)
    'GET /api/e2e/keys': (_b, _u, { q }) => {
      const ids = String(q.get('ids') ?? '').split(',').filter(Boolean).slice(0, 50);
      return [200, { keys: Object.fromEntries(ids.map((id) => [id, db.data.users[id]?.e2e?.pub ?? null])) }];
    }
  };
}
