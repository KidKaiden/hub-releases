// Space: how much each person keeps on this server. The server's owners have unlimited space; everyone else has the
// server's limit (100 MB to start; the owner changes it), unless an owner switches them to unlimited or they type the
// server's unlimited-space password. Unlimited space is also what lets someone connect a bank (bank.mjs).
// When someone is full, new things wait on their device (nothing is ever deleted for them): they can free up space,
// ask for more, or set up their own server. Only they can choose to reset (empty) their own space.
import { hashPassword, checkPassword } from './auth.mjs';

const MB = 1024 * 1024;
const size = (rec) => (rec && !rec.deleted ? Buffer.byteLength(JSON.stringify(rec.data ?? null)) : 0);

export function space(ctx) {
  const { db, log, stamp } = ctx;
  db.data.settings.spaceMb ??= 100;
  const isAdmin = (u) => !!db.data.roles?.[u.role]?.admin;
  const unlimited = (u) => isAdmin(u) || u.space === 'unlimited';
  /** Bytes each person keeps (the records they own). Worked out when asked; cheap for a family's server. */
  function usage() {
    const m = new Map();
    for (const { rec } of Object.values(db.data.recs)) if (!rec.deleted) m.set(rec.owner, (m.get(rec.owner) ?? 0) + size(rec));
    return m;
  }
  const limitOf = (u) => (unlimited(u) ? null : Math.max(1, Number(u.spaceMb ?? db.data.settings.spaceMb) || 100) * MB);
  function info(u, used = usage().get(u.id) ?? 0) {
    const limit = limitOf(u);
    return { used, limit, unlimited: limit === null, full: limit !== null && used >= limit, pct: limit ? Math.min(100, Math.round((used / limit) * 100)) : 0, by: isAdmin(u) ? 'owner' : u.space === 'unlimited' ? (u.spaceBy ?? 'owner') : null };
  }
  /** For one sync: says whether each change fits, keeping count as it goes. Deleting or shrinking always fits. */
  function meter(u) {
    const lim = new Map(), used = usage();
    const room = (owner) => {
      if (!lim.has(owner)) { const p = db.data.users[owner]; lim.set(owner, p ? limitOf(p) : null); }
      return lim.get(owner);
    };
    return {
      fits(rec, prev) {
        const delta = size(rec) - size(prev);
        const limit = room(rec.owner);
        const now = used.get(rec.owner) ?? 0;
        if (delta > 0 && limit !== null && now + delta > limit) return false;
        used.set(rec.owner, now + delta);
        return true;
      },
      info: () => info(u, used.get(u.id) ?? 0)
    };
  }
  const tries = new Map(); // account -> recent wrong unlock tries
  const routes = {
    'GET /api/space': (_b, u) => [200, { ...info(u), hasCode: !!db.data.settings.unlockHash, asked: u.spaceAsked ?? null }],
    // The server's unlimited-space password (set by an owner in Admin > Space)
    'POST /api/space/unlock': (b, u) => {
      if (unlimited(u)) return [200, info(u)];
      if (!db.data.settings.unlockHash) return [400, { error: "This server doesn't have an unlimited-space password" }];
      const t = (tries.get(u.id) ?? []).filter((x) => Date.now() - x < 3600_000);
      if (t.length >= 5) return [429, { error: 'Too many wrong tries. Wait an hour, or ask the owner' }];
      if (!checkPassword(String(b.code ?? ''), db.data.settings.unlockHash)) { tries.set(u.id, [...t, Date.now()]); return [400, { error: "That isn't the password" }]; }
      u.space = 'unlimited'; u.spaceBy = 'password'; delete u.spaceAsked;
      db.save();
      log(`${stamp()} ${u.name} unlocked unlimited space with the password`);
      ctx.poke?.(Object.values(db.data.users).filter(isAdmin).map((x) => x.id));
      return [200, info(u)];
    },
    // Ask the owner for unlimited space (they get a note and answer in Admin > People)
    'POST /api/space/request': async (_b, u) => {
      if (unlimited(u)) return [200, info(u)];
      u.spaceAsked = Date.now();
      db.save();
      for (const o of Object.values(db.data.users).filter((x) => isAdmin(x) && !x.disabled)) {
        ctx.poke?.([o.id]);
        await ctx.sendPush?.(o.id, { title: 'Space request', body: `${u.name} asks for unlimited space`, route: 'hub/admin', tag: 'space-request' })?.catch?.(() => {});
      }
      return [200, { ...info(u), asked: u.spaceAsked }];
    },
    // Their own choice only: everything they keep here is emptied (marked deleted; the server's backups still have it)
    'POST /api/space/reset': (b, u) => {
      if (b.confirm !== 'EMPTY') return [400, { error: 'Type EMPTY to confirm' }];
      let n = 0;
      for (const [k, v] of Object.entries(db.data.recs)) {
        if (v.rec.owner !== u.id || v.rec.deleted) continue;
        db.data.recs[k] = { rec: { ...v.rec, deleted: true, rev: (v.rec.rev ?? 1) + 1, updatedAt: Date.now() }, seq: db.nextSeq(), by: u.id };
        n++;
      }
      db.save();
      log(`${stamp()} ${u.name} emptied their own space (${n} item${n === 1 ? '' : 's'})`);
      ctx.poke?.([u.id]);
      return [200, { emptied: n, ...info(u) }];
    },

    // ---------- The owner (Admin > People and Space) ----------
    'GET /api/admin/space': (_b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      const used = usage();
      return [200, {
        spaceMb: db.data.settings.spaceMb, hasCode: !!db.data.settings.unlockHash,
        people: Object.values(db.data.users).map((p) => ({ accountId: p.id, name: p.name, username: p.username, owner: isAdmin(p), ...info(p, used.get(p.id) ?? 0), asked: p.spaceAsked ?? null, disabled: !!p.disabled }))
      }];
    },
    'POST /api/admin/space': (b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      if (b.spaceMb !== undefined) db.data.settings.spaceMb = Math.min(1_000_000, Math.max(10, Math.round(Number(b.spaceMb) || 100)));
      if (b.code !== undefined) {
        const c = String(b.code ?? '');
        if (!c) delete db.data.settings.unlockHash;
        else if (c.length < 8) return [400, { error: 'Use 8 or more letters or numbers', field: 'code' }];
        else db.data.settings.unlockHash = hashPassword(c);
      }
      if (b.person) {
        const p = db.data.users[b.person.id];
        if (!p) return [404, { error: 'No such account' }];
        if (b.person.unlimited === true) { p.space = 'unlimited'; p.spaceBy = 'owner'; delete p.spaceAsked; }
        if (b.person.unlimited === false) { delete p.space; delete p.spaceBy; delete p.spaceAsked; }
        if (b.person.spaceMb !== undefined) { const n = Math.round(Number(b.person.spaceMb)); if (n > 0) p.spaceMb = Math.min(1_000_000, n); else delete p.spaceMb; }
        if (b.person.decline) delete p.spaceAsked;
        ctx.poke?.([p.id]);
      }
      db.save();
      return [200, { ok: true }];
    }
  };
  return { routes, info, meter, unlimited, isAdmin };
}
