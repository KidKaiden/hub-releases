// Two-step sign-in (security plan A5, 2026-11-14): a 6-digit code from a free authenticator app (Microsoft or Google
// Authenticator, or any that reads a QR code), checked at sign-in after the password. Ten one-time backup codes for
// when the phone is lost. The secret is kept in the encrypted database; backup codes only as hashes.
// Also: Your devices (each sign-in, sign out one or everywhere), and "confirm it's you" for risky actions (the
// password or a code again, good for 10 minutes on that device).
import { createHmac, randomBytes, createHash, timingSafeEqual } from 'node:crypto';
import { checkPassword, tokenKey } from './auth.mjs';
import { record, addr } from './history.mjs';

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
export function base32(buf) { let bits = 0, v = 0, out = ''; for (const b of buf) { v = (v << 8) | b; bits += 8; while (bits >= 5) { out += B32[(v >>> (bits - 5)) & 31]; bits -= 5; } } if (bits) out += B32[(v << (5 - bits)) & 31]; return out; }
export function unbase32(s) { let bits = 0, v = 0; const out = []; for (const c of String(s).toUpperCase().replace(/[^A-Z2-7]/g, '')) { v = (v << 5) | B32.indexOf(c); bits += 5; if (bits >= 8) { out.push((v >>> (bits - 8)) & 255); bits -= 8; } } return Buffer.from(out); }
/** RFC 6238: the code for a 30-second step */
export function totp(secret, t = Date.now(), step = 0) {
  const counter = Math.floor(t / 30000) + step;
  const msg = Buffer.alloc(8); msg.writeBigUInt64BE(BigInt(counter));
  const h = createHmac('sha1', unbase32(secret)).update(msg).digest();
  const o = h[h.length - 1] & 15;
  return String(((h.readUInt32BE(o) & 0x7fffffff) % 1_000_000)).padStart(6, '0');
}
const same = (a, b) => a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b));
/** A code from the app: this step or one either side (a clock a little off); each code works once */
export function checkTotp(t, code, now = Date.now()) {
  const c = String(code ?? '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(c) || !t?.secret) return false;
  for (const s of [-1, 0, 1]) {
    const step = Math.floor(now / 30000) + s;
    if (same(totp(t.secret, now, s), c) && step > (t.lastStep ?? 0)) { t.lastStep = step; return true; }
  }
  return false;
}
const hashCode = (c) => createHash('sha256').update(String(c).toUpperCase().replace(/[^A-Z0-9]/g, '')).digest('hex');
/** A backup code: used once, then gone */
function useBackup(t, code) {
  const h = hashCode(code);
  const i = (t.backup ?? []).findIndex((x) => x === h);
  if (i < 0) return false;
  t.backup.splice(i, 1);
  return true;
}
/** Password-then-code: true when this account's second step is passed (or it has none) */
export function secondStepOk(u, code) {
  if (!u.totp?.on) return true;
  return checkTotp(u.totp, code) || useBackup(u.totp, code);
}
export const twoStepOn = (u) => !!u.totp?.on;

export function twoStepRoutes(ctx) {
  const { db, log, stamp } = ctx;
  const CONFIRM_MS = 10 * 60_000;
  const pw = (b, u) => checkPassword(String(b.password ?? ''), u.pw);
  const say = (u, what, ip, device) => record(db, { user: u.id, username: u.username, kind: 'security', what, ip, device });
  const shortId = (k) => k.slice(0, 12);

  /** Risky actions: confirmed on this device in the last 10 minutes? */
  // Signing in counts: the password was just typed
  ctx.confirmed = (session) => !!session && Date.now() - Math.max(session.confirmedAt ?? 0, session.created ?? 0) < CONFIRM_MS;
  ctx.needConfirm = (session) => (ctx.confirmed(session) ? null : [403, { error: "Confirm it's you first", code: 'confirm' }]);

  return {
    'GET /api/account/security': (_b, u, { token }) => {
      const now = Date.now();
      const mine = Object.entries(db.data.tokens).filter(([, s]) => s.userId === u.id && s.expires > now);
      return [200, {
        twoStep: { on: twoStepOn(u), since: u.totp?.on ? u.totp.made : null, backupLeft: u.totp?.backup?.length ?? 0 },
        devices: mine.map(([k, s]) => ({ id: shortId(k), device: s.device ?? {}, ip: s.ip ?? '', created: s.created, lastSeen: s.lastSeen, current: k === tokenKey(token), extension: false }))
          .sort((a, b) => Number(b.current) - Number(a.current) || b.lastSeen - a.lastSeen),
        events: db.data.events.filter((e) => e.user === u.id && ['signin', 'signout', 'fail', 'password', 'security'].includes(e.kind)).slice(-40).reverse()
      }];
    },
    // Your devices: sign one out, or every other one
    'POST /api/account/devices/signout': (b, u, { ip, token, session }) => {
      const no = ctx.needConfirm(session); if (no) return no;
      const me = tokenKey(token);
      let n = 0;
      for (const [k, s] of Object.entries(db.data.tokens)) {
        if (s.userId !== u.id || k === me) continue;
        if (b.all || shortId(k) === b.id) { delete db.data.tokens[k]; n++; }
      }
      db.save();
      say(u, b.all ? `signed out every other device (${n})` : 'signed out a device', ip);
      return [200, { signedOut: n }];
    },
    // Confirm it's you: the password (or, with two-step on, a code from the app works too)
    'POST /api/account/confirm': (b, u, { ip, session }) => {
      const ok = pw(b, u) || (twoStepOn(u) && secondStepOk(u, b.code));
      if (!ok) { say(u, 'got the password wrong when confirming', ip); return [403, { error: 'That password is not right', field: 'password', code: 'password' }]; }
      if (session) session.confirmedAt = Date.now();
      db.save();
      return [200, { until: Date.now() + CONFIRM_MS }];
    },
    // Turning two-step on: a new secret (shown as a QR code), on only once a code from the app checks out
    'POST /api/account/2fa/start': (b, u) => {
      if (!pw(b, u)) return [403, { error: 'That password is not right', field: 'password', code: 'password' }];
      const secret = base32(randomBytes(20));
      u.totpPending = { secret, at: Date.now() };
      db.save();
      const label = encodeURIComponent(`Hub:${u.username}`);
      return [200, { secret: secret.match(/.{1,4}/g).join(' '), uri: `otpauth://totp/${label}?secret=${secret}&issuer=Hub&digits=6&period=30` }];
    },
    'POST /api/account/2fa/confirm': (b, u, { ip }) => {
      const p = u.totpPending;
      if (!p || Date.now() - p.at > 15 * 60_000) return [400, { error: 'Start again: press Turn on' }];
      const t = { secret: p.secret, made: Date.now(), on: true };
      if (!checkTotp(t, b.code)) return [400, { error: "That code doesn't match. Check the phone's clock, then type the newest code", field: 'code' }];
      const codes = Array.from({ length: 10 }, () => base32(randomBytes(5)).slice(0, 8).replace(/(.{4})/, '$1-'));
      t.backup = codes.map(hashCode);
      u.totp = t; delete u.totpPending;
      db.save();
      say(u, 'turned on two-step sign-in', ip);
      log(`${stamp()} ${u.name} turned on two-step sign-in`);
      ctx.alert?.(u.id, 'Two-step sign-in is on', 'From now on, signing in also asks for a code from your authenticator app');
      return [200, { on: true, backupCodes: codes }];
    },
    'POST /api/account/2fa/off': (b, u, { ip }) => {
      if (!pw(b, u)) return [403, { error: 'That password is not right', field: 'password', code: 'password' }];
      if (twoStepOn(u) && !secondStepOk(u, b.code)) return [403, { error: 'Type a code from your authenticator app (or a backup code)', field: 'code', code: 'two-step' }];
      delete u.totp; delete u.totpPending;
      db.save();
      say(u, 'turned off two-step sign-in', ip);
      ctx.alert?.(u.id, 'Two-step sign-in is off', "If this wasn't you, change your password now");
      return [200, { on: false }];
    },
    'POST /api/account/2fa/backup': (b, u, { ip }) => {
      if (!twoStepOn(u)) return [400, { error: 'Two-step sign-in is off' }];
      if (!pw(b, u)) return [403, { error: 'That password is not right', field: 'password', code: 'password' }];
      const codes = Array.from({ length: 10 }, () => base32(randomBytes(5)).slice(0, 8).replace(/(.{4})/, '$1-'));
      u.totp.backup = codes.map(hashCode);
      db.save();
      say(u, 'made new backup codes', ip);
      return [200, { backupCodes: codes }];
    }
  };
}
export { addr };
