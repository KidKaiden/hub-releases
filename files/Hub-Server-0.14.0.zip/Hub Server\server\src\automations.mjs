// Hub > AI > Automations (Hub upgrade, 2026-11-11): what Hub does by itself, and how each run went.
// Each part that runs on a timer records its runs here (when, worked or not, a few words, a number), last 60 each.
// Only the owner sees this list, and it only ever holds counts and words like "3 payments in": never contents.
export function automations(ctx) {
  const { db } = ctx;
  db.data.runs ??= {};
  function record(id, { ok = true, text = '', n = 0 } = {}) {
    const list = (db.data.runs[id] ??= []);
    list.push({ at: Date.now(), ok: !!ok, text: String(text).slice(0, 140), n: Number(n) || 0 });
    if (list.length > 60) list.splice(0, list.length - 60);
    db.save();
  }
  const isAdmin = (u) => !!db.data.roles?.[u.role]?.admin;
  const runs = (id) => (db.data.runs[id] ?? []).slice(-30);
  const health = (list, on = true) => (!on ? 'off' : !list.length ? 'waiting' : list.at(-1).ok ? 'healthy' : 'failing');

  function view() {
    const bank = db.data.settings.bank ?? {};
    const T = db.data.trading ?? { settings: {} };
    const ts = T.settings ?? {};
    const bankOn = !!(bank.appId && bank.keyFile) && !bank.paused;
    const tradeOn = !!ctx.trading?.view?.().connected?.paper || !!ctx.trading?.view?.().connected?.live;
    const list = [
      { id: 'bank', name: 'Bank feed', what: 'Brings in payments and balances from connected banks', every: `every ${ctx.cfg.bank?.pollHours || 6} hours`, area: 'finance',
        on: bankOn, toggle: bank.appId ? { key: 'bank', label: bank.paused ? 'Paused' : 'On', value: !bank.paused } : null,
        flow: ['Your bank', 'Enable Banking', 'Your PC', 'Finance'] },
      { id: 'trading-watch', name: 'Trading watch', what: 'Every few minutes: the account, stop losses, the floor, the daily stop', every: 'every 5 minutes', area: 'trading',
        on: tradeOn && !T.killed, toggle: null, flow: ['Alpaca', 'Your PC', 'Stops and floor', 'Trading'] },
      { id: 'trading-signals', name: 'Strategy signals', what: 'Each trading day: the moving-average crossover, worked out by code', every: 'each trading day', area: 'trading',
        on: tradeOn, toggle: tradeOn ? { key: 'signals', label: 'Suggest trades from the strategy', value: ts.pipeline !== 'claude' } : null,
        flow: ['Prices', 'Strategy (code)', ts.pipeline === 'claude' ? 'Claude bot' : null, 'Your limits', ts.auto ? 'Automatic' : 'You approve', 'Alpaca'].filter(Boolean) },
      { id: 'trading-journal', name: 'Trading journal', what: 'After each close: the account against simply holding the index', every: 'each trading day', area: 'trading', on: tradeOn, toggle: null, flow: ['Account', 'Index', 'Journal'] },
      { id: 'assistant', name: 'Assistant inbox', what: 'Tasks and notes from your Notion inbox', every: 'every 3 minutes', area: 'notes', on: !!((ctx.cfg.notion?.token && ctx.cfg.notion?.database) || (db.data.assistant?.notion?.token && db.data.assistant?.notion?.database)), toggle: null, flow: ['Notion', 'Your PC', 'To Do and Notes'] }
    ];
    return list.map((a) => { const r = runs(a.id); return { ...a, runs: r, health: health(r, a.on), last: r.at(-1) ?? null }; });
  }
  const routes = {
    'GET /api/automations': (_b, u) => (isAdmin(u) ? [200, { list: view() }] : [403, { error: 'Only the owner can do this', code: 'owner' }]),
    // Only real switches: pause the bank feed; the strategy suggesting trades (off = only the Claude bot suggests)
    'POST /api/automations/toggle': (b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      if (b.key === 'bank' && db.data.settings.bank) { db.data.settings.bank.paused = !b.on; db.save(); }
      else if (b.key === 'signals' && db.data.trading?.settings) { db.data.trading.settings.pipeline = b.on ? 'code' : 'claude'; db.save(); }
      else return [400, { error: "That one can't be switched here" }];
      return [200, { list: view() }];
    }
  };
  return { record, routes, view };
}
