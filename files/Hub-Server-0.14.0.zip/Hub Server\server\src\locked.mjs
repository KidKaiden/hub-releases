// When Windows can't open the master key (Windows was reinstalled, or the data moved to a new PC), the server
// starts locked: nothing can be read, nobody can sign in. It shows one page, on this PC only, where the owner types
// the recovery key. Then Windows locks the key again for next time and the server restarts normally.
import { createServer } from 'node:http';
import { fileRoutes } from './files.mjs';

const local = (ip) => /^(::1|127\.|::ffff:127\.)/.test(String(ip ?? ''));
const page = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hub is locked</title><style>
:root{color-scheme:dark}body{margin:0;font:16px/1.5 system-ui,sans-serif;background:#0F1A16;color:#E8F2EE}
main{max-width:520px;margin:0 auto;padding:40px 20px}h1{font-size:24px;margin:0 0 6px}p{color:#A9BDB5}
input{width:100%;box-sizing:border-box;font:600 20px/1 ui-monospace,monospace;letter-spacing:2px;padding:14px;border-radius:12px;border:1px solid #2E4A40;background:#132520;color:#fff;text-transform:uppercase}
button{margin-top:14px;width:100%;padding:14px;border:0;border-radius:12px;background:#0A6E4F;color:#fff;font:600 17px system-ui;cursor:pointer}
#msg{min-height:24px;margin-top:12px}.bad{color:#FF9B8F}.ok{color:#7FE0B5}ol{color:#A9BDB5;padding-left:20px}
</style></head><body><main>
<h1>Your Hub is locked</h1>
<p>Everything on this server is encrypted. Windows couldn't open its key this time (Windows was reinstalled, or the data was moved to a new PC), so it needs your <b>recovery key</b>: the 25 letters and numbers you saved when you made it.</p>
<form id="f"><label for="c">Recovery key</label><br><input id="c" autocomplete="off" spellcheck="false" placeholder="XXXXX-XXXXX-XXXXX-XXXXX-XXXXX" autofocus>
<button>Unlock</button></form><p id="msg" role="status"></p>
<ol><li>This only works on the PC itself (here), never from a phone or outside.</li><li>After it opens, Hub starts again by itself in about 15 seconds. Then open Hub as usual.</li></ol>
<script>
f.onsubmit=async(e)=>{e.preventDefault();msg.className='';msg.textContent='Checking…';
const r=await fetch('/api/recover',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({code:c.value})}).then(r=>r.json()).catch(()=>({error:"Can't reach the server"}));
if(r.ok){msg.className='ok';msg.textContent='Unlocked. Hub is starting again…';setTimeout(()=>location.href='/',15000)}else{msg.className='bad';msg.textContent=r.error}};
</script></main></body></html>`;

export function lockedServer(cfg, keys, { log = console.log, exit = (n) => process.exit(n) } = {}) {
  let tries = [];
  const files = fileRoutes(cfg, log, (res) => { res.writeHead(404); res.end(); });
  const send = (res, code, body, type = 'application/json') => { res.writeHead(code, { 'content-type': type, 'cache-control': 'no-store', 'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type, authorization', 'x-frame-options': 'DENY' }); res.end(type === 'application/json' ? JSON.stringify(body) : body); };
  const server = createServer(async (req, res) => {
    const path = new URL(req.url, 'http://x').pathname;
    const ip = req.socket.remoteAddress;
    if (req.method === 'OPTIONS') return send(res, 204, {});
    if (path === '/api/health') return send(res, 200, { ok: true, locked: true, api: 2, server: { id: 'locked', name: 'Hub (locked)' }, hasAccounts: true });
    if (path === '/api/recover' && req.method === 'POST') {
      if (!local(ip)) return send(res, 403, { error: 'Unlock it on the PC itself, at http://localhost:' + cfg.port, code: 'home' });
      const now = Date.now();
      tries = tries.filter((t) => now - t < 10 * 60_000);
      if (tries.length >= 10) return send(res, 429, { error: 'Too many tries. Wait 10 minutes' });
      tries.push(now);
      let s = ''; for await (const c of req) { s += c; if (s.length > 2000) break; }
      let code = ''; try { code = JSON.parse(s).code; } catch { /* empty */ }
      if (!keys.unlock(code)) return send(res, 403, { error: "That recovery key isn't right. Check each group of 5" });
      log(`${new Date().toISOString()} unlocked with the recovery key; starting again`);
      send(res, 200, { ok: true });
      setTimeout(() => exit(0), 500); // the keeper (server-run.ps1) starts the server again, now unlocked
      return;
    }
    if (path.startsWith('/api/')) return send(res, 423, { error: 'Hub is locked: on the PC, open http://localhost:' + cfg.port + '/unlock and type the recovery key', code: 'locked' });
    if (path === '/unlock' || (path === '/' && local(ip))) return send(res, 200, page, 'text/html; charset=utf-8');
    if (files(req, res, path)) return;
    send(res, 423, page, 'text/html; charset=utf-8');
  });
  return { server, start: (port = cfg.port) => new Promise((r) => server.listen(port, cfg.host, () => r(server.address().port))) };
}
