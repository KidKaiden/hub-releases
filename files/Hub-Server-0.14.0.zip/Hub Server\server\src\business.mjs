// Finance > Business partners. A partner is a Hub friend invited to one business or to all of yours; nothing is
// shared until they accept, and either of you can end it. Roles: view (see only), edit (add and change entries,
// invoices, products...), full (also the business's own settings and categories). Only the owner can delete a
// business or change who it's shared with. A partner sees only the businesses they were invited to: never the owner's
// personal finance, bank connections or other businesses. Everything here is enforced on the server.
import { randomUUID } from 'node:crypto';
import { record } from './history.mjs';

const BIZ = 'business';
/** Which business a record belongs to */
export const bizOf = (rec) => (rec?.data?.kind === 'biz' ? rec.id : rec?.data?.biz);
const covers = (p, bizId) => p.scope === 'all' || (Array.isArray(p.scope) && p.scope.includes(bizId));
const list = (db) => (db.data.bizPartners ??= []);

/** What this account may do with a business record: owner, full, edit, view, or nothing */
export function bizAccess(db, rec, uid) {
  if (!rec || rec.col !== BIZ) return null;
  if (rec.owner === uid) return 'owner';
  const bizId = bizOf(rec);
  const p = list(db).find((x) => x.status === 'accepted' && x.from === rec.owner && x.to === uid && covers(x, bizId));
  return p ? p.role : null;
}
/** May this account write this change? (view never; a business's own record only with full; deleting it only the owner) */
export function bizMayWrite(db, incoming, current, uid) {
  const target = current ?? incoming;
  const a = bizAccess(db, { ...target, owner: target.owner ?? uid }, uid);
  if (a === 'owner') return true;
  if (a !== 'edit' && a !== 'full') return false;
  if (bizOf(target) !== bizOf(incoming)) return false; // can't move it into a business they can't see
  if ((incoming.data?.kind ?? target.data?.kind) === 'biz') return a === 'full' && !incoming.deleted;
  return true;
}

export function businessRoutes(ctx) {
  const { db } = ctx;
  const users = () => db.data.users;
  const person = (id) => { const u = users()[id]; return u ? { accountId: u.id, username: u.username, name: u.name || u.username } : { accountId: id, username: '', name: 'Someone' }; };
  const friends = (a, b) => (db.data.friends ?? []).some((f) => f.status === 'accepted' && ((f.from === a && f.to === b) || (f.from === b && f.to === a)));
  const note = (u, what) => record(db, { user: u.id, username: u.username, kind: 'action', what });
  const ROLES = new Set(['view', 'edit', 'full']);
  const scopeOk = (s) => s === 'all' || (Array.isArray(s) && s.length > 0 && s.length <= 200 && s.every((x) => typeof x === 'string' && x.length < 120));
  const share = (v) => (v === undefined || v === null || v === '' ? undefined : Math.max(0, Math.min(100, Math.round(Number(v) * 10) / 10)));
  // Send the businesses now shared to the partner on their next sync (their copies may be older than their cursor)
  const resend = (p) => { for (const r of Object.values(db.data.recs)) if (r.rec.col === BIZ && r.rec.owner === p.from && covers(p, bizOf(r.rec))) r.seq = db.nextSeq(); };
  const view = (p, uid) => ({ id: p.id, scope: p.scope, role: p.role, share: p.share, names: p.names ?? {}, status: p.status, created: p.created, answered: p.answered ?? null, mine: p.from === uid, from: person(p.from), to: person(p.to) });

  return {
    /** Invites I sent and invites to me, with their status */
    'GET /api/business/partners': (_b, u) => [200, { partners: list(db).filter((p) => p.from === u.id || p.to === u.id).map((p) => view(p, u.id)) }],
    'POST /api/business/invite': (b, u) => {
      const to = String(b.accountId ?? '');
      if (!users()[to] || to === u.id) return [404, { error: 'Pick one of your friends' }];
      if (!friends(u.id, to)) return [403, { error: 'Only friends can be partners. Add them as a friend in Hub > Sharing first' }];
      if (!ROLES.has(b.role)) return [400, { error: 'Choose what they can do' }];
      if (!scopeOk(b.scope)) return [400, { error: 'Choose a business, or all of them' }];
      if (list(db).some((p) => p.from === u.id && p.to === to)) return [409, { error: 'They already have an invite from you. Change it instead' }];
      const p = { id: randomUUID(), from: u.id, to, scope: b.scope, role: b.role, share: share(b.share), names: typeof b.names === 'object' && b.names ? Object.fromEntries(Object.entries(b.names).slice(0, 200).map(([k, v]) => [k, String(v).slice(0, 80)])) : {}, status: 'pending', created: Date.now() };
      list(db).push(p);
      note(u, `invited ${person(to).username} as a business partner`);
      db.save();
      return [200, view(p, u.id)];
    },
    'POST /api/business/answer': (b, u) => {
      const p = list(db).find((x) => x.id === b.id && x.to === u.id && x.status === 'pending');
      if (!p) return [404, { error: 'That invite has gone' }];
      if (b.accept) { p.status = 'accepted'; p.answered = Date.now(); resend(p); note(u, `became a business partner of ${person(p.from).username}`); }
      else { db.data.bizPartners = list(db).filter((x) => x !== p); note(u, 'said no to a business partner invite'); }
      db.save();
      return [200, { ok: true }];
    },
    /** The owner changes which businesses, the role or the share (it stays accepted if it was) */
    'POST /api/business/change': (b, u) => {
      const p = list(db).find((x) => x.id === b.id && x.from === u.id);
      if (!p) return [404, { error: 'That partner has gone' }];
      if (b.role !== undefined) { if (!ROLES.has(b.role)) return [400, { error: 'Choose what they can do' }]; p.role = b.role; }
      if (b.scope !== undefined) { if (!scopeOk(b.scope)) return [400, { error: 'Choose a business, or all of them' }]; p.scope = b.scope; }
      if (b.share !== undefined) p.share = share(b.share);
      if (b.names && typeof b.names === 'object') p.names = { ...(p.names ?? {}), ...Object.fromEntries(Object.entries(b.names).slice(0, 200).map(([k, v]) => [k, String(v).slice(0, 80)])) };
      if (p.status === 'accepted') resend(p);
      note(u, `changed what ${person(p.to).username} can see or do`);
      db.save();
      return [200, view(p, u.id)];
    },
    /** Either side ends it */
    'POST /api/business/leave': (b, u) => {
      const p = list(db).find((x) => x.id === b.id && (x.from === u.id || x.to === u.id));
      if (!p) return [404, { error: 'That partner has gone' }];
      db.data.bizPartners = list(db).filter((x) => x !== p);
      note(u, p.from === u.id ? `removed ${person(p.to).username} as a business partner` : `stopped being a business partner of ${person(p.from).username}`);
      db.save();
      return [200, { ok: true }];
    }
  };
}
