// Field by field merging, the server's copy of packages/core/src/data.svelte.ts mergeFields (keep them the same).
// Records whose data carries `clock` (when each field last changed) are merged field by field, so two people
// changing the same shopping item on two phones each keep their change. Others: the newest whole record wins.
export const hasClock = (d) => !!d && typeof d === 'object' && !!d.clock && typeof d.clock === 'object';
/** Same content, whatever order the fields are in */
const canon = (v) => (Array.isArray(v) ? v.map(canon) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canon(v[k])])) : v);
export const same = (a, b) => JSON.stringify(canon(a)) === JSON.stringify(canon(b));

export function mergeFields(a, b, aNewer) {
  const ca = a.clock ?? {}, cb = b.clock ?? {};
  const out = {}, clock = {};
  for (const f of new Set([...Object.keys(a), ...Object.keys(b), ...Object.keys(ca), ...Object.keys(cb)])) {
    if (f === 'clock') continue;
    const ta = ca[f] ?? 0, tb = cb[f] ?? 0;
    const src = ta > tb || (ta === tb && aNewer) ? a : b;
    if (src[f] !== undefined) out[f] = src[f];
    if (ta || tb) clock[f] = Math.max(ta, tb);
  }
  out.clock = clock;
  return out;
}
