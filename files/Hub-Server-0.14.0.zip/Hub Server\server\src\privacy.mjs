// Hub > Privacy and the Hub browser extension (Kaiden, 2026-11-13).
//  - Cookie refusal: the extension says no to cookie banners by itself. Its switch lives here (one per person), and
//    each browser that has it reports how many banners it refused, so Privacy shows which devices really work.
//  - One-off identities: made-up name, a free temporary email (with its inbox) and a password for a site you'll use
//    once. They're kept in a vault locked with the person's own Identities password ON THEIR DEVICE: the server only
//    ever holds locked data it can't read. A browser adds a new identity by sealing it to the vault's public key
//    (only the unlocked vault can open it); Hub then files it.
//  - The temporary email: mail.tm's free public API, called from here (so browsers need no extra permission).
// A browser joins with a six-character code made in Hub > Privacy, and gets its own key that opens only /api/ext/*.
import { randomBytes, createHash, randomUUID } from 'node:crypto';
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, resolve, dirname, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const EXT_DIR = resolve(here, '..', '..', 'tools', 'extension', 'hub');
const hash = (t) => createHash('sha256').update(String(t)).digest('hex');
const today = () => new Date().toISOString().slice(0, 10);
const str = (v, max) => String(v ?? '').slice(0, max);
const blob = (v) => (v && typeof v.iv === 'string' && typeof v.ct === 'string' && v.iv.length <= 64 && v.ct.length <= 200_000 ? { iv: v.iv, ct: v.ct } : null);

export function privacy(ctx) {
  const { db, cfg } = ctx;
  const base = cfg.privacy?.mailBase ?? 'https://api.mail.tm';
  const all = () => (db.data.privacy ??= {});
  const mine = (id) => {
    const p = (all()[id] ??= {});
    p.settings ??= { cookies: false, identities: true, asked: false };
    p.devices ??= [];
    p.pairs ??= [];
    p.vault ??= { meta: null, items: {}, inbox: [] };
    return p;
  };
  const deviceView = (d) => ({ id: d.id, name: d.name, browser: d.browser, kind: d.kind, created: d.created, lastSeen: d.lastSeen, refusedToday: d.day === today() ? d.today : 0, refusedWeek: week(d) });
  const week = (d) => (d.days ?? []).filter((x) => x.day >= new Date(Date.now() - 6 * 86_400_000).toISOString().slice(0, 10)).reduce((s, x) => s + x.n, 0);

  // ---------- The temporary email (mail.tm) ----------
  async function mailFetch(path, { method = 'GET', body, token } = {}) {
    const r = await fetch(`${base}${path}`, { method, headers: { accept: 'application/json', 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(15_000) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(j?.detail || j?.message || `The email service said ${r.status}`); e.status = r.status; throw e; }
    return j;
  }
  const list = (j) => (Array.isArray(j) ? j : j?.['hydra:member'] ?? []);
  async function newMailbox() {
    const domains = list(await mailFetch('/domains')).filter((d) => d.isActive !== false);
    if (!domains.length) throw new Error('The email service has no addresses to give out right now');
    const words = ['quiet', 'brisk', 'amber', 'otter', 'maple', 'cloud', 'lunar', 'pebble', 'fern', 'comet', 'river', 'tulip', 'cedar', 'hazel'];
    const pick = () => words[randomBytes(1)[0] % words.length];
    const address = `${pick()}.${pick()}${randomBytes(2).readUInt16BE() % 1000}@${domains[0].domain}`;
    const password = randomBytes(12).toString('base64url');
    await mailFetch('/accounts', { method: 'POST', body: { address, password } });
    return { address, password };
  }
  async function token(address, password) { return (await mailFetch('/token', { method: 'POST', body: { address, password } })).token; }
  async function inbox(address, password) {
    const t = await token(address, password);
    return list(await mailFetch('/messages', { token: t })).slice(0, 30).map((m) => ({ id: m.id, from: m.from?.name || m.from?.address || 'Someone', subject: m.subject || '(no subject)', intro: m.intro ?? '', at: m.createdAt, seen: !!m.seen }));
  }
  async function readMail(address, password, id) {
    const t = await token(address, password);
    const m = await mailFetch(`/messages/${encodeURIComponent(id)}`, { token: t });
    const text = String(m.text || '').slice(0, 20_000) || String((Array.isArray(m.html) ? m.html.join('\n') : m.html) || '').replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 20_000);
    const links = [...new Set((String(m.text || '') + ' ' + String(Array.isArray(m.html) ? m.html.join(' ') : m.html || '')).match(/https?:\/\/[^\s"'<>)]+/g) ?? [])].slice(0, 12);
    return { subject: m.subject || '(no subject)', from: m.from?.name || m.from?.address || 'Someone', at: m.createdAt, text, links };
  }
  const mailErr = (e) => [502, { error: `The temporary email service didn't answer: ${e.message}. Try again in a minute` }];
  const mailRoutes = (prefix) => ({
    [`POST ${prefix}/mail/new`]: async () => { try { return [200, await newMailbox()]; } catch (e) { return mailErr(e); } },
    [`POST ${prefix}/mail/inbox`]: async (b) => { try { return [200, { messages: await inbox(str(b.address, 200), str(b.password, 200)) }]; } catch (e) { return mailErr(e); } },
    [`POST ${prefix}/mail/read`]: async (b) => { try { return [200, await readMail(str(b.address, 200), str(b.password, 200), str(b.id, 100))]; } catch (e) { return mailErr(e); } }
  });

  // ---------- A browser with the extension, by its key ----------
  function extUser(tok) {
    if (!/^hubext_/.test(tok ?? '')) return null;
    const h = hash(tok);
    for (const [id, p] of Object.entries(all())) {
      const d = (p.devices ?? []).find((x) => x.tokenHash === h);
      if (d && db.data.users[id] && !db.data.users[id].disabled) { d.lastSeen = Date.now(); return { ...db.data.users[id], extDevice: d.id }; }
    }
    return null;
  }

  const routes = {
    // ---------- Hub > Privacy ----------
    'GET /api/privacy': (_b, u) => {
      const p = mine(u.id);
      const ds = p.devices.map(deviceView);
      return [200, { settings: p.settings, devices: ds, refusedToday: ds.reduce((s, d) => s + d.refusedToday, 0), refusedWeek: ds.reduce((s, d) => s + d.refusedWeek, 0), vault: { set: !!p.vault.meta, items: Object.keys(p.vault.items).length, inbox: p.vault.inbox.length } }];
    },
    'POST /api/privacy/settings': (b, u) => {
      const s = mine(u.id).settings;
      for (const k of ['cookies', 'identities', 'asked']) if (typeof b[k] === 'boolean') s[k] = b[k];
      db.save();
      return [200, { settings: s }];
    },
    /** A six-character code to join a browser (10 minutes) */
    'POST /api/privacy/pair': (_b, u) => {
      const p = mine(u.id);
      const code = randomBytes(4).toString('base64').replace(/[^A-Za-z0-9]/g, '').slice(0, 6).toUpperCase().padEnd(6, 'X');
      p.pairs = [...p.pairs.filter((x) => x.expires > Date.now()), { code, expires: Date.now() + 10 * 60_000 }];
      db.save();
      return [200, { code, expires: Date.now() + 10 * 60_000 }];
    },
    'POST /api/privacy/devices/remove': (b, u) => {
      const p = mine(u.id);
      const before = p.devices.length;
      p.devices = p.devices.filter((d) => d.id !== b.id);
      db.save();
      return before === p.devices.length ? [404, { error: 'That device has gone' }] : [200, { ok: true }];
    },
    /** The extension's files, zipped, to add it to a browser by hand (Edge and Chrome: Load unpacked) */
    'GET /api/privacy/extension': () => {
      if (!existsSync(EXT_DIR)) return [404, { error: "The extension's files aren't on this server" }];
      const files = walk(EXT_DIR).map((f) => ({ name: relative(EXT_DIR, f).replace(/\\/g, '/'), data: readFileSync(f) }));
      return [200, { name: 'Hub-extension.zip', data: zip(files).toString('base64'), version: JSON.parse(readFileSync(join(EXT_DIR, 'manifest.json'), 'utf8')).version }];
    },

    // ---------- Identities: locked on the device, kept here locked ----------
    'GET /api/privacy/vault': (_b, u) => {
      const v = mine(u.id).vault;
      return [200, { meta: v.meta, items: Object.entries(v.items).map(([id, x]) => ({ id, ...x })), inbox: v.inbox }];
    },
    /** First time (or start again, which wipes what's there): the salt, a check, the public key, the locked private key */
    'POST /api/privacy/vault/setup': (b, u) => {
      const v = mine(u.id).vault;
      if (v.meta && b.restart !== true) return [409, { error: 'Identities are already set up' }];
      const check = blob(b.check), priv = blob(b.priv);
      if (typeof b.salt !== 'string' || b.salt.length > 64 || !check || !priv || typeof b.pub !== 'object' || !b.pub) return [400, { error: 'Missing parts of the lock' }];
      v.meta = { salt: b.salt, iter: Math.max(100_000, Math.min(2_000_000, Number(b.iter) || 310_000)), check, priv, pub: { kty: str(b.pub.kty, 8), crv: str(b.pub.crv, 8), x: str(b.pub.x, 100), y: str(b.pub.y, 100), ext: true } };
      if (b.restart === true) { v.items = {}; v.inbox = []; }
      db.save();
      return [200, { ok: true }];
    },
    'POST /api/privacy/vault/put': (b, u) => {
      const v = mine(u.id).vault;
      if (!v.meta) return [409, { error: 'Set up Identities first' }];
      const x = blob(b);
      if (!x) return [400, { error: 'Missing the locked identity' }];
      if (Object.keys(v.items).length >= 2000 && !v.items[b.id]) return [413, { error: 'Identities are full (2000)' }];
      const id = typeof b.id === 'string' && /^[\w-]{4,60}$/.test(b.id) ? b.id : randomUUID();
      v.items[id] = { ...x, updated: Date.now() };
      db.save();
      return [200, { id }];
    },
    'POST /api/privacy/vault/remove': (b, u) => {
      const v = mine(u.id).vault;
      if (!v.items[b.id]) return [404, { error: 'That identity has gone' }];
      delete v.items[b.id];
      db.save();
      return [200, { ok: true }];
    },
    /** Hub filed these new ones from browsers into the vault */
    'POST /api/privacy/vault/inbox/clear': (b, u) => {
      const v = mine(u.id).vault;
      const ids = new Set(Array.isArray(b.ids) ? b.ids.map(String) : []);
      v.inbox = v.inbox.filter((x) => !ids.has(x.id));
      db.save();
      return [200, { ok: true }];
    },
    ...mailRoutes('/api/privacy'),

    // ---------- The extension (its own key) ----------
    /** Join a browser with the code from Hub > Privacy (no sign-in: the code is the proof) */
    'POST /api/ext/pair': (b) => {
      const code = str(b.code, 12).trim().toUpperCase();
      if (!/^[A-Z0-9]{6}$/.test(code)) return [400, { error: 'The code is the six letters and numbers shown in Hub > Privacy', field: 'code' }];
      const hit = Object.entries(all()).find(([, p]) => (p.pairs ?? []).some((x) => x.code === code && x.expires > Date.now()));
      if (!hit) return [404, { error: 'That code is wrong or has run out. Make a new one in Hub > Privacy', field: 'code' }];
      const [uid, p] = hit;
      p.pairs = p.pairs.filter((x) => x.code !== code);
      const tok = `hubext_${randomBytes(24).toString('base64url')}`;
      const kind = b.kind === 'phone' ? 'phone' : 'pc';
      const dev = { id: randomUUID(), name: str(b.name, 40) || (kind === 'phone' ? 'Phone' : 'PC'), browser: str(b.browser, 30) || 'Browser', kind, tokenHash: hash(tok), created: Date.now(), lastSeen: Date.now(), day: today(), today: 0, days: [] };
      mine(uid).devices.push(dev);
      db.save();
      return [200, { token: tok, device: dev.id, name: db.data.users[uid]?.name || db.data.users[uid]?.username }];
    },
    /** What the extension should do now (and a sign it's alive) */
    'GET /api/ext/state': (_b, u) => {
      const p = mine(u.id);
      db.save();
      return [200, { settings: p.settings, vault: p.vault.meta ? { set: true, pub: p.vault.meta.pub } : { set: false }, name: u.name || u.username }];
    },
    /** The same two switches as Hub > Privacy (change either, both follow) */
    'POST /api/ext/settings': (b, u) => {
      const s = mine(u.id).settings;
      for (const k of ['cookies', 'identities']) if (typeof b[k] === 'boolean') s[k] = b[k];
      db.save();
      return [200, { settings: s }];
    },
    /** Banners refused since the last report */
    'POST /api/ext/report': (b, u) => {
      const d = mine(u.id).devices.find((x) => x.id === u.extDevice);
      if (!d) return [404, { error: 'This browser was removed from Hub' }];
      const n = Math.max(0, Math.min(500, Math.round(Number(b.refused) || 0)));
      const t = today();
      if (d.day !== t) { d.day = t; d.today = 0; }
      d.today += n;
      d.days = [...(d.days ?? []).filter((x) => x.day !== t && x.day >= new Date(Date.now() - 30 * 86_400_000).toISOString().slice(0, 10)), { day: t, n: d.today }];
      d.lastSeen = Date.now();
      db.save();
      return [200, { ok: true }];
    },
    /** A new one-off identity, sealed to the vault's public key (only the unlocked vault can open it) */
    'POST /api/ext/identity': (b, u) => {
      const v = mine(u.id).vault;
      if (!v.meta) return [409, { error: 'Set up Identities in Hub first' }];
      const s = b.sealed;
      if (!s || typeof s.epk !== 'object' || !blob(s)) return [400, { error: 'Missing the sealed identity' }];
      if (v.inbox.length >= 200) return [413, { error: 'Open Hub > Identities to file the new ones first' }];
      const x = { id: randomUUID(), sealed: { epk: { kty: str(s.epk.kty, 8), crv: str(s.epk.crv, 8), x: str(s.epk.x, 100), y: str(s.epk.y, 100) }, ...blob(s) }, created: Date.now() };
      v.inbox.push(x);
      db.save();
      return [200, { id: x.id }];
    },
    /** For filling saved details on a site: everything locked; the extension unlocks it with the password */
    'GET /api/ext/vault': (_b, u) => {
      const v = mine(u.id).vault;
      return [200, { meta: v.meta, items: Object.entries(v.items).map(([id, x]) => ({ id, ...x })) }];
    },
    ...mailRoutes('/api/ext')
  };
  return { routes, extUser };
}

function walk(dir) {
  const out = [];
  for (const n of readdirSync(dir)) { const p = join(dir, n); if (statSync(p).isDirectory()) out.push(...walk(p)); else out.push(p); }
  return out.sort();
}

// A plain ZIP (stored, no compression): enough for a handful of small extension files
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(buf) { let c = 0xffffffff; for (const b of buf) c = CRC[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
export function zip(files) {
  const parts = [], central = [];
  let offset = 0;
  for (const f of files) {
    const name = Buffer.from(f.name, 'utf8'), crc = crc32(f.data), size = f.data.length;
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(0, 8); lh.writeUInt32LE(0, 10);
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(size, 18); lh.writeUInt32LE(size, 22); lh.writeUInt16LE(name.length, 26); lh.writeUInt16LE(0, 28);
    parts.push(lh, name, f.data);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(0, 10); ch.writeUInt32LE(0, 12);
    ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(size, 20); ch.writeUInt32LE(size, 24); ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(offset, 42);
    central.push(ch, name);
    offset += 30 + name.length + size;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...parts, cd, end]);
}
