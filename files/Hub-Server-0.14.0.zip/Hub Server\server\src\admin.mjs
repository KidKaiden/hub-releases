// The owner's console (Hub > Admin): a manager's view of the whole system. What is running, on which device,
// which version, when it last synced, errors, server health and backups, with account history alongside.
// It records WHAT happened, never passwords and never the contents of tasks, notes or finance entries.
import { readFileSync, existsSync, statSync, readdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';
import { networkInterfaces } from 'node:os';
import { hashPassword, hashAnswer, passwordProblem, usernameProblem, cleanUsername, revokeAll, tokenKey } from './auth.mjs';
import { record, filterEvents, toCsv, addr } from './history.mjs';
import { pub, findUser, rules } from './accounts.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const SERVER_VERSION = (() => { try { return JSON.parse(readFileSync(join(here, '..', 'package.json'), 'utf8')).version; } catch { return '?'; } })();
const ONLINE_MS = 150_000; // devices sync once a minute
const readJsonSafe = (f) => { try { return JSON.parse(readFileSync(f, 'utf8')); } catch { return null; } };

/** This PC's addresses on the home network (Wi-Fi or cable), the usual 192.168.x.x first. */
export function homeAddresses(nets = networkInterfaces()) {
  const rank = (ip) => (ip.startsWith('192.168.') ? 0 : ip.startsWith('10.') ? 1 : /^172\.(1[6-9]|2\d|3[01])\./.test(ip) ? 2 : 9);
  const ips = Object.entries(nets).flatMap(([name, list]) => (list ?? [])
    .filter((n) => (n.family === 'IPv4' || n.family === 4) && !n.internal && rank(n.address) < 9)
    // Virtual adapters (Hyper-V, WSL, VirtualBox, VPNs) aren't reachable from a phone
    .filter(() => !/vEthernet|WSL|VirtualBox|VMware|Hyper-V|Tailscale|ZeroTier|Loopback/i.test(name))
    .map((n) => n.address));
  return [...new Set(ips)].sort((a, b) => rank(a) - rank(b));
}

/** A temporary password that is easy to read out: three short words and two numbers. */
const WORDS = ['amber', 'river', 'cloud', 'maple', 'stone', 'tiger', 'lemon', 'ocean', 'pixel', 'comet', 'cedar', 'flint', 'lunar', 'mango', 'orbit', 'piano'];
export function tempPassword() {
  const b = randomBytes(5);
  return `${WORDS[b[0] % 16]}-${WORDS[b[1] % 16]}-${WORDS[b[2] % 16]}-${(b[3] % 90) + 10}`;
}

export function adminRoutes(ctx) {
  const { db, cfg, log, stamp, started } = ctx;
  const owners = () => Object.values(db.data.users).filter((u) => u.role === 'owner' && !u.disabled);
  const admin = (fn) => (b, u, meta) => (db.data.roles[u.role]?.admin ? fn(b, u, meta) : [403, { error: 'Only the owner can do this', code: 'owner' }]);
  const act = (u, what, ip, target) => record(db, { user: u.id, username: u.username, kind: 'admin', what: target ? `${what} (${target.username})` : what, ip });

  function overview() {
    const now = Date.now();
    const sessions = Object.values(db.data.tokens).filter((t) => t.expires > now);
    const users = Object.values(db.data.users).map((u) => {
      const mine = sessions.filter((s) => s.userId === u.id).sort((a, b) => b.lastSeen - a.lastSeen);
      return {
        ...pub(u), disabled: !!u.disabled, created: u.created, lastSignIn: u.lastSignIn ?? null, space: ctx.space?.info(u) ?? null, spaceAsked: u.spaceAsked ?? null,
        lastSeen: mine[0]?.lastSeen ?? null, online: mine.some((s) => now - s.lastSeen < ONLINE_MS),
        sessions: mine.map((s) => ({ device: s.device, ip: s.ip, created: s.created, lastSeen: s.lastSeen, online: now - s.lastSeen < ONLINE_MS, sync: s.sync ?? null }))
      };
    });
    // Per app: when it was last opened and by whom, from the history
    const apps = {};
    for (let i = db.data.events.length - 1; i >= 0; i--) {
      const e = db.data.events[i];
      if (!e.app) continue;
      const a = (apps[e.app] ??= { app: e.app, last: e.t, by: e.username, opens7: 0, actions7: 0 });
      if (now - e.t < 7 * 86400000) { if (e.kind === 'open') a.opens7++; else if (e.kind === 'action') a.actions7++; }
    }
    const backups = db.backups();
    const latest = cfg.updatesDir ? readJsonSafe(join(cfg.updatesDir, 'latest.json')) : null;
    const web = cfg.webDir ? readJsonSafe(join(cfg.webDir, 'version.json')) : null;
    let apk = null;
    try {
      const ver = (f) => f.match(/^Hub-(\d+)\.(\d+)\.(\d+)\.apk$/)?.slice(1).map(Number);
      apk = readdirSync(cfg.phoneDir ?? '').filter(ver).sort((a, b) => { const x = ver(a), y = ver(b); return x[0] - y[0] || x[1] - y[1] || x[2] - y[2]; }).at(-1)?.slice(4, -4) ?? null;
    } catch { /* no folder */ }
    const recent = db.data.errors.slice(-50).reverse();
    return {
      server: {
        id: db.data.server.id, name: db.data.server.name, version: SERVER_VERSION, node: process.version,
        started, uptime: now - started, dbSize: existsSync(db.file) ? statSync(db.file).size : 0,
        accounts: users.length, records: Object.keys(db.data.recs).length,
        lastBackup: backups[0] ?? null, errors24h: db.data.errors.filter((e) => now - e.t < 86400000).length,
        releases: { pc: latest?.version ?? null, android: apk, web: web?.version ?? null }
      },
      // Links to send people: the iPhone opens the Hub page (the outside link works anywhere, home only on Wi-Fi);
      // Android installs the app from the release site (anywhere) or the home server's /phone page
      links: { home: homeAddresses().map((ip) => `http://${ip}:${cfg.port}`), outside: cfg.publicUrl || '', releaseSite: cfg.releaseSite || '' },
      // Never the unlimited-space password, even as its hash
      settings: { ...db.data.settings, unlockHash: undefined }, rules: rules(db), roles: db.data.roles,
      // The main server, or someone's own (which gets the simpler Admin), and its standing in the Hub network
      network: ctx.net?.status() ?? { main: true, status: 'ok' },
      users, apps: Object.values(apps).sort((a, b) => b.last - a.last), errors: recent, backups: backups.slice(0, 40)
    };
  }

  return {
    'GET /api/admin/overview': admin(() => [200, overview()]),
    'GET /api/admin/history': admin((_b, _u, { q }) => [200, { events: filterEvents(db, q) }]),
    'GET /api/admin/history.csv': admin((_b, u, { q, ip }) => {
      act(u, 'exported the history', ip);
      return [200, toCsv(filterEvents(db, q)), { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="hub-history-${new Date().toISOString().slice(0, 10)}.csv"` }];
    }),

    'POST /api/admin/users': admin((b, u, { ip }) => {
      const username = cleanUsername(b.username);
      const uerr = usernameProblem(username);
      if (uerr) return [400, { error: uerr, field: 'username' }];
      if (findUser(db, username)) return [409, { error: 'That username is taken', field: 'username' }];
      const role = db.data.roles[b.role] ? b.role : 'user';
      const temp = b.password ? String(b.password) : tempPassword();
      const perr = passwordProblem(temp, { username, name: b.name }, rules(db).passwordMin);
      if (perr) return [400, { error: perr, field: 'password' }];
      const nu = ctx.makeUser({ username, name: b.name, password: temp, role, email: b.email });
      nu.mustChange = true; // they choose their own password at first sign-in
      db.save();
      act(u, 'created an account', ip, nu);
      log(`${stamp()} ${u.name} created the account ${nu.username}`);
      return [200, { user: pub(nu), temp }];
    }),

    'POST /api/admin/user': admin((b, u, { ip }) => {
      const t = db.data.users[b.id];
      if (!t) return [404, { error: 'No such account' }];
      const lastOwner = t.role === 'owner' && owners().length <= 1;
      switch (b.action) {
        case 'reset-password': {
          const temp = b.password ? String(b.password) : tempPassword();
          const perr = passwordProblem(temp, t, rules(db).passwordMin);
          if (perr) return [400, { error: perr, field: 'password' }];
          t.pw = hashPassword(temp); t.mustChange = true;
          revokeAll(db, t.id);
          act(u, 'reset a password', ip, t);
          return [200, { user: pub(t), temp }];
        }
        case 'set-question': {
          const q = String(b.question ?? '').trim(), a = String(b.answer ?? '').trim();
          if (q.length < 5 || a.length < 2) return [400, { error: 'Write a question and an answer' }];
          t.question = q.slice(0, 160); t.answer = hashAnswer(a);
          act(u, 'changed a security question', ip, t);
          break;
        }
        case 'disable':
          if (t.id === u.id) return [400, { error: "You can't turn off your own account" }];
          if (lastOwner) return [400, { error: "You can't turn off the only owner" }];
          t.disabled = true; revokeAll(db, t.id);
          act(u, 'turned off an account', ip, t);
          break;
        case 'enable': t.disabled = false; act(u, 'turned on an account', ip, t); break;
        case 'signout': revokeAll(db, t.id); act(u, 'signed an account out of every device', ip, t); break;
        case 'role':
          if (!db.data.roles[b.role]) return [400, { error: 'No such role' }];
          if (lastOwner && b.role !== 'owner') return [400, { error: 'Keep at least one owner' }];
          t.role = b.role; act(u, `made an account ${db.data.roles[b.role].label.toLowerCase()}`, ip, t);
          break;
        case 'rename': t.name = String(b.name ?? '').trim().slice(0, 60) || t.name; act(u, 'renamed an account', ip, t); break;
        case 'delete':
          if (t.id === u.id) return [400, { error: "You can't delete your own account" }];
          if (lastOwner) return [400, { error: "You can't delete the only owner" }];
          // Their records stay in the database and in backups (never wiped), but nobody can sign in as them
          revokeAll(db, t.id);
          db.data.links = db.data.links.filter((l) => l.from !== t.id && l.to !== t.id);
          delete db.data.users[t.id];
          act(u, 'deleted an account', ip, t);
          log(`${stamp()} ${u.name} deleted the account ${t.username}`);
          db.save();
          return [200, { ok: true }];
        default: return [400, { error: 'Unknown action' }];
      }
      db.save();
      return [200, { user: pub(t) }];
    }),

    'POST /api/admin/settings': admin((b, u, { ip }) => {
      const s = db.data.settings;
      if (b.serverName !== undefined) db.data.server.name = String(b.serverName).trim().slice(0, 40) || db.data.server.name;
      if (b.passwordMin !== undefined) s.passwordMin = Math.min(64, Math.max(4, Math.round(Number(b.passwordMin) || 7)));
      if (b.securityLevel !== undefined) s.securityLevel = b.securityLevel === 'stricter' ? 'stricter' : 'home';
      if (b.sessionDays !== undefined) s.sessionDays = Math.min(3650, Math.max(1, Math.round(Number(b.sessionDays) || 365)));
      db.save();
      act(u, 'changed server settings', ip);
      return [200, { settings: s, rules: rules(db), server: { id: db.data.server.id, name: db.data.server.name } }];
    }),

    'GET /api/admin/backups': admin(() => [200, { backups: db.backups() }]),
    'POST /api/admin/backup': admin((_b, u, { ip }) => { const name = db.backupNow(); act(u, 'made a backup', ip); return [200, { name, backups: db.backups() }]; }),
    'GET /api/admin/backup': admin((_b, u, { q, ip }) => {
      const p = db.backupPath(q.get('name') ?? '');
      if (!p || !existsSync(p)) return [404, { error: 'No such backup' }];
      act(u, 'downloaded a backup', ip);
      return [200, readFileSync(p), { 'content-type': p.endsWith('.json') ? 'application/json' : 'application/octet-stream', 'content-disposition': `attachment; filename="${q.get('name')}"` }];
    }),
    // A backup file from another PC (or saved elsewhere): put in the backup folder, then restored like the others
    'POST /api/admin/backup/upload': admin((b, u, { ip }) => {
      const buf = Buffer.from(String(b.data ?? ''), 'base64');
      if (buf.length < 20) return [400, { error: 'Choose a Hub backup file' }];
      const name = db.addBackup ? db.addBackup(buf) : null;
      if (!name) return [400, { error: 'This server cannot take a backup file' }];
      act(u, 'added a backup file', ip);
      return [200, { name, backups: db.backups() }];
    }),
    'POST /api/admin/restore': admin((b, u, { ip, token }) => {
      const k = tokenKey(token), keep = db.data.tokens[k];
      try { db.restore(String(b.name ?? ''), b.code); } catch (e) { return [e.code === 'needs-code' || e.code === 'wrong-code' ? 400 : 404, { error: e.message, code: e.code }]; }
      if (keep && db.data.users[keep.userId]) { db.data.tokens[k] = keep; db.save(); }
      // The owner who restored stays able to act; everyone else syncs again from the restored copy
      record(db, { user: u.id, username: u.username, kind: 'admin', what: `rolled back to ${b.name}`, ip });
      log(`${stamp()} ${u.name} rolled the server back to ${b.name}`);
      return [200, { ok: true, backups: db.backups() }];
    })
  };
}
export { SERVER_VERSION, addr };
