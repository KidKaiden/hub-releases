// What happened, for the owner's console: sign-ins, sign-outs, failed tries, apps opened and simple actions
// ("added a task"). Never passwords and never the contents of tasks, notes or finance entries.
const MAX_EVENTS = 20000;
const MAX_ERRORS = 500;

export const stamp = () => { const d = new Date(); return new Date(d - d.getTimezoneOffset() * 60e3).toISOString().slice(0, 19); };
export const addr = (ip) => String(ip ?? '').replace(/^::ffff:/, '');
export const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

/** Plain names for what a record is, so history says "added 2 tasks" without saying which. */
const NOUN = { tasks: 'task', notes: 'note', bills: 'bill', people: 'person', dates: 'date', reminders: 'reminder', pots: 'pot', chats: 'message', shopping: 'shopping item', business: 'business record', banktx: 'bank payment' };
export const noun = (col) => NOUN[col] ?? (col.startsWith('app:') ? 'setting' : 'item');

export function record(db, e) {
  const ev = {
    t: Date.now(), user: e.user ?? null, username: e.username ?? null, kind: e.kind, what: String(e.what ?? '').slice(0, 120),
    app: e.app ? String(e.app).slice(0, 40) : undefined, device: e.device ? String(e.device).slice(0, 60) : undefined,
    ip: e.ip ? addr(e.ip) : undefined
  };
  db.data.events.push(ev);
  if (db.data.events.length > MAX_EVENTS) db.data.events.splice(0, db.data.events.length - MAX_EVENTS);
  db.save();
  return ev;
}

export function recordError(db, e) {
  db.data.errors.push({ t: Date.now(), method: e.method, path: String(e.path).slice(0, 80), status: e.status, ip: addr(e.ip), user: e.user ?? null, msg: e.msg ? String(e.msg).slice(0, 120) : undefined });
  if (db.data.errors.length > MAX_ERRORS) db.data.errors.splice(0, db.data.errors.length - MAX_ERRORS);
  db.save();
}

/** Turn a sync's accepted changes into "added 2 tasks, completed a task" lines (one event per kind). */
export function summarise(changes) {
  const counts = new Map();
  for (const c of changes) {
    const k = `${c.verb} ${noun(c.col)}`;
    counts.set(k, (counts.get(k) ?? 0) + 1);
  }
  return [...counts.entries()].map(([k, n]) => {
    const [verb, w] = k.split(' ');
    return n === 1 ? `${verb} a${/^[aeiou]/.test(w) ? 'n' : ''} ${w}` : `${verb} ${n} ${w === 'person' ? 'people' : w + 's'}`;
  });
}

export function filterEvents(db, q) {
  const user = q.get('user'), app = q.get('app'), kind = q.get('kind');
  const since = Number(q.get('since') ?? 0);
  const limit = Math.min(5000, Math.max(1, Number(q.get('limit') ?? 500)));
  const out = [];
  for (let i = db.data.events.length - 1; i >= 0 && out.length < limit; i--) {
    const e = db.data.events[i];
    if (user && e.user !== user) continue;
    if (app && e.app !== app) continue;
    if (kind && e.kind !== kind) continue;
    if (since && e.t < since) break;
    out.push(e);
  }
  return out;
}

const cell = (v) => { const s = v == null ? '' : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
export function toCsv(events) {
  const rows = [['time', 'username', 'kind', 'what', 'app', 'device', 'address']];
  for (const e of events) rows.push([new Date(e.t).toISOString(), e.username ?? '', e.kind, e.what, e.app ?? '', e.device ?? '', e.ip ?? '']);
  return rows.map((r) => r.map(cell).join(',')).join('\r\n') + '\r\n';
}
