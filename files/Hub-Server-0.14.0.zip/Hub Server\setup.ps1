# Hub Server: your own Hub server, for your family or group, on a PC of yours.
# Double-click "Set up Hub Server.cmd" (it runs this). Run it again with a newer download to update: your people, their
# things and your settings are kept. Nothing here needs admin rights.
#   Set up Hub Server.cmd             set up, or update
#   Set up Hub Server.cmd -Remove     stop it and stop it starting with Windows (your data stays)
param([string]$Folder, [switch]$Remove, [switch]$Quiet)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
function Say($t, $c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Title($t) { Write-Host ''; Write-Host $t -ForegroundColor Magenta }
function Utf8($path, $text) { [IO.File]::WriteAllText($path, $text, (New-Object System.Text.UTF8Encoding($false))) }
function Ask($q, $default = 'y') {
  if ($Quiet) { return $default -eq 'y' }
  $a = Read-Host "$q $(if ($default -eq 'y') { '[Y/n]' } else { '[y/N]' })"
  if (-not $a) { $a = $default }
  return $a -match '^[yY]'
}
$info = if (Test-Path (Join-Path $here 'hub-server.json')) { Get-Content (Join-Path $here 'hub-server.json') -Raw | ConvertFrom-Json } else { [pscustomobject]@{ version = '?'; mainUrl = ''; releaseSite = '' } }
$remember = Join-Path $env:LOCALAPPDATA 'Hub Server\where.txt'
$lnk = Join-Path ([Environment]::GetFolderPath('Startup')) 'Hub Server.lnk'
$ps = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
$env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')

function Stop-HubServer($root) {
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*run.ps1*' -and $_.CommandLine -like "*$root*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  # The server: node started by run.ps1 through cmd, whose command line holds this folder (its log is in it)
  Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -like '*src*index.mjs*' } | ForEach-Object {
    $parent = Get-CimInstance Win32_Process -Filter "ProcessId=$($_.ParentProcessId)" -ErrorAction SilentlyContinue
    if ($parent.CommandLine -like "*$root*") { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue; Stop-Process -Id $parent.ProcessId -Force -ErrorAction SilentlyContinue }
  }
}
$root = if ($Folder) { $Folder } elseif (Test-Path $remember) { (Get-Content $remember -Raw).Trim() } else { '' }

# ---------- Remove ----------
if ($Remove) {
  if (-not $root) { Say 'Hub Server is not set up on this PC.' Yellow; return }
  Stop-HubServer $root
  if (Test-Path $lnk) { Remove-Item $lnk }
  Say "Hub Server is stopped and no longer starts with Windows." Green
  Say "Your people's data is still in $root\Data. Delete the folder $root yourself if you are sure nobody needs it." Gray
  return
}

Title "Hub Server $($info.version)"
Say 'Your own Hub server, for your family or group. The apps on your phones and computers keep everything here,'
Say 'on this PC: as much space as its drive has, and your bank (if you connect one) stays on your own PC.'
Title 'What it shares with Hub'
if ($info.mainUrl) {
  Say 'It tells the main Hub only: its name, your name, how many people it has, and its version, every few hours.'
  Say "Never anyone's accounts, messages, notes, tasks or money. Hub's owner can pause its link to Hub, but can't see inside it."
} else { Say 'Nothing: this copy is not linked to a main Hub.' }
Title 'What it needs'
Say '- This PC switched on when people want to sync (their apps keep working on their own copy while it is off).'
Say '- Node.js (free). If it is missing, this installs it for you.'
Say '- About 300 MB for the program, plus the space your people use.'
if (-not (Ask "`nSet up Hub Server on this PC?")) { Say 'Nothing was changed.'; return }

# ---------- Where ----------
if (-not $root) {
  $default = Join-Path $env:USERPROFILE 'Hub Server'
  Title 'Where to keep it'
  Say "Everything goes in one folder. A big drive is a good place (for example D:\Hub Server)."
  $typed = if ($Quiet) { '' } else { Read-Host "Folder (press Enter for $default)" }
  $root = if ($typed) { $typed.Trim('"', ' ') } else { $default }
}
$root = [IO.Path]::GetFullPath($root)
New-Item -ItemType Directory -Force $root, (Join-Path $root 'Data'), (Join-Path $root 'Backups'), (Join-Path $root 'Keys'), (Join-Path $root 'Updates') | Out-Null
New-Item -ItemType Directory -Force (Split-Path -Parent $remember) | Out-Null
Utf8 $remember $root
Say "Folder: $root" Green

# ---------- Node.js ----------
Title 'Node.js'
$nodeOk = $false
if (Get-Command node -ErrorAction SilentlyContinue) { $nodeOk = [int]((node -v).TrimStart('v').Split('.')[0]) -ge 20 }
if (-not $nodeOk) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Say 'Node.js is missing, and so is winget (which installs it).' Red
    Say '1. Install Node.js "LTS" from https://nodejs.org (the Windows installer, all the default choices).'
    Say '2. Double-click "Set up Hub Server" again.'
    Start-Process 'https://nodejs.org/en/download'
    return
  }
  if (-not (Ask 'Node.js is needed. Install it now (from Microsoft''s winget)?')) { Say 'Hub Server needs Node.js. Nothing else was changed.' Yellow; return }
  winget install --id OpenJS.NodeJS.LTS -e --silent --accept-package-agreements --accept-source-agreements
  $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
  if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Say 'Node.js was installed, but Windows needs a fresh start of this window. Close it and double-click "Set up Hub Server" again.' Yellow; return }
}
Say "Node.js $(node -v)" Green

# ---------- The program (your data and settings are never in here) ----------
Title 'Putting the program in place'
Stop-HubServer $root
$app = Join-Path $root 'app'; $new = Join-Path $root 'app.new'; $old = Join-Path $root 'app.old'
if (Test-Path $new) { Remove-Item $new -Recurse -Force }
New-Item -ItemType Directory -Force $new | Out-Null
Copy-Item (Join-Path $here 'server') (Join-Path $new 'server') -Recurse
if (Test-Path (Join-Path $here 'web')) { Copy-Item (Join-Path $here 'web') (Join-Path $new 'web') -Recurse }
Copy-Item (Join-Path $here 'run.ps1') (Join-Path $root 'run.ps1') -Force

# Settings: made once, kept on every update (the server's own data lives in Data, never in app)
$settings = Join-Path $root 'settings.env'
if (-not (Test-Path $settings)) {
  $port = 8787
  while (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue) { $port++ }
  $lines = @(
    '# Hub Server settings. Kept when you update. Restart the server after a change (run "Set up Hub Server" again).',
    "PORT=$port",
    'DATA_DIR=../../Data', 'BACKUP_DIR=../../Backups', 'KEYS_DIR=../../Keys', 'UPDATES_DIR=../../Updates', 'WEB_DIR=../web',
    '# The main Hub this server checks in with (name, owner, how many people, version only). Empty: not linked.',
    "MAIN_URL=$($info.mainUrl)"
  )
  Utf8 $settings ($lines -join "`r`n")
} elseif ($info.mainUrl -and -not (Select-String -Path $settings -Pattern '^\s*MAIN_URL\s*=' -Quiet)) {
  Add-Content $settings "`r`nMAIN_URL=$($info.mainUrl)"
}
Copy-Item $settings (Join-Path $new 'server\.env') -Force

Push-Location (Join-Path $new 'server')
$ErrorActionPreference = 'Continue'
npm install --omit=dev --no-audit --no-fund --loglevel=error
$ok = $LASTEXITCODE -eq 0
$ErrorActionPreference = 'Stop'
Pop-Location
if (-not $ok) {
  Remove-Item $new -Recurse -Force
  Say 'The program''s parts did not download (is the internet on?). Nothing changed: your server is as it was. Try again.' Red
  if (Test-Path $app) { Start-Process $ps -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $root 'run.ps1')`" -Root `"$root`"" -WindowStyle Hidden }
  return
}
# Swap: the version before stays in app.old, to go back to if needed
if (Test-Path $old) { Remove-Item $old -Recurse -Force }
if (Test-Path $app) { Rename-Item $app 'app.old' }
Rename-Item $new 'app'
Say 'Program ready. Your data and settings were not touched.' Green

# ---------- Start with Windows, and now ----------
Title 'Starting it'
$runArgs = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $root 'run.ps1')`" -Root `"$root`""
$sh = New-Object -ComObject WScript.Shell
$s = $sh.CreateShortcut($lnk); $s.TargetPath = $ps; $s.Arguments = $runArgs; $s.WorkingDirectory = $root; $s.WindowStyle = 7
$s.Description = 'Hub Server (your own Hub, for your family or group)'; $s.Save()
Start-Process $ps -ArgumentList $runArgs -WindowStyle Hidden
$port = [int]((Select-String -Path $settings -Pattern '^\s*PORT\s*=\s*(\d+)' | Select-Object -First 1).Matches[0].Groups[1].Value)
Say 'If Windows asks whether Node.js may use the network, choose Private networks and Allow (so phones at home can reach it).' Yellow
$up = $false
foreach ($i in 1..40) { try { Invoke-RestMethod "http://localhost:$port/api/health" -TimeoutSec 3 | Out-Null; $up = $true; break } catch { Start-Sleep 2 } }
if (-not $up) { Say "It didn't answer yet. Look in $root\Data\server.log, or run this again." Red; return }

$ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notmatch '^(127|169\.254)\.' -and $_.PrefixOrigin -ne 'WellKnown' } | Select-Object -ExpandProperty IPAddress
Title 'Done'
Say "Hub Server is running, and starts by itself with Windows." Green
Say "On this PC:        http://localhost:$port"
foreach ($ip in $ips) { Say "Phones at home:    http://$($ip):$port" }
Say ''
Say 'Next, in the browser that opens now:'
Say '1. Make your account. The first account on a new server is its owner: you get unlimited space and the Admin for your server.'
Say '2. In Admin > People, make an account for each person, and send them the link (Copy or Email).'
Say '3. Already use Hub on another server? Tap your name > Add account > Change server, and type the address above.'
Say "   Each account remembers its own server, so you can switch between them."
Say ''
Say "To update later: download the newer Hub Server and run it again. Stop it: Set up Hub Server.cmd -Remove"
if (-not $Quiet) { Start-Process "http://localhost:$port" }
