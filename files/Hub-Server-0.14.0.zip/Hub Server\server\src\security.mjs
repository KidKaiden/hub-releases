// Hub > Settings > Security, for the owner (security plan, 2026-11-14). The recovery key: made by itself on the first
// start, shown to the owner (password again, at home only) until they type it back to prove it's written down;
// a new one can be made at any time (the old one stops working).
import { existsSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { checkPassword } from './auth.mjs';
import { record } from './history.mjs';

export function securityRoutes(ctx) {
  const { db, log, stamp } = ctx;
  const keys = db.keys;
  const owner = (fn) => (b, u, meta) => (db.data.roles[u.role]?.admin ? fn(b, u, meta) : [403, { error: 'Only the owner can do this', code: 'owner' }]);
  const recheck = (b, u) => (checkPassword(String(b.password ?? ''), u.pw) ? null : [403, { error: 'That password is not right', field: 'password', code: 'password' }]);
  const home = (meta) => (meta?.public ? [403, { error: 'Do this at home, on the PC or on the home Wi-Fi: never through the outside link', code: 'home' }] : null);
  const state = () => keys ? ({
    key: { id: keys.id, lockedBy: keys.how === 'windows' ? 'windows' : 'none' },
    recovery: { ...keys.recovery, saved: keys.saved, pending: !!keys.pendingCode },
    settings: settings()
  }) : { key: null, recovery: { has: false, saved: false, pending: false }, settings: settings() };
  const settings = () => ({ secureOnly: db.data.settings.secureOnly !== false, publicUrl: ctx.cfg.publicUrl || null, idleDays: db.data.settings.idleDays ?? 90 });

  const keysDir = () => ctx.cfg.keysDir || resolve(ctx.cfg.dataDir, '..', 'Keys');
  const fileInfo = (p) => { try { return existsSync(p) ? { set: true, at: statSync(p).mtimeMs } : { set: false }; } catch { return { set: false }; } };
  /** Every key the Hub holds, in one place (security plan A6): never the key itself, only whether it's there and where to change it */
  function keyList(u) {
    const T = db.data.trading ?? {};
    const bank = db.data.settings.bank;
    const ext = Object.values(db.data.privacy ?? {}).flatMap((p) => p.devices ?? []);
    return [
      { id: 'ai', label: 'AI (Anthropic)', ...fileInfo(join(keysDir(), 'anthropic-api.key')), where: 'hub/settings/tools', place: 'Settings > AI and tools' },
      { id: 'trading-paper', label: 'Trading, practice (Alpaca)', ...fileInfo(join(keysDir(), 'alpaca-paper.json')), where: 'trading/connect', place: 'Trading > Connect' },
      { id: 'trading-live', label: 'Trading, real money (Alpaca)', ...fileInfo(join(keysDir(), 'alpaca-live.json')), where: 'trading/connect', place: 'Trading > Connect' },
      { id: 'bot', label: 'Trading bot key', set: (T.botTokens ?? []).length > 0, at: T.botTokens?.at(-1)?.at ?? null, where: 'trading/connect', place: 'Trading > Connect, step 5' },
      { id: 'bank', label: 'Banking (Enable Banking)', ...(bank?.keyFile ? fileInfo(bank.keyFile) : { set: false }), where: 'hub/admin/banking', place: 'Admin > Banking' },
      { id: 'extension', label: `Hub extension (${ext.length} ${ext.length === 1 ? 'browser' : 'browsers'})`, set: ext.length > 0, at: ext.reduce((m, d) => Math.max(m, d.paired ?? d.at ?? 0), 0) || null, where: 'hub/privacy', place: 'Privacy > Your devices' },
      { id: 'env', label: 'Email and text services (server .env file)', set: !!(ctx.cfg.email?.brevoKey || ctx.cfg.email?.resendKey || ctx.cfg.sms?.twilioToken), at: null, where: null, place: 'server\\.env on the PC (not encrypted: keep that file private)' }
    ];
  }

  return {
    'GET /api/admin/security/recovery': owner(() => [200, state()]),
    'GET /api/admin/security/keys': owner((_b, u) => [200, { keys: keyList(u), keysDir: keysDir() }]),
    // Secure connections only (other devices use the outside link's https address), and sign-out after unused days
    'POST /api/admin/security/settings': owner((b, u, meta) => {
      const s = db.data.settings;
      if (b.secureOnly !== undefined) s.secureOnly = !!b.secureOnly;
      if (b.idleDays !== undefined) s.idleDays = Math.min(365, Math.max(7, Math.round(Number(b.idleDays) || 90)));
      db.save();
      record(db, { user: u.id, username: u.username, kind: 'admin', what: b.secureOnly === false ? 'allowed plain http on the home network' : 'changed security settings', ip: meta.ip });
      return [200, state()];
    }),
    // Show the recovery key that's waiting to be written down
    'POST /api/admin/security/recovery/show': owner((b, u, meta) => {
      const no = home(meta) ?? recheck(b, u); if (no) return no;
      const code = keys?.pendingCode;
      if (!code) return [404, { error: 'It was already written down. Make a new one if it is lost' }];
      record(db, { user: u.id, username: u.username, kind: 'admin', what: 'looked at the recovery key', ip: meta.ip });
      return [200, { code, ...state() }];
    }),
    // Typed back: proves it's written down. Then it's never shown again (only its lock is kept)
    'POST /api/admin/security/recovery/saved': owner((b, u, meta) => {
      if (!keys?.checkCode(b.code)) return [400, { error: "That doesn't match. Check each group of 5", field: 'code' }];
      keys.confirmSaved();
      record(db, { user: u.id, username: u.username, kind: 'admin', what: 'saved the recovery key', ip: meta.ip });
      log(`${stamp()} ${u.name} confirmed the recovery key is written down`);
      return [200, state()];
    }),
    'POST /api/admin/security/recovery/new': owner((b, u, meta) => {
      const no = home(meta) ?? recheck(b, u); if (no) return no;
      const code = keys.makeRecovery();
      keys.markPending(code);
      db.backupNow(); // a backup that the new key opens
      record(db, { user: u.id, username: u.username, kind: 'admin', what: 'made a new recovery key', ip: meta.ip });
      log(`${stamp()} ${u.name} made a new recovery key (the old one no longer works)`);
      return [200, { code, ...state() }];
    })
  };
}
