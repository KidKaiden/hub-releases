function w(n){const t=n-1;return t*t*t+1}function m(n){const t=typeof n=="string"&&n.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);return t?[parseFloat(t[1]),t[2]||"px"]:[n,"px"]}function R(n,{delay:t=0,duration:s=400,easing:p=w,x:$=0,y:g=0,opacity:i=0}={}){const e=getComputedStyle(n),f=+e.opacity,c=e.transform==="none"?"":e.transform,o=f*(1-i),[d,u]=m($),[a,l]=m(g);return{delay:t,duration:s,easing:p,css:(y,h)=>`
			transform: ${c} translate(${(1-y)*d}${u}, ${(1-y)*a}${l});
			opacity: ${f-o*h}`}}function k(n,t){for(const s in t)n[s]=t[s];return n}function S({fallback:n,...t}){const s=new Map,p=new Map;function $(i,e,f){const{delay:c=0,duration:o=r=>Math.sqrt(r)*30,easing:d=w}=k(k({},t),f),u=i.getBoundingClientRect(),a=e.getBoundingClientRect(),l=u.left-a.left,y=u.top-a.top,h=u.width/a.width,C=u.height/a.height,M=Math.sqrt(l*l+y*y),_=getComputedStyle(e),q=_.transform==="none"?"":_.transform,B=+_.opacity;return{delay:c,duration:typeof o=="function"?o(M):o,easing:d,css:(r,x)=>`
			   opacity: ${r*B};
			   transform-origin: top left;
			   transform: ${q} translate(${x*l}px,${x*y}px) scale(${r+(1-r)*h}, ${r+(1-r)*C});
		   `}}function g(i,e,f){return(c,o)=>(i.set(o.key,c),()=>{if(e.has(o.key)){const d=e.get(o.key);return e.delete(o.key),$(d,c,o)}return i.delete(o.key),n&&n(c,o,f)})}return[g(p,s,!1),g(s,p,!0)]}export{S as c,R as f};
