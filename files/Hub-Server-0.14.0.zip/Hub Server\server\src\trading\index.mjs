// Hub > Trading, on the PC server (Kaiden's plan, 2026-11-11). Losing less comes first.
//  - Code makes the signals (strategy.mjs). Code enforces the limits (risk.mjs). Claude, when used, only filters the
//    code's signals, sizes within the limits and explains: a buy must match a fresh code signal, or it's refused.
//  - Every order, from anyone, goes through checkOrder here. Paper (practice money) by default. Cash only.
//  - Manual first: orders wait in the approval queue. Automatic only after 20 journal days on paper, and only when the
//    owner switches it on. Real money only after that too, typed by him, and automatic goes off again when he does.
//  - The kill switch stops everything until he restarts it. Reaching the protected floor locks trading until he
//    unlocks it. Every halt is written down and sent to his devices.
// Keys: typed by the owner in Hub > Trading > Connect, at home; kept in the Keys folder (never git, never logged).
import { randomBytes, createHash, randomUUID } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync, mkdirSync, unlinkSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { alpaca } from './alpaca.mjs';
import { DEFAULT_LIMITS, checkOrder, budget, dailyStopHit, trims, isStock } from './risk.mjs';
import { DEFAULT_STRATEGY, latest, gapSize, practiceBars } from './strategy.mjs';
import { backtest } from './backtest.mjs';

export const PROVEN_DAYS = 20;
const DAY = 86_400_000;
const nyDate = (t = Date.now()) => new Date(t).toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
const r2 = (v) => Math.round(v * 100) / 100;
const hash = (t) => createHash('sha256').update(t).digest('hex');

export function trading(ctx) {
  const { db, cfg, log, stamp } = ctx;
  const T = (db.data.trading ??= {});
  T.settings ??= {};
  T.settings = { mode: 'paper', auto: false, pipeline: 'code', index: 'SPY', gbpPerUsd: 0.79, ...T.settings, limits: { ...DEFAULT_LIMITS, ...(T.settings.limits ?? {}) }, strategy: { ...DEFAULT_STRATEGY, ...(T.settings.strategy ?? {}) } };
  T.queue ??= []; T.journal ??= []; T.halts ??= []; T.stops ??= {}; T.botTokens ??= []; T.day ??= null; T.last ??= null;
  T.killed ??= false; T.locked ??= false;
  const S = () => T.settings;
  const isAdmin = (u) => !!db.data.roles?.[u.role]?.admin;
  const keysDir = () => cfg.keysDir || resolve(cfg.dataDir, '..', 'Keys');
  const keyPath = (mode) => join(keysDir(), `alpaca-${mode === 'live' ? 'live' : 'paper'}.json`);
  const readKeys = (mode) => { try { return existsSync(keyPath(mode)) ? JSON.parse(db.keys ? db.keys.readSecret(keyPath(mode)) : readFileSync(keyPath(mode), 'utf8')) : null; } catch { return null; } };
  const broker = (mode = S().mode) => { const k = readKeys(mode); return k ? alpaca({ ...k, mode, base: cfg.trading?.[mode === 'live' ? 'liveBase' : 'paperBase'], dataBase: cfg.trading?.dataBase }) : null; };
  const paperDays = () => T.journal.filter((j) => j.mode === 'paper').length;
  const owners = () => Object.values(db.data.users).filter((x) => isAdmin(x) && !x.disabled);

  async function halt(kind, why) {
    T.halts.unshift({ at: Date.now(), kind, why });
    T.halts = T.halts.slice(0, 100);
    db.save();
    log(`${stamp()} Trading: ${why}`);
    for (const o of owners()) { ctx.poke?.([o.id]); await ctx.sendPush?.(o.id, { title: 'Trading stopped', body: why, route: 'trading', tag: `trading-${kind}` })?.catch?.(() => {}); }
  }

  // ---------- The account as it is now (refreshed every few minutes, and when asked) ----------
  async function refresh() {
    const b = broker();
    if (!b) { T.last = null; return null; }
    try {
      const [account, positions] = await Promise.all([b.account(), b.positions()]);
      T.last = { at: Date.now(), mode: S().mode, account, positions, error: null };
      const today = nyDate();
      if (T.day?.date !== today) T.day = { date: today, startEquity: account.lastEquity || account.equity, orders: 0, dailyHalted: false };
      for (const p of positions) {
        const st = T.stops[p.symbol];
        // The stop is set from the real buy price once the order has filled
        if (st && st.stopPrice == null && p.qty > 0) st.stopPrice = r2((p.cost / p.qty) * (1 - st.stopPct / 100));
      }
      for (const s of Object.keys(T.stops)) if (!positions.some((p) => p.symbol === s)) delete T.stops[s];
      db.save();
      return T.last;
    } catch (e) {
      T.last = { ...(T.last ?? {}), at: Date.now(), error: e.status === 401 || e.status === 403 ? 'The broker turned the keys down' : "Couldn't reach the broker" };
      return null;
    }
  }
  const stateNow = () => {
    const a = T.last?.account;
    return {
      equity: a?.equity ?? 0, cash: a?.cash ?? 0, dayStart: T.day?.startEquity ?? a?.equity ?? 0, ordersToday: T.day?.orders ?? 0,
      killed: T.killed, locked: T.locked, account: a ? { multiplier: a.multiplier, shorting: a.shorting } : null,
      positions: (T.last?.positions ?? []).filter((p) => p.qty > 0).map((p) => ({ symbol: p.symbol, qty: p.qty, value: p.value, stopPct: T.stops[p.symbol]?.stopPct ?? S().limits.stopPct, gap: T.stops[p.symbol]?.gap ?? 0.02 }))
    };
  };

  // ---------- Orders: every one is checked here first ----------
  async function place(item, human) {
    const b = broker();
    if (!b) { item.status = 'failed'; item.reasons = ['Not connected to the broker']; return item; }
    await refresh();
    const c = checkOrder(item, stateNow(), S().limits, { human });
    if (!c.ok) { item.status = 'refused'; item.reasons = c.reasons; db.save(); return item; }
    try {
      const o = await b.submit({ ...c.order, clientId: `hub-${item.id}`.slice(0, 48) });
      item.status = 'placed'; item.orderId = o?.id ?? null; item.placedAt = Date.now(); item.notes = [...(item.notes ?? []), ...c.notes];
      item.notional = c.order.notional ?? item.notional; item.qty = c.order.qty ?? item.qty;
      if (T.day) T.day.orders++;
      if (c.order.side === 'buy') T.stops[c.order.symbol] = { stopPct: c.order.stopPct, gap: c.order.gap, stopPrice: null, at: Date.now() };
      log(`${stamp()} Trading (${S().mode}): ${c.order.side} ${c.order.symbol} ${c.order.notional != null ? `$${c.order.notional}` : `${c.order.qty} shares`} (${item.source})`);
    } catch (e) { item.status = 'failed'; item.reasons = [e.message || 'The broker said no']; }
    db.save();
    return item;
  }
  /** A proposal from the code, the Claude bot, the AI chat or the owner: checked, sized, then queued or placed. */
  async function propose(p, source, human = false) {
    const item = { id: randomUUID().slice(0, 12), at: Date.now(), source, symbol: String(p.symbol ?? '').toUpperCase(), side: p.side === 'sell' ? 'sell' : 'buy',
      notional: p.notional != null ? Number(p.notional) : undefined, qty: p.qty != null ? Number(p.qty) : undefined, stopPct: p.stopPct != null ? Number(p.stopPct) : undefined,
      why: String(p.why ?? '').slice(0, 600), status: 'waiting', reasons: [], notes: [] };
    if (!isStock(item.symbol)) { item.status = 'refused'; item.reasons = ['Only plain shares and funds']; }
    // Claude (or anything but code and the owner) may only pass on a fresh code signal: never a trade of its own
    if (item.status === 'waiting' && item.side === 'buy' && source !== 'code' && !human) {
      const sig = signalsCache.list.find((s) => s.symbol === item.symbol);
      const fresh = sig && sig.trend === 'up' && sig.lastBuy && Date.now() - Date.parse(sig.lastBuy) < 4 * DAY;
      if (!fresh) { item.status = 'refused'; item.reasons = [`There's no fresh buy signal from the strategy for ${item.symbol}. The bot can only pass on the code's signals`]; }
    }
    if (item.status === 'waiting') {
      if (item.side === 'buy') item.gap = gapCache[item.symbol] ?? 0.02;
      await refresh();
      const c = checkOrder(item, stateNow(), S().limits, { human });
      if (!c.ok) { item.status = 'refused'; item.reasons = c.reasons; }
      else { item.notional = c.order.notional; item.qty = c.order.qty; item.stopPct = c.order.stopPct; item.notes = c.notes; item.worstLoss = c.worstLoss ?? null; }
    }
    T.queue.unshift(item);
    T.queue = T.queue.slice(0, 300);
    db.save();
    if (item.status === 'waiting' && S().auto && !T.killed) return place(item, false);
    if (item.status === 'waiting') for (const o of owners()) { ctx.poke?.([o.id]); await ctx.sendPush?.(o.id, { title: 'Trade to approve', body: `${item.side === 'buy' ? 'Buy' : 'Sell'} ${item.symbol}${item.notional ? ` for $${item.notional}` : ''}`, route: 'trading', tag: 'trading-queue' })?.catch?.(() => {}); }
    return item;
  }

  // ---------- Signals from the code (a moving-average crossover on daily prices) ----------
  const signalsCache = { at: 0, list: [] };
  const gapCache = {};
  async function bars(symbol, days) {
    const b = broker();
    if (b) { try { const x = await b.bars(symbol, days); if (x.length > 60) return { bars: x, practice: false }; } catch { /* fall back */ } }
    return { bars: practiceBars(symbol, days), practice: true };
  }
  async function computeSignals() {
    const list = [];
    for (const symbol of S().limits.symbols) {
      const { bars: x, practice } = await bars(symbol, 260);
      const l = latest(x, S().strategy);
      gapCache[symbol] = gapSize(x);
      // When the last buy crossing was (Claude may pass it on for a few days while the trend is still up)
      let lastBuy = null;
      for (let i = x.length - 1, k = 0; i > 0 && k < 6; i--, k++) { const sub = latest(x.slice(0, i + 1), S().strategy); if (sub.signal === 'buy') { lastBuy = x[i].t; break; } if (sub.signal === 'sell') break; }
      list.push({ symbol, ...l, lastBuy, gap: r2(gapCache[symbol] * 100), practice });
    }
    signalsCache.at = Date.now(); signalsCache.list = list;
    ctx.runs?.record('trading-signals', { text: list.filter((x) => x.signal).map((x) => `${x.symbol} ${x.signal}`).join(', ') || 'No crossings today', n: list.filter((x) => x.signal).length });
    return list;
  }

  // ---------- The watch: every few minutes ----------
  let busy = false;
  async function tick() {
    if (busy || !broker()) return;
    busy = true;
    try {
      const now = await refresh();
      if (!now) { if (!T.last?.at || T.last.error) recordWatch(false, T.last?.error ?? "Couldn't reach the broker"); return; }
      recordWatch(true, `${now.account.equity.toFixed(2)}`);
      const L = S().limits, a = now.account;
      // The protected floor: reached, it locks (until the owner unlocks it) and tells him
      if (L.floor != null && a.equity <= Number(L.floor) && !T.locked) { T.locked = true; await halt('floor', `The account reached your protected floor ($${Number(L.floor).toFixed(2)}). Trading is locked until you unlock it`); }
      if (dailyStopHit(a.equity, T.day.startEquity, L) && !T.day.dailyHalted) { T.day.dailyHalted = true; await halt('daily', `Today's loss passed your daily stop (${L.dailyLossPct}%). No more buys today`); }
      if (a.multiplier > 1 || a.shorting) await haltOnce('margin', 'The broker account allows borrowing or shorting. Hub won\'t trade until it\'s a cash account');
      const b = broker();
      const clock = await b.clock().catch(() => null);
      if (clock?.open) {
        // Stop losses, watched here (a stop can be skipped past when the price jumps: then it sells at the next price)
        for (const p of now.positions) {
          const st = T.stops[p.symbol];
          if (!st?.stopPrice || p.qty <= 0) continue;
          const px = await b.lastPrice(p.symbol).catch(() => p.price);
          if (px > 0 && px <= st.stopPrice && !st.selling) {
            st.selling = true;
            const item = { id: randomUUID().slice(0, 12), at: Date.now(), source: 'stop', symbol: p.symbol, side: 'sell', qty: p.qty, why: `Stop loss: price $${px} reached the stop at $${st.stopPrice}`, status: 'waiting', reasons: [], notes: [] };
            T.queue.unshift(item);
            await place(item, true);
          }
        }
        // Over budget after a fall towards the floor: sell down to fit
        for (const t of trims(stateNow(), L)) await propose({ ...t }, 'limits', true);
        // Once a day, half an hour after the open: the strategy's signals
        if (T.day.signalsDone !== T.day.date && !T.killed && !T.locked) {
          const opened = clock.nextClose ? Date.parse(clock.nextClose) - 6 * 3600_000 : 0;
          if (!opened || Date.now() > opened) {
            T.day.signalsDone = T.day.date;
            const list = await computeSignals();
            if (S().pipeline === 'code') for (const s of list) {
              const held = now.positions.find((p) => p.symbol === s.symbol && p.qty > 0);
              if (s.signal === 'buy' && !held) await propose({ symbol: s.symbol, side: 'buy', why: s.why }, 'code');
              if (s.signal === 'sell' && held) await propose({ symbol: s.symbol, side: 'sell', why: s.why }, 'code');
            }
          }
        }
      } else if (clock && T.day.journaled !== T.day.date && T.day.signalsDone === T.day.date) {
        // After the close: the journal, against simply holding the index
        T.day.journaled = T.day.date;
        await journal(a);
      }
      db.save();
    } finally { busy = false; }
  }
  // The watch runs every 5 minutes: one run a half hour is enough for the history
  let lastWatch = 0;
  const recordWatch = (ok, text) => { if (!ok || Date.now() - lastWatch > 30 * 60_000) { lastWatch = Date.now(); ctx.runs?.record('trading-watch', { ok, text }); } };
  const haltedOnce = new Set();
  async function haltOnce(kind, why) { if (haltedOnce.has(kind)) return; haltedOnce.add(kind); await halt(kind, why); }
  async function journal(a) {
    const { bars: idx } = await bars(S().index, 5);
    const close = idx.at(-1)?.c ?? null;
    const first = T.journal.at(-1) ?? null; // oldest is last
    const base = first ? { eq: first.baseEquity, idx: first.baseIndex } : { eq: a.equity, idx: close };
    const trades = T.queue.filter((q) => q.status === 'placed' && nyDate(q.placedAt) === T.day.date).length;
    T.journal.unshift({ date: T.day.date, mode: S().mode, equity: r2(a.equity), index: close, baseEquity: base.eq, baseIndex: base.idx,
      botPct: base.eq ? r2((a.equity / base.eq - 1) * 100) : 0, indexPct: base.idx && close ? r2((close / base.idx - 1) * 100) : 0, trades, note: T.day.note ?? '' });
    T.journal = T.journal.slice(0, 1000);
    ctx.runs?.record('trading-journal', { text: `Bot ${T.journal[0].botPct}% ? index ${T.journal[0].indexPct}%`, n: T.journal[0].botPct });
  }

  // ---------- What the app sees ----------
  function view() {
    const s = stateNow();
    const a = T.last?.account ?? null;
    const j = T.journal;
    const proven = paperDays() >= PROVEN_DAYS;
    return {
      connected: { paper: !!readKeys('paper'), live: !!readKeys('live') }, mode: S().mode, auto: S().auto, pipeline: S().pipeline,
      killed: T.killed, locked: T.locked, limits: S().limits, strategy: S().strategy, index: S().index, gbpPerUsd: S().gbpPerUsd,
      account: a, positions: (T.last?.positions ?? []).map((p) => ({ ...p, stop: T.stops[p.symbol] ?? null })), at: T.last?.at ?? null, error: T.last?.error ?? null,
      budget: a ? budget(s, S().limits) : null, day: T.day, dailyStopHit: a ? dailyStopHit(a.equity, T.day?.startEquity ?? a.equity, S().limits) : false,
      cashOnly: a ? a.multiplier <= 1 && !a.shorting : null,
      queue: T.queue.slice(0, 60), journal: j.slice(0, 120), halts: T.halts.slice(0, 20), signals: signalsCache.list, signalsAt: signalsCache.at,
      paperDays: paperDays(), provenDays: PROVEN_DAYS, canAuto: proven, canLive: proven && !!readKeys('live'),
      bots: T.botTokens.map((t) => ({ label: t.label, at: t.at, used: t.used ?? null }))
    };
  }
  const own = (u) => (isAdmin(u) ? null : [403, { error: 'Trading is only for the owner', code: 'owner' }]);
  const home = (meta) => (meta?.public ? [403, { error: 'Do this at home, on the home Wi-Fi or the PC itself: keys never travel over the internet', code: 'home' }] : null);
  const pct = (v, a, b) => Number.isFinite(Number(v)) && Number(v) >= a && Number(v) <= b;

  const routes = {
    'GET /api/trading/status': async (_b, u, { q }) => { const no = own(u); if (no) return no; if (q?.get('fresh') === '1') await refresh(); return [200, view()]; },
    // Keys: tested with the broker before they're kept
    'POST /api/trading/keys': async (b, u, meta) => {
      const no = own(u) || home(meta); if (no) return no;
      const mode = b.mode === 'live' ? 'live' : 'paper';
      const key = String(b.key ?? '').trim(), secret = String(b.secret ?? '').trim();
      if (!/^[A-Z0-9]{16,40}$/.test(key) || !/^[A-Za-z0-9/+]{30,80}$/.test(secret)) return [400, { error: "Those don't look like Alpaca keys (a key id and a secret, from the broker's dashboard)" }];
      try { await alpaca({ key, secret, mode, base: cfg.trading?.[mode === 'live' ? 'liveBase' : 'paperBase'] }).account(); }
      catch (e) { return [400, { error: e.status === 401 || e.status === 403 ? `Alpaca turned those keys down. Check they're the ${mode === 'live' ? 'real-money' : 'paper'} ones` : "Couldn't reach Alpaca to check them. Try again" }]; }
      mkdirSync(keysDir(), { recursive: true });
      if (db.keys) db.keys.writeSecret(keyPath(mode), JSON.stringify({ key, secret })); else writeFileSync(keyPath(mode), JSON.stringify({ key, secret }), { mode: 0o600 });
      log(`${stamp()} Trading: ${mode} keys added by ${u.name} (kept in the Keys folder)`);
      await refresh();
      return [200, view()];
    },
    'POST /api/trading/keys/remove': (b, u, meta) => {
      const no = own(u) || home(meta); if (no) return no;
      const mode = b.mode === 'live' ? 'live' : 'paper';
      try { if (existsSync(keyPath(mode))) unlinkSync(keyPath(mode)); } catch { /* gone */ }
      if (mode === 'live' && S().mode === 'live') { S().mode = 'paper'; S().auto = false; }
      db.save();
      return [200, view()];
    },
    'POST /api/trading/settings': (b, u) => {
      const no = own(u); if (no) return no;
      const s = S(), L = { ...s.limits };
      if (b.limits && typeof b.limits === 'object') {
        const x = b.limits;
        if (x.floor === null || (Number.isFinite(Number(x.floor)) && Number(x.floor) >= 0)) L.floor = x.floor === null ? null : r2(Number(x.floor));
        if (pct(x.maxPositionPct, 1, 100)) L.maxPositionPct = Number(x.maxPositionPct);
        if (pct(x.dailyLossPct, 0.5, 20)) L.dailyLossPct = Number(x.dailyLossPct);
        if (pct(x.maxOrdersPerDay, 1, 50)) L.maxOrdersPerDay = Math.round(Number(x.maxOrdersPerDay));
        if (pct(x.riskPerTradePct, 0.1, 10)) L.riskPerTradePct = Number(x.riskPerTradePct);
        if (pct(x.stopPct, 0.5, 25)) L.stopPct = Number(x.stopPct);
        if (Array.isArray(x.symbols)) { const list = [...new Set(x.symbols.map((v) => String(v).toUpperCase().trim()))].filter(isStock).slice(0, 20); if (list.length) L.symbols = list; }
        s.limits = L;
      }
      if (b.strategy && Number.isInteger(b.strategy.fast) && Number.isInteger(b.strategy.slow) && b.strategy.fast >= 2 && b.strategy.slow > b.strategy.fast && b.strategy.slow <= 250) s.strategy = { ...s.strategy, fast: b.strategy.fast, slow: b.strategy.slow };
      if (b.pipeline === 'code' || b.pipeline === 'claude') s.pipeline = b.pipeline;
      if (Number.isFinite(Number(b.gbpPerUsd)) && Number(b.gbpPerUsd) > 0.3 && Number(b.gbpPerUsd) < 2) s.gbpPerUsd = Number(b.gbpPerUsd);
      if (b.auto === false) s.auto = false;
      if (b.auto === true) {
        if (paperDays() < PROVEN_DAYS) return [400, { error: `Automatic opens after ${PROVEN_DAYS} days on paper (${paperDays()} so far)` }];
        if (L.floor == null) return [400, { error: 'Set your protected floor first' }];
        s.auto = true;
      }
      if (b.mode === 'paper' && s.mode !== 'paper') { s.mode = 'paper'; s.auto = false; T.stops = {}; }
      if (b.mode === 'live' && s.mode !== 'live') {
        if (paperDays() < PROVEN_DAYS) return [400, { error: `Real money opens after ${PROVEN_DAYS} days on paper (${paperDays()} so far)` }];
        if (!readKeys('live')) return [400, { error: 'Add your real-money keys first' }];
        if (b.confirm !== 'REAL MONEY') return [400, { error: 'Type REAL MONEY to confirm' }];
        s.mode = 'live'; s.auto = false; T.stops = {};
        log(`${stamp()} Trading: switched to REAL MONEY by ${u.name}`);
      }
      db.save();
      return [200, view()];
    },
    // The kill switch: on stops every new order and cancels the ones waiting; only the owner turns it off again
    'POST /api/trading/kill': async (b, u) => {
      const no = own(u); if (no) return no;
      if (b.on) {
        T.killed = true; S().auto = false;
        for (const q of T.queue) if (q.status === 'waiting') { q.status = 'rejected'; q.reasons = ['Kill switch']; }
        const br = broker();
        if (br) { await br.cancelAll().catch(() => {}); if (b.sellAll) await br.closeAll().catch(() => {}); }
        await halt('kill', `Kill switch pressed by ${u.name}${b.sellAll ? ', and everything sold to cash' : ''}`);
      } else {
        if (b.confirm !== 'RESTART') return [400, { error: 'Type RESTART to turn trading back on' }];
        T.killed = false; log(`${stamp()} Trading: restarted by ${u.name}`);
      }
      db.save();
      return [200, view()];
    },
    'POST /api/trading/unlock': async (b, u) => {
      const no = own(u); if (no) return no;
      if (b.confirm !== 'UNLOCK') return [400, { error: 'Type UNLOCK to confirm' }];
      await refresh();
      const eq = T.last?.account?.equity ?? 0;
      if (S().limits.floor != null && eq <= Number(S().limits.floor)) return [400, { error: 'The account is still at or below your floor. Lower the floor or add money first' }];
      T.locked = false; db.save();
      log(`${stamp()} Trading: unlocked by ${u.name}`);
      return [200, view()];
    },
    'POST /api/trading/queue/decide': async (b, u) => {
      const no = own(u); if (no) return no;
      const item = T.queue.find((q) => q.id === b.id && q.status === 'waiting');
      if (!item) return [404, { error: 'That one is no longer waiting' }];
      if (!b.approve) { item.status = 'rejected'; item.decidedAt = Date.now(); db.save(); return [200, view()]; }
      item.decidedAt = Date.now();
      await place(item, true);
      return [200, view()];
    },
    // The owner (or the AI chat on his device, after he pressed Do it) proposes: it still waits in the queue
    'POST /api/trading/propose': async (b, u) => { const no = own(u); if (no) return no; const src = b.source === 'ai' ? 'ai' : 'you'; const item = await propose(b, src, src === 'you'); return [200, { item, ...view() }]; },
    'POST /api/trading/signals': async (_b, u) => { const no = own(u); if (no) return no; return [200, { signals: await computeSignals() }]; },
    'POST /api/trading/backtest': async (b, u) => {
      const no = own(u); if (no) return no;
      const syms = (Array.isArray(b.symbols) ? b.symbols : S().limits.symbols).map((s) => String(s).toUpperCase()).filter(isStock).slice(0, 8);
      const days = Math.max(120, Math.min(1000, Number(b.days) || 500));
      const start = Math.max(5, Math.min(1e6, Number(b.start) || T.last?.account?.equity || 100));
      const all = {}; let practice = false;
      for (const s of [...new Set([S().index, ...syms])]) { const x = await bars(s, days); all[s] = x.bars; practice ||= x.practice; }
      // Keep only the days every symbol has
      const common = all[S().index].map((x) => x.t).filter((t) => syms.every((s) => all[s].some((x) => x.t === t)));
      const set = new Set(common);
      for (const s of Object.keys(all)) all[s] = all[s].filter((x) => set.has(x.t));
      const floor = b.floor != null ? Number(b.floor) : S().limits.floor != null ? Number(S().limits.floor) : r2(start * 0.7);
      const res = backtest({ bars: all, symbols: syms, index: S().index, start, limits: { ...S().limits, floor }, strategy: S().strategy });
      const thin = (c) => { const k = Math.max(1, Math.ceil(c.length / 260)); return c.filter((_, i) => i % k === 0 || i === c.length - 1); };
      for (const x of [res.alone, res.limited, res.index]) x.curve = thin(x.curve);
      return [200, { ...res, practice, symbols: syms, floor }];
    },
    'POST /api/trading/bot/new': (b, u, meta) => {
      const no = own(u) || home(meta); if (no) return no;
      const token = `hubbot_${randomBytes(24).toString('base64url')}`;
      T.botTokens.push({ hash: hash(token), label: String(b.label ?? 'Claude trading bot').slice(0, 60), at: Date.now(), by: u.id });
      db.save();
      return [200, { token, ...view() }];
    },
    'POST /api/trading/bot/revoke': (_b, u) => { const no = own(u); if (no) return no; T.botTokens = []; db.save(); return [200, view()]; },
    // ---------- For the Claude Code bot (its own token; tools/trading/hub-bot.mjs) ----------
    'GET /api/trading/bot/context': async (_b, u) => {
      const no = own(u); if (no) return no;
      await refresh();
      if (!signalsCache.list.length || Date.now() - signalsCache.at > 3600_000) await computeSignals();
      const v = view();
      return [200, { mode: v.mode, auto: v.auto, killed: v.killed, locked: v.locked, limits: v.limits, budget: v.budget, account: v.account && { equity: v.account.equity, cash: v.account.cash, currency: v.account.currency },
        positions: v.positions.map((p) => ({ symbol: p.symbol, qty: p.qty, value: p.value, plPct: r2(p.plPct), stop: p.stop?.stopPrice ?? null })), signals: v.signals, waiting: v.queue.filter((q) => q.status === 'waiting').length,
        rules: 'You may only pass on the strategy\'s buy signals (fresh, trend up) or sell what is held. Size within the budget or less. Explain in plain words. Hub checks every order and the owner approves unless he switched on automatic.' }];
    },
    'POST /api/trading/bot/propose': async (b, u) => { const no = own(u); if (no) return no; const item = await propose(b, 'claude', false); return [200, { item: { id: item.id, status: item.status, reasons: item.reasons, notes: item.notes, notional: item.notional ?? null } }]; },
    'POST /api/trading/bot/note': (b, u) => { const no = own(u); if (no) return no; if (T.day) { T.day.note = String(b.text ?? '').slice(0, 2000); db.save(); } return [200, { ok: true }]; }
  };

  let iv = null;
  return {
    routes,
    /** The bot's own token stands for the owner, but only on /api/trading/bot/ routes (app.mjs checks the path) */
    botUser(token) {
      if (!token || !token.startsWith('hubbot_')) return null;
      const t = T.botTokens.find((x) => x.hash === hash(token));
      if (!t) return null;
      t.used = Date.now();
      return db.data.users[t.by] ?? null;
    },
    tick, refresh, propose, view,
    start() { iv = setInterval(() => void tick().catch((e) => log(`${stamp()} Trading: watch failed (${e.message})`)), cfg.trading?.tickMs ?? 5 * 60_000); iv.unref?.(); setTimeout(() => void tick().catch(() => {}), 20_000).unref?.(); },
    stop() { clearInterval(iv); }
  };
}
