// Trading: the size and risk layer, enforced here on the PC server, outside the AI (Kaiden's rules, 2026-11-11).
// Losing less comes first. The strategy (strategy.mjs) chooses WHICH trades; this layer only decides HOW MUCH, or
// says no. It never invents a trade. Plain functions, tested in server/test/trading.test.mjs.
//
// The protected floor: an amount the owner sets that the bot can never trade with. Only money above it is at risk.
// Strict or loose follows how far the account is above the floor, by itself (not a setting):
//  - Near the floor: strict. Only money above the floor is invested; the floor stays as cash, so even a price that
//    jumps past a stop can't take the account below it (at worst the invested part goes to 0).
//  - Far above the floor: loose. It may invest more than the money above the floor, but what all the stop losses
//    could lose together, plus a buffer for each stock's usual overnight jump, stays within the money above it.
//  - In between it slides smoothly from one to the other.
// Always: cash only (no margin, no shorting, no options, no borrowing), a stop loss on every buy, a cap on each
// position, a daily loss stop, a cap on orders a day, a list of allowed symbols, and the kill switch.

export const DEFAULT_LIMITS = {
  floor: null,            // the protected floor, in the account's currency. Must be set before any buy.
  maxPositionPct: 20,     // one stock at most this share of the account
  dailyLossPct: 4,        // stop buying for the day after losing this much since the day began
  maxOrdersPerDay: 4,
  riskPerTradePct: 1,     // what one trade may lose at its stop, as a share of the account
  stopPct: 5,             // the default stop loss below the buy price
  minOrder: 1,            // the broker's smallest order (dollars)
  symbols: ['SPY', 'QQQ', 'AAPL', 'MSFT'],
  strictBelow: 0.15,      // money above the floor under 15% of the account: fully strict
  looseAbove: 0.6         // over 60%: fully loose
};

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const r2 = (v) => Math.round(v * 100) / 100;
export const isStock = (s) => typeof s === 'string' && /^[A-Z]{1,5}(\.[A-Z])?$/.test(s);

/** What the account may still invest and risk, given the floor and what it holds now. */
export function budget({ equity, cash, positions = [] }, limits) {
  const floor = Number(limits.floor);
  if (!Number.isFinite(floor) || floor < 0) return { zone: 'unset', cushion: 0, looseness: 0, investMax: 0, invested: 0, investLeft: 0, riskUsed: 0, riskLeft: 0 };
  const cushion = Math.max(0, equity - floor);
  const invested = positions.reduce((s, p) => s + Math.max(0, p.value), 0);
  const riskUsed = positions.reduce((s, p) => s + Math.max(0, p.value) * ((p.stopPct ?? limits.stopPct) / 100 + (p.gap ?? 0.02)), 0);
  if (cushion <= 0 || equity <= 0) return { zone: 'floor', cushion: 0, looseness: 0, investMax: 0, invested, investLeft: 0, riskUsed, riskLeft: 0 };
  const ratio = cushion / equity;
  const w = clamp((ratio - limits.strictBelow) / (limits.looseAbove - limits.strictBelow), 0, 1);
  // Strict: only the cushion. Loose: up to the whole account (cash only, never borrowed).
  const investMax = cushion + w * (equity - cushion);
  return {
    zone: w <= 0 ? 'strict' : w >= 1 ? 'loose' : 'sliding', cushion: r2(cushion), looseness: r2(w),
    investMax: r2(investMax), invested: r2(invested), investLeft: r2(Math.max(0, Math.min(investMax - invested, cash))),
    riskUsed: r2(riskUsed), riskLeft: r2(Math.max(0, cushion - riskUsed))
  };
}

/** Has the day's loss gone past the daily stop? */
export const dailyStopHit = (equity, dayStart, limits) => dayStart > 0 && (dayStart - equity) / dayStart * 100 >= limits.dailyLossPct;

/**
 * Checks one order against every rule and sizes it. order: { symbol, side: 'buy'|'sell', notional?, qty?, stopPct?, gap? }
 * state: { equity, cash, positions: [{ symbol, value, qty, stopPct, gap }], dayStart, ordersToday, killed, locked,
 *          account: { multiplier, shorting } }
 * Returns { ok, order (sized), reasons: [why not], notes: [what changed] }. Nothing here places an order.
 */
export function checkOrder(order, state, limits, { human = false } = {}) {
  const reasons = [], notes = [];
  const no = (r) => ({ ok: false, order: null, reasons: [...reasons, r], notes });
  if (state.killed) return no('The kill switch is on. Only you can restart trading');
  if (state.locked && !(human && order.side === 'sell')) return no('The account reached your protected floor, so trading is locked until you unlock it');
  if (state.account && (Number(state.account.multiplier ?? 1) > 1 || state.account.shorting)) return no('The broker account allows borrowing or shorting. Turn that off in the broker first (cash account only)');
  const symbol = String(order.symbol ?? '').toUpperCase();
  if (!isStock(symbol)) return no('Only plain shares and funds can be traded (no options or other products)');
  if (!limits.symbols.includes(symbol)) return no(`${symbol} isn't on your list of allowed symbols`);
  if ((state.ordersToday ?? 0) >= limits.maxOrdersPerDay) return no(`That's the most orders for one day (${limits.maxOrdersPerDay})`);
  const held = state.positions.find((p) => p.symbol === symbol);

  if (order.side === 'sell') {
    // Selling only what's held: never short
    if (!held || held.qty <= 0) return no(`Nothing of ${symbol} to sell (no shorting)`);
    const qty = order.qty != null ? Math.min(Number(order.qty), held.qty) : held.qty;
    if (!(qty > 0)) return no('Nothing to sell');
    if (order.qty != null && Number(order.qty) > held.qty) notes.push(`Only ${held.qty} held, so selling that`);
    return { ok: true, order: { symbol, side: 'sell', qty: Math.round(qty * 1e9) / 1e9 }, reasons, notes };
  }
  if (order.side !== 'buy') return no('An order is a buy or a sell');
  if (limits.floor == null || !Number.isFinite(Number(limits.floor))) return no('Set your protected floor first (Trading > Safety)');
  if (dailyStopHit(state.equity, state.dayStart, limits)) return no(`Today's loss passed your daily stop (${limits.dailyLossPct}%). No more buys today`);
  const stopPct = Number(order.stopPct ?? limits.stopPct);
  if (!(stopPct >= 0.5 && stopPct <= 25)) return no('Every buy needs a stop loss between 0.5% and 25% below the price');
  const gap = clamp(Number(order.gap ?? 0.02), 0, 0.25);
  const b = budget(state, limits);
  if (b.zone === 'floor') return no('The account is at your protected floor: nothing can be invested');
  let want = Number(order.notional);
  if (!(want > 0)) want = Infinity; // no amount asked: as much as the rules allow
  const perLoss = stopPct / 100 + gap;
  const caps = [
    ['what you asked for', want],
    ['the cash in the account', state.cash],
    [`the most for one stock (${limits.maxPositionPct}%)`, state.equity * limits.maxPositionPct / 100 - (held?.value ?? 0)],
    [b.zone === 'strict' ? 'the money above your floor' : 'what may be invested at this distance from your floor', b.investLeft],
    ['what may be lost above your floor (stop losses plus overnight jumps)', b.riskLeft / perLoss],
    [`the risk for one trade (${limits.riskPerTradePct}% of the account)`, state.equity * limits.riskPerTradePct / 100 / perLoss]
  ];
  let notional = Infinity, by = '';
  for (const [w, v] of caps) if (v < notional) { notional = v; by = w; }
  notional = Math.floor(notional * 100) / 100;
  if (!(notional >= limits.minOrder)) return no(`Too small to buy after the limits (${by}: $${Math.max(0, notional).toFixed(2)})`);
  if (Number.isFinite(want) && notional < want) notes.push(`Made smaller to fit ${by}`);
  return { ok: true, order: { symbol, side: 'buy', notional, stopPct, gap }, reasons, notes, budget: b, worstLoss: r2(notional * perLoss) };
}

/** Positions now bigger than the budget allows (the account fell towards the floor): sells that bring it back. */
export function trims(state, limits) {
  const b = budget(state, limits);
  if (b.zone === 'unset' || b.invested <= b.investMax + 0.5) return [];
  let over = b.invested - b.investMax;
  const out = [];
  for (const p of [...state.positions].sort((a, b2) => b2.value - a.value)) {
    if (over <= 0) break;
    const part = Math.min(1, over / p.value);
    out.push({ symbol: p.symbol, side: 'sell', qty: Math.round(p.qty * part * 1e6) / 1e6, why: `Back within your floor's budget (over by $${over.toFixed(2)})` });
    over -= p.value * part;
  }
  return out;
}
