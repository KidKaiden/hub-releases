// Web push: notifications to a web app added to the Home Screen (iPhone, iOS 16.4+) or a browser, through the
// outside link (https). Standard Web Push: messages are encrypted for each device (RFC 8291, aes128gcm) and signed
// with this server's own key (VAPID, RFC 8292). Only Node's built-in crypto; the keys live in the server's data.
import { createECDH, generateKeyPairSync, createPrivateKey, createPublicKey, sign, randomBytes, hkdfSync, createCipheriv } from 'node:crypto';
import { stamp } from './history.mjs';

const b64u = (b) => Buffer.from(b).toString('base64url');
const fromB64u = (s) => Buffer.from(String(s), 'base64url');
const hkdf = (ikm, salt, info, len) => Buffer.from(hkdfSync('sha256', ikm, salt, info, len));

/** The server's VAPID key pair: made once, kept in the database. */
export function vapidKeys(db) {
  db.data.push ??= { vapid: null, subs: [] };
  if (!db.data.push.vapid) {
    const { privateKey, publicKey } = generateKeyPairSync('ec', { namedCurve: 'P-256' });
    const jwk = publicKey.export({ format: 'jwk' });
    db.data.push.vapid = { privateJwk: privateKey.export({ format: 'jwk' }), publicKey: b64u(Buffer.concat([Buffer.from([4]), fromB64u(jwk.x), fromB64u(jwk.y)])) };
    db.save();
  }
  return db.data.push.vapid;
}

/** RFC 8291: encrypt `payload` for one subscription. Returns the request body. */
export function encrypt(sub, payload) {
  const uaPublic = fromB64u(sub.keys.p256dh);
  const authSecret = fromB64u(sub.keys.auth);
  const as = createECDH('prime256v1');
  const asPublic = as.generateKeys();
  const ecdh = as.computeSecret(uaPublic);
  const ikm = hkdf(ecdh, authSecret, Buffer.concat([Buffer.from('WebPush: info\0'), uaPublic, asPublic]), 32);
  const salt = randomBytes(16);
  const cek = hkdf(ikm, salt, Buffer.from('Content-Encoding: aes128gcm\0'), 16);
  const nonce = hkdf(ikm, salt, Buffer.from('Content-Encoding: nonce\0'), 12);
  const cipher = createCipheriv('aes-128-gcm', cek, nonce);
  const body = Buffer.concat([cipher.update(Buffer.concat([Buffer.from(payload), Buffer.from([2])])), cipher.final(), cipher.getAuthTag()]);
  const head = Buffer.alloc(21);
  salt.copy(head, 0); head.writeUInt32BE(4096, 16); head.writeUInt8(asPublic.length, 20);
  return Buffer.concat([head, asPublic, body]);
}

/** RFC 8292: the signed "this server sent it" header for a push service. */
export function vapidAuth(vapid, endpoint, subject = 'mailto:hub@localhost', now = Date.now()) {
  const enc = (o) => b64u(JSON.stringify(o));
  const unsigned = `${enc({ typ: 'JWT', alg: 'ES256' })}.${enc({ aud: new URL(endpoint).origin, exp: Math.floor(now / 1000) + 12 * 3600, sub: subject })}`;
  const sig = sign('sha256', Buffer.from(unsigned), { key: createPrivateKey({ key: vapid.privateJwk, format: 'jwk' }), dsaEncoding: 'ieee-p1363' });
  return `vapid t=${unsigned}.${b64u(sig)}, k=${vapid.publicKey}`;
}

export function pushRoutes(ctx) {
  const { db, cfg, log } = ctx;
  const subs = () => (db.data.push ??= { vapid: null, subs: [] }).subs;
  const fetchFn = cfg.fetch ?? fetch;

  /** Send to every device this account turned push on for. Throws if none took it (so it is retried). */
  async function sendToUser(userId, msg) {
    const mine = subs().filter((s) => s.userId === userId);
    if (!mine.length) throw new Error('No device has phone notifications on');
    const vapid = vapidKeys(db);
    const payload = JSON.stringify({ title: String(msg.title ?? 'Hub').slice(0, 120), body: String(msg.body ?? '').slice(0, 400), route: msg.route ?? '', tag: msg.tag });
    let ok = 0;
    for (const s of mine) {
      try {
        const r = await fetchFn(s.endpoint, {
          method: 'POST',
          headers: { 'content-encoding': 'aes128gcm', 'content-type': 'application/octet-stream', ttl: '86400', urgency: 'high', authorization: vapidAuth(vapid, s.endpoint, cfg.pushSubject) },
          body: encrypt(s, payload)
        });
        if (r.status === 404 || r.status === 410) { db.data.push.subs = subs().filter((x) => x !== s); db.save(); continue; } // gone: forget it
        if (r.ok) ok++;
        else log(`${stamp()} push: the push service said ${r.status}`);
      } catch (e) { log(`${stamp()} push: couldn't reach the push service (${e.message})`); }
    }
    if (!ok) throw new Error('No device took the notification');
    return ok;
  }
  ctx.sendPush = sendToUser;

  return {
    routes: {
      'GET /api/push/key': () => [200, { key: vapidKeys(db).publicKey }],
      'POST /api/push/subscribe': (b, u, { session }) => {
        const s = b.subscription;
        if (!s?.endpoint || !/^https:\/\//.test(s.endpoint) || !s.keys?.p256dh || !s.keys?.auth) return [400, { error: "That isn't a push subscription" }];
        db.data.push.subs = subs().filter((x) => x.endpoint !== s.endpoint);
        db.data.push.subs.push({ userId: u.id, endpoint: s.endpoint, keys: { p256dh: s.keys.p256dh, auth: s.keys.auth }, device: session?.device?.name ?? '', created: Date.now() });
        db.save();
        return [200, { ok: true, devices: subs().filter((x) => x.userId === u.id).length }];
      },
      'POST /api/push/unsubscribe': (b, u) => {
        db.data.push.subs = subs().filter((x) => !(x.userId === u.id && (!b.endpoint || x.endpoint === b.endpoint)));
        db.save();
        return [200, { ok: true }];
      },
      'POST /api/push/test': async (_b, u) => {
        try { const n = await sendToUser(u.id, { title: 'Hub', body: 'Phone notifications work', route: '', tag: 'test' }); return [200, { ok: true, devices: n }]; }
        catch (e) { return [200, { ok: false, error: e.message }]; }
      }
    },
    sendToUser
  };
}
