// World Link from the Hub (Kaiden, 2026-11-15: "a button in Admin, not a file to double-click"; "the PC address
// should be automatic"; "each account should have the password remembered at all times").
// Three jobs, all on the PC that runs the server:
//   1. The address: the PC's Tailscale name from the Hub's own outside link (port 8443), handed to every device, so
//      nobody types it.
//   2. The password: kept per account in the Keys folder (encrypted with the server's key like every other key) and
//      given back only to that account, so it follows the person to every device.
//   3. Admin: a light for each part (TightVNC, the bridge, Tailscale) and one Set up / Repair button that runs
//      tools/worldlink/setup.ps1 in the background (Windows asks its one "Yes" on the PC), like the server update.
import net from 'node:net';
import { execFile, spawn } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { randomInt } from 'node:crypto';
import { checkPassword } from './auth.mjs';
import { record } from './history.mjs';
import { ROOT } from './selfupdate.mjs';

const PORT_VNC = 5900, PORT_BRIDGE = 6080, PORT_OUTSIDE = 8443;
const ALPHA = 'abcdefghjkmnpqrstuvwxyz23456789'; // the same letters set-up uses: nothing easy to misread
export const newPassword = () => Array.from({ length: 8 }, () => ALPHA[randomInt(ALPHA.length)]).join('');
const okPassword = (p) => /^[A-Za-z0-9]{6,8}$/.test(p);

/** The PC's World Link address from the Hub's outside link (a Tailscale name), or '' when there isn't one. */
export function bridgeFrom(publicUrl) {
  try { const h = new URL(publicUrl).hostname; return h.endsWith('.ts.net') ? `wss://${h}:${PORT_OUTSIDE}` : ''; } catch { return ''; }
}

// ---------- The checks: real tries, each one a light in Admin ----------
/** TightVNC on this PC (port 5900): does it let this PC in and ask for a password? */
export function probeVnc({ port = PORT_VNC, host = '127.0.0.1', ms = 4000 } = {}) {
  return new Promise((ok) => {
    const s = net.connect({ port, host });
    let buf = Buffer.alloc(0), greeted = false, done = false;
    const end = (r) => { if (done) return; done = true; clearTimeout(t); s.destroy(); ok(r); };
    const t = setTimeout(() => end({ ok: false, text: 'TightVNC did not answer.' }), ms);
    s.on('error', () => end({ ok: false, text: "TightVNC isn't running on this PC." }));
    s.on('close', () => end({ ok: false, text: 'TightVNC closed the connection.' }));
    s.on('data', (d) => {
      buf = Buffer.concat([buf, d]);
      if (!greeted) { if (buf.length < 12) return; s.write(buf.subarray(0, 12)); buf = buf.subarray(12); greeted = true; }
      if (!buf.length) return;
      const n = buf[0];
      if (n === 0) {
        if (buf.length < 5 || buf.length < 5 + buf.readUInt32BE(1)) return;
        const why = buf.subarray(5, 5 + buf.readUInt32BE(1)).toString('latin1');
        return end({ ok: false, text: /loopback/i.test(why) ? 'TightVNC is refusing this PC (it is the newer version). Set up again to put the right one on.' : `TightVNC refused: ${why}` });
      }
      if (buf.length < 1 + n) return;
      const types = [...buf.subarray(1, 1 + n)];
      end(types.includes(2) ? { ok: true, text: 'TightVNC is on and asks for the password.' } : { ok: false, text: 'TightVNC has no password set. Set up again to choose one.' });
    });
  });
}

/** The bridge (port 6080): does it accept a web socket and hand over TightVNC's greeting? */
export function probeBridge({ port = PORT_BRIDGE, ms = 5000 } = {}) {
  return new Promise((ok) => {
    let ws, done = false;
    const end = (r) => { if (done) return; done = true; clearTimeout(t); try { ws?.close(); } catch { /* closed */ } ok(r); };
    const t = setTimeout(() => end({ ok: false, text: 'The bridge did not answer.' }), ms);
    try { ws = new WebSocket(`ws://127.0.0.1:${port}`, ['binary']); } catch { return end({ ok: false, text: "This server can't test the bridge." }); }
    ws.binaryType = 'arraybuffer';
    ws.onerror = () => end({ ok: false, text: "The bridge isn't running." });
    ws.onclose = () => end({ ok: false, text: "The bridge answered, then closed: TightVNC isn't running behind it." });
    ws.onmessage = (e) => {
      const text = Buffer.from(e.data).toString('latin1');
      end(/^RFB \d{3}\.\d{3}\n/.test(text) ? { ok: true, text: 'The bridge is running and passes TightVNC through.' } : { ok: false, text: 'The bridge gave an answer that is not TightVNC.' });
    };
  });
}

const run = (cmd, args) => new Promise((ok) => {
  execFile(cmd, args, { timeout: 15_000, windowsHide: true, maxBuffer: 1 << 20 }, (e, out, err) => ok({ ok: !e, out: String(out ?? '').trim(), err: String(err ?? e?.message ?? '').trim() }));
});
/** Tailscale: running, and sharing the bridge on 8443 (tailnet only). */
export async function probeOutside(exec = run) {
  const candidates = ['tailscale', join(process.env.ProgramFiles ?? 'C:\\Program Files', 'Tailscale', 'tailscale.exe')];
  let r = null;
  for (const c of candidates) { r = await exec(c, ['serve', 'status']); if (r.ok || r.out) break; }
  if (!r || (!r.ok && !r.out)) return { ok: false, text: "Tailscale isn't installed or isn't signed in on this PC." };
  const shared = r.out.includes(`:${PORT_OUTSIDE}`) && r.out.includes(String(PORT_BRIDGE));
  return shared ? { ok: true, text: 'Tailscale is sharing World Link on your private network only.' } : { ok: false, text: 'Tailscale is on, but not sharing World Link yet. Set up again.' };
}

export function worldLink(ctx, impl = {}) {
  const { db, cfg, log, stamp } = ctx;
  const root = impl.root ?? ROOT;
  const keysDir = () => cfg.keysDir || resolve(cfg.dataDir, '..', 'Keys');
  const statusFile = join(cfg.dataDir, 'worldlink-status.json');
  const pwHand = join(cfg.dataDir, 'worldlink-setup.pw'); // handed to set-up, deleted by it
  const probes = { vnc: impl.vnc ?? probeVnc, bridge: impl.bridge ?? probeBridge, outside: impl.outside ?? (() => probeOutside()) };
  const isAdmin = (u) => !!db.data.roles?.[u.role]?.admin;
  const owner = (fn) => (b, u, meta) => (isAdmin(u) ? fn(b, u, meta) : [403, { error: 'Only the owner can do this', code: 'owner' }]);
  const address = () => bridgeFrom(cfg.publicUrl);
  let pending = null, watcher = null, lastCheck = null;

  // The password, one file per account, encrypted by the server's key (db.keys), never logged
  const pwFile = (u) => join(keysDir(), `worldlink-${String(u.id).replace(/[^A-Za-z0-9_-]/g, '')}.pw`);
  const readPw = (u) => { try { const f = pwFile(u); return existsSync(f) ? (db.keys ? db.keys.readSecret(f) : readFileSync(f, 'utf8')).trim() : ''; } catch { return ''; } };
  const writePw = (u, p) => { mkdirSync(keysDir(), { recursive: true }); if (db.keys) db.keys.writeSecret(pwFile(u), p + '\n'); else writeFileSync(pwFile(u), p + '\n', { mode: 0o600 }); };
  const forgetPw = (u) => { try { rmSync(pwFile(u), { force: true }); } catch { /* none */ } };

  const status = () => { try { return JSON.parse(readFileSync(statusFile, 'utf8').replace(/^﻿/, '')); } catch { return null; } };
  const running = () => { const s = status(); return s?.state === 'running' && Date.now() - (s.updated ?? 0) < 10 * 60_000; };
  const available = () => (impl.spawn ? true : process.platform === 'win32' && existsSync(join(root, 'tools', 'worldlink', 'setup.ps1')));

  /** A real try of every part. Each is a light: green, or red with what to do. */
  async function check() {
    const [vnc, bridge, outside] = await Promise.all([probes.vnc(), probes.bridge(), probes.outside()]);
    const addr = address();
    const lights = [
      { id: 'vnc', label: 'TightVNC on this PC', ...vnc },
      { id: 'bridge', label: 'The bridge', ...bridge },
      { id: 'outside', label: 'Tailscale', ...outside },
      { id: 'address', label: 'The PC address', ok: !!addr, text: addr ? `Your devices find the PC by themselves (${addr.replace('wss://', '')}).` : "Your Hub has no Tailscale outside link yet, so devices can't find the PC by themselves. Turn the outside link on first (Hub > Setup)." }
    ];
    lastCheck = { at: Date.now(), ok: lights.every((l) => l.ok), lights };
    return lastCheck;
  }

  function finish(s) {
    if (!pending) return;
    if (s?.state === 'done') { try { writePw(pending.user, pending.password); } catch (e) { log(`${stamp()} World Link: could not keep the password (${e.message})`); } log(`${stamp()} World Link: set up for ${pending.user.name}; password kept for their account`); }
    rmSync(pwHand, { force: true });
    pending = null;
  }
  function watch() {
    clearInterval(watcher);
    watcher = setInterval(() => { const s = status(); if (!s || s.state === 'running') return; finish(s); clearInterval(watcher); watcher = null; }, 1500);
    watcher.unref?.();
  }

  function info(u) {
    return { address: address(), available: available(), busy: running(), job: status(), check: lastCheck, hasPassword: !!(u && readPw(u)) };
  }

  const routes = {
    // Every signed-in device: where the PC is, and whether this account has its password kept
    'GET /api/worldlink': (_b, u) => [200, { bridge: address(), hasPassword: !!readPw(u) }],
    // Only the account's own password, to its own devices
    'GET /api/worldlink/password': (_b, u) => [200, { password: readPw(u) }],
    'POST /api/worldlink/password': (b, u) => {
      const p = String(b.password ?? '');
      if (!p || p.length > 64) return [400, { error: 'Type the World Link password' }];
      writePw(u, p);
      return [200, { ok: true }];
    },
    'POST /api/worldlink/password/forget': (_b, u) => { forgetPw(u); return [200, { ok: true }]; },

    // Admin (owner)
    'GET /api/admin/worldlink': owner((_b, u) => [200, info(u)]),
    'POST /api/admin/worldlink/check': owner(async (_b, u) => { await check(); return [200, info(u)]; }),
    'POST /api/admin/worldlink/setup': owner(async (b, u, meta) => {
      if (!checkPassword(String(b.password ?? ''), u.pw)) return [403, { error: 'That password is not right', field: 'password', code: 'password' }];
      if (!available()) return [400, { error: 'Setting up from the Hub works on the Windows PC that runs the server' }];
      if (running()) return [409, { error: 'A set-up is already running' }];
      // A new World Link password (typed here, or made for you), or keep the one this account already has
      const typed = String(b.newPassword ?? '').trim();
      if (typed && !okPassword(typed)) return [400, { error: '6 to 8 letters and numbers only (TightVNC only uses the first 8)', field: 'newPassword' }];
      const keep = !typed && !!readPw(u);
      const password = keep ? readPw(u) : typed || newPassword();
      mkdirSync(cfg.dataDir, { recursive: true });
      rmSync(statusFile, { force: true });
      const args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', join(root, 'tools', 'worldlink', 'setup.ps1'), '-NoPrompt', '-Status', statusFile];
      if (!keep) { writeFileSync(pwHand, password, { mode: 0o600 }); args.push('-PwFile', pwHand); }
      pending = { user: u, password };
      record(db, { user: u.id, username: u.username, kind: 'admin', what: 'ran World Link set-up from Admin', ip: meta?.ip });
      log(`${stamp()} ${u.name} started World Link set-up`);
      writeFileSync(statusFile, JSON.stringify({ state: 'running', steps: [], started: Date.now(), updated: Date.now() }));
      if (impl.spawn) impl.spawn(args); else { const child = spawn('powershell.exe', args, { cwd: root, detached: true, stdio: 'ignore', windowsHide: true }); child.unref(); }
      watch();
      // The password is shown once, here, when it was made for you (it is also kept for this account)
      return [200, { ...info(u), busy: true, made: keep || typed ? undefined : password }];
    })
  };
  return { routes, check, address, info, stop() { clearInterval(watcher); } };
}
