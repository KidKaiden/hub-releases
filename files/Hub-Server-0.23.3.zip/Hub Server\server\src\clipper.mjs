// Clipper on the Hub server (plans/clipper/PLAN.md). Owner only, on the PC that runs the server:
//   - jobs: a link to a finished stream or video -> fetched with yt-dlp -> moments found -> clips cut (clipper-engine.mjs)
//   - finds: the clips made (files stay on this PC); the app imports them into its queue, you approve there
//   - top streamers: the biggest live streams of a game, from Twitch (and Kick), with the owner's own free API keys
//   - the live watcher: records each chosen stream in short pieces, finds moments in each piece, throws the piece away
// Nothing here posts anything and nothing runs on its own until the owner starts it.
import { spawn } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { record } from './history.mjs';
import { ROOT } from './selfupdate.mjs';
import { clipFile, fetchVideo, goodLink, toolPaths } from './clipper-engine.mjs';
import { sensePaths, twitchChat } from './clipper-senses.mjs';
import { localLlm } from './clipper-llm.mjs';
import { poster } from './clipper-post.mjs';
import { makeVideo, writeScript } from './clipper-maker.mjs';

const CHUNK = 150; // seconds of a live stream looked at together
const cleanHandle = (h) => String(h ?? '').trim().replace(/^@+/, '').replace(/[^A-Za-z0-9_.-]/g, '').slice(0, 40);
const PLATFORMS = { twitch: (h) => `https://www.twitch.tv/${h}`, kick: (h) => `https://kick.com/${h}`, youtube: (h) => `https://www.youtube.com/@${h}/live` };

export function clipper(ctx, impl = {}) {
  const { db, cfg, log, stamp } = ctx;
  const root = impl.root ?? ROOT;
  const home = impl.dir ?? cfg.clipper?.dir ?? resolve(cfg.dataDir, '..', 'Clipper');
  const keysDir = () => cfg.keysDir || resolve(cfg.dataDir, '..', 'Keys');
  const keyFile = join(keysDir(), 'clipper-keys.json');
  const stateFile = join(home, 'state.json');
  const media = join(home, 'media');
  const toolsDir = impl.tools ?? cfg.clipper?.tools ?? resolve(root, '..', 'Tools', 'clipper');
  const tools = () => toolPaths(toolsDir);
  // The free AI (Qwen2.5-VL through llama.cpp) runs on this PC: no key, no bill. Tests hand in a pretend one.
  const llm = localLlm(toolsDir, { log: (m) => log(`${stamp()} ${m}`) });
  const ask = impl.ask ?? llm.ask;
  const sense = () => impl.senses ?? sensePaths(tools().dir);
  /** A concrete title and caption from what was said, written by the free local AI (plain ones stay if it isn't there) */
  const TITLE = { type: 'object', additionalProperties: false, required: ['title', 'caption'], properties: { title: { type: 'string' }, caption: { type: 'string' } } };
  async function titler({ text, source }) {
    if (impl.noTitles || !(impl.ask || llm.has())) return null;
    const r = await ask({ system: 'You write the title and on-screen caption for a short vertical clip of a streamer. The title names the person and the concrete thing that happens, in plain words, at most 12 words, never claiming more than what was said. The caption is 2 to 5 words in CAPITALS with the loudest word in {braces}.', content: `Streamer: ${source || 'unknown'}\nWhat was said in the clip: ${text.slice(0, 1200)}`, max: 200, schema: TITLE, temperature: 0.5 });
    if (r.error) return null;
    try { const j = JSON.parse(r.text); return j && typeof j.title === 'string' && j.title.trim() ? j : null; } catch { return null; }
  }  const isAdmin = (u) => !!db.data.roles?.[u.role]?.admin;
  const owner = (fn) => (b, u, meta) => (isAdmin(u) ? fn(b, u, meta) : [403, { error: 'Only the owner can do this', code: 'owner' }]);
  const doFetch = impl.fetch ?? fetch;

  // ---------- state: jobs and finds, kept in a file next to the clips ----------
  let state = { jobs: [], finds: [], watch: [] };
  try { state = { ...state, ...JSON.parse(readFileSync(stateFile, 'utf8')) }; } catch { /* first time */ }
  for (const j of state.jobs) if (j.state === 'running' || j.state === 'queued') { j.state = 'error'; j.text = 'The server restarted while this was running. Add the link again.'; }
  let saveT = null;
  const save = () => { clearTimeout(saveT); saveT = setTimeout(() => { try { mkdirSync(home, { recursive: true }); writeFileSync(stateFile, JSON.stringify(state)); } catch (e) { log(`${stamp()} Clipper: could not save its state (${e.message})`); } }, 300); saveT.unref?.(); };
  const newId = () => `j${Date.now().toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`;

  // ---------- keys (free developer keys the owner makes at Twitch and Kick), kept like every other key ----------
  const readKeys = () => { try { return existsSync(keyFile) ? JSON.parse(db.keys ? db.keys.readSecret(keyFile) : readFileSync(keyFile, 'utf8')) : {}; } catch { return {}; } };
  const writeKeys = (k) => { mkdirSync(keysDir(), { recursive: true }); const s = JSON.stringify(k); if (db.keys) db.keys.writeSecret(keyFile, s); else writeFileSync(keyFile, s, { mode: 0o600 }); };
  const keyState = () => { const k = readKeys(); return { twitch: !!(k.twitchId && k.twitchSecret), kick: !!(k.kickId && k.kickSecret), instagram: !!(k.igToken && k.igUser) }; };

  // ---------- the job queue: one at a time ----------
  let running = false;
  async function pump() {
    if (running) return;
    const job = state.jobs.find((j) => j.state === 'queued');
    if (!job) return;
    running = true; job.state = 'running'; job.text = 'Starting'; job.started = Date.now(); save();
    const t = tools();
    try {
      if (!t.hasFfmpeg) throw new Error('FFmpeg is not set up yet (Admin > Clipper)');
      if (job.make) {
        job.text = 'The free AI is writing the script (the first time it takes a minute to wake up)'; save();
        const sc = await (impl.writeScript ?? writeScript)(ask, { ...job.make, image: job.image });
        if (sc.error) throw new Error(sc.error);
        job.title = sc.title;
        const m = await makeVideo(t, sc, media, { on: (p) => { job.text = p.text; save(); }, voice: impl.voice });
        if (!m.ok) throw new Error(m.error);
        const id = `v${Date.now().toString(36)}`;
        state.finds.push({ id, file: m.file, thumb: m.thumb, title: sc.title, caption: (sc.scenes[0].caption || sc.title), post: sc.caption, streamer: '', source: 'made', seconds: m.seconds, caught: Date.now(), from: '', job: job.id, imported: false, score: m.gate.ok ? 70 : 40, signals: [{ id: 'screen', strength: m.gate.ok ? 0.8 : 0.4, detail: m.gate.ok ? 'Quality check passed: picture, sound and length are fine' : `Quality check: ${m.gate.problems.join('; ')}` }] });
        job.clips = 1; job.state = 'done'; job.text = m.gate.ok ? 'Your video is in the queue' : `Made, but the quality check says: ${m.gate.problems.join('; ')}`;
        job.ended = Date.now(); delete job.image; running = false; save(); setImmediate(pump); return;
      }
      let file = job.file, name = job.title;
      if (job.url) {
        if (!t.hasYtdlp && !impl.fetchVideo) throw new Error('yt-dlp is not set up yet (Admin > Clipper)');
        job.text = 'Fetching the video (a long stream can take a while)'; save();
        const r = await (impl.fetchVideo ?? fetchVideo)(t, job.url, join(home, 'downloads'));
        if (!r.ok) throw new Error(r.error);
        file = r.file; name = r.title || job.url;
      }
      job.title = name;
      const r = await clipFile(t, file, { outDir: media, source: job.streamer || name, need: job.need, len: job.len, max: job.max, on: (p) => { job.text = p.text; save(); }, senses: sense(), titler });
      if (!r.ok) throw new Error(r.error);
      for (const c of r.clips) state.finds.push({ ...c, streamer: job.streamer || '', source: job.source || 'vod', caught: Date.now(), from: job.url ?? '', job: job.id, imported: false });
      job.clips = r.clips.length; job.state = 'done'; job.seconds = r.seconds; job.blind = r.blind;
      job.text = r.clips.length ? `${r.clips.length} clip${r.clips.length === 1 ? '' : 's'} are in your queue` : 'No moment was strong enough. Try a looser setting in Clipper > Settings';
      if (job.url && file && !impl.fetchVideo && !job.keep) rmSync(file, { force: true });
    } catch (e) { job.state = 'error'; job.text = String(e.message ?? e).slice(0, 300); log(`${stamp()} Clipper: a job failed (${job.text})`); }
    job.ended = Date.now(); delete job.image; running = false; save();
    setImmediate(pump);
  }

  // ---------- who is live: the biggest streams of a game (needs the owner's free keys) ----------
  const tok = {};
  async function token(kind) {
    const k = readKeys();
    const c = tok[kind];
    if (c && c.exp > Date.now() + 60_000) return c.v;
    const [id, secret, url] = kind === 'twitch' ? [k.twitchId, k.twitchSecret, 'https://id.twitch.tv/oauth2/token'] : [k.kickId, k.kickSecret, 'https://id.kick.com/oauth/token'];
    if (!id || !secret) return '';
    const r = await doFetch(url, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: id, client_secret: secret, grant_type: 'client_credentials' }) });
    if (!r.ok) throw new Error(`${kind === 'twitch' ? 'Twitch' : 'Kick'} did not accept the keys (${r.status})`);
    const j = await r.json();
    tok[kind] = { v: j.access_token, exp: Date.now() + (j.expires_in ?? 3600) * 1000 };
    return tok[kind].v;
  }
  async function topTwitch(game, n) {
    const k = readKeys(), t = await token('twitch');
    if (!t) return { platform: 'twitch', error: 'Add your free Twitch keys first' };
    const h = { authorization: `Bearer ${t}`, 'client-id': k.twitchId };
    const g = await (await doFetch(`https://api.twitch.tv/helix/games?name=${encodeURIComponent(game)}`, { headers: h })).json();
    const id = g.data?.[0]?.id;
    if (!id) return { platform: 'twitch', error: `Twitch doesn't list a game called "${game}" yet` };
    const s = await (await doFetch(`https://api.twitch.tv/helix/streams?game_id=${id}&first=${Math.min(100, n * 3)}`, { headers: h })).json();
    return { platform: 'twitch', list: (s.data ?? []).filter((x) => x.type === 'live').slice(0, n).map((x) => ({ handle: x.user_login, name: x.user_name, viewers: x.viewer_count, title: x.title, platform: 'twitch', lang: x.language })) };
  }
  async function topKick(game, n) {
    const t = await token('kick');
    if (!t) return { platform: 'kick', error: 'Add your free Kick keys to include Kick' };
    const h = { authorization: `Bearer ${t}` };
    const c = await (await doFetch(`https://api.kick.com/public/v1/categories?q=${encodeURIComponent(game)}`, { headers: h })).json();
    const id = c.data?.[0]?.id;
    if (!id) return { platform: 'kick', error: `Kick doesn't list a category called "${game}" yet` };
    const s = await (await doFetch(`https://api.kick.com/public/v1/livestreams?category_id=${id}&sort=viewer_count&limit=${n}`, { headers: h })).json();
    return { platform: 'kick', list: (s.data ?? []).slice(0, n).map((x) => ({ handle: x.slug ?? x.broadcaster_user_name, name: x.broadcaster_user_name ?? x.slug, viewers: x.viewer_count, title: x.stream_title ?? '', platform: 'kick', lang: x.language ?? '' })) };
  }
  async function top(game, n) {
    const out = await Promise.all([topTwitch(game, n).catch((e) => ({ platform: 'twitch', error: e.message })), topKick(game, n).catch((e) => ({ platform: 'kick', error: e.message }))]);
    const list = out.flatMap((o) => o.list ?? []).sort((a, b) => b.viewers - a.viewers).slice(0, n);
    return { list, notes: out.filter((o) => o.error).map((o) => o.error) };
  }

  // ---------- the live watcher ----------
  const watchers = new Map(); // handle -> { child, timer, stop }
  const watching = () => [...watchers.keys()];
  function startWatch(w) {
    const key = `${w.platform}:${w.handle}`;
    if (watchers.has(key)) return;
    const t = tools();
    const dir = join(home, 'live', `${w.platform}-${w.handle}`);
    mkdirSync(dir, { recursive: true });
    const rec = { stopped: false, seen: new Set(), busy: false, child: null, chat: w.platform === 'twitch' && !impl.noChat ? twitchChat(w.handle) : null };
    watchers.set(key, rec);
    const launch = () => {
      if (rec.stopped) return;
      // yt-dlp finds the live address, ffmpeg writes it in pieces of CHUNK seconds
      const child = spawn(t.ytdlp, ['--no-warnings', '--ffmpeg-location', t.ffdir, '-f', 'b[height<=720]/b', '-o', '-', PLATFORMS[w.platform](w.handle)], { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
      const ff = spawn(t.ffmpeg, ['-nostdin', '-v', 'error', '-i', 'pipe:0', '-c', 'copy', '-f', 'segment', '-segment_time', String(CHUNK), '-reset_timestamps', '1', '-segment_format', 'mp4', '-segment_format_options', 'movflags=+faststart', join(dir, `${Date.now()}-%03d.mp4`)], { windowsHide: true, stdio: ['pipe', 'ignore', 'ignore'] });
      child.stdout.pipe(ff.stdin); ff.stdin.on('error', () => {});
      rec.child = [child, ff];
      const done = () => { try { child.kill(); ff.kill(); } catch { /* gone */ } rec.child = null; if (!rec.stopped) rec.retry = setTimeout(launch, 60_000); };
      child.on('close', done); ff.on('close', () => { try { child.kill(); } catch { /* gone */ } });
    };
    // every 20 seconds: a piece that is no longer the newest is finished: look at it, then delete it
    rec.timer = setInterval(async () => {
      if (rec.busy) return;
      const files = readdirSync(dir).filter((f) => f.endsWith('.mp4')).sort();
      const finished = rec.stopped ? files : files.slice(0, -1);
      for (const f of finished) {
        if (rec.seen.has(f)) continue;
        rec.seen.add(f); rec.busy = true;
        try {
          const file = join(dir, f);
          // Chat speed for this piece: the messages counted while it was recorded (Twitch only)
          const endMs = statSync(file).mtimeMs;
          const r = await clipFile(t, file, { outDir: media, source: w.handle, need: w.need ?? 3, len: w.len ?? 22, max: 3, senses: sense(), titler, chat: rec.chat ? (secs) => rec.chat.perSecond(endMs - secs * 1000, endMs) : null });
          for (const c of r.clips ?? []) state.finds.push({ ...c, streamer: w.handle, source: 'live', caught: Date.now(), from: PLATFORMS[w.platform](w.handle), job: 'live', imported: false });
          if (r.clips?.length) save();
          rmSync(file, { force: true });
        } catch (e) { log(`${stamp()} Clipper: a live piece failed (${e.message})`); }
        rec.busy = false;
      }
    }, 20_000);
    rec.timer.unref?.();
    if (!impl.noLaunch) launch();
    state.watch = [...state.watch.filter((x) => `${x.platform}:${x.handle}` !== key), { handle: w.handle, platform: w.platform }]; save();
  }
  function stopWatch(key) {
    const rec = watchers.get(key);
    if (!rec) return;
    rec.stopped = true; clearInterval(rec.timer); clearTimeout(rec.retry); rec.chat?.close();
    for (const c of rec.child ?? []) try { c.kill(); } catch { /* gone */ }
    watchers.delete(key);
    state.watch = state.watch.filter((x) => `${x.platform}:${x.handle}` !== key); save();
  }

  // ---------- what the app and Admin see ----------
  const pub = (f) => ({ id: f.id, post: f.post ?? '', title: f.title, caption: f.caption, streamer: f.streamer, source: f.source, seconds: f.seconds, caught: f.caught, signals: f.signals, score: f.score, from: f.from, hasThumb: !!f.thumb, hasFile: existsSync(f.file) });
  const info = () => {
    const t = tools();
    const s = sense();
    return { tools: { ffmpeg: t.hasFfmpeg, ytdlp: t.hasYtdlp, whisper: s.hasWhisper, face: s.hasFace, ai: llm.has(), dir: t.dir }, keys: keyState(), jobs: state.jobs.slice(-12).reverse(), watching: watching(), waiting: state.finds.filter((f) => !f.imported).length, posting: post.status() };
  };
  const post = poster({ ...ctx, home, keys: () => readKeys(), clipPath: (id) => findOf(id)?.file }, impl.post);
  const findOf = (id) => state.finds.find((f) => f.id === id);
  /** Clips older than 14 days that aren't waiting to be posted: the files go, so the disk doesn't fill */
  function sweep(now = Date.now()) {
    const keep = new Set(post.list().filter((p) => p.state === 'queued').map((p) => p.id));
    const old = state.finds.filter((f) => now - f.caught > 14 * 86400_000 && !keep.has(f.id));
    for (const f of old) for (const p of [f.file, f.thumb]) if (p && p.startsWith(media)) rmSync(p, { force: true });
    if (old.length) { state.finds = state.finds.filter((f) => !old.includes(f)); save(); }
    return old.length;
  }
  const sweeper = setInterval(() => sweep(), 6 * 3600_000); sweeper.unref?.();
  setTimeout(() => sweep(), 5000).unref?.();

  const routes = {
    'GET /api/admin/clipper': owner(() => [200, info()]),
    'POST /api/admin/clipper/link': owner((b, u, meta) => {
      const url = String(b.url ?? '').trim();
      if (!goodLink(url)) return [400, { error: 'Paste a full link that starts with https://', field: 'url' }];
      if (state.jobs.filter((j) => j.state === 'queued' || j.state === 'running').length >= 10) return [429, { error: 'There are already 10 videos waiting. Let some finish first' }];
      const job = { id: newId(), url, streamer: cleanHandle(b.streamer), source: 'vod', need: [2, 3, 4].includes(Number(b.need)) ? Number(b.need) : 3, len: Math.max(10, Math.min(45, Number(b.len) || 22)), max: Math.max(1, Math.min(20, Number(b.max) || 8)), state: 'queued', text: 'Waiting its turn', added: Date.now() };
      state.jobs.push(job); if (state.jobs.length > 60) state.jobs = state.jobs.slice(-60);
      record(db, { user: u.id, username: u.username, kind: 'admin', what: 'gave Clipper a video link', ip: meta?.ip });
      save(); setImmediate(pump);
      return [200, info()];
    }),
    // The video maker: an idea (and for a remix, the meme picture) becomes a finished short in the queue
    'POST /api/admin/clipper/make': owner((b, u, meta) => {
      const idea = String(b.idea ?? '').trim().slice(0, 1200);
      if (idea.length < 8) return [400, { error: 'Describe the video in a sentence or two', field: 'idea' }];
      const kind = ['comedy', 'story', 'remix'].includes(b.kind) ? b.kind : 'comedy';
      let image = null;
      if (b.image) {
        if (!/^image\/(png|jpeg|webp|gif)$/.test(String(b.image.type)) || !/^[A-Za-z0-9+/=]+$/.test(String(b.image.data)) || String(b.image.data).length > 5_000_000) return [400, { error: 'The meme has to be a png, jpg, webp or gif picture under 3 MB', field: 'image' }];
        image = { type: b.image.type, data: b.image.data };
      }
      if (state.jobs.filter((j) => j.state === 'queued' || j.state === 'running').length >= 10) return [429, { error: 'There are already 10 jobs waiting. Let some finish first' }];
      const job = { id: newId(), make: { idea, kind, seconds: Number(b.seconds) === 30 ? 30 : 60, look: '8-bit pixel' }, image, title: idea.slice(0, 60), streamer: '', state: 'queued', text: 'Waiting its turn', added: Date.now() };
      state.jobs.push(job); if (state.jobs.length > 60) state.jobs = state.jobs.slice(-60);
      record(db, { user: u.id, username: u.username, kind: 'admin', what: 'asked Clipper to make a video', ip: meta?.ip });
      save(); setImmediate(pump);
      return [200, info()];
    }),
    'POST /api/admin/clipper/job/cancel': owner((b) => {
      const j = state.jobs.find((x) => x.id === b.id && x.state === 'queued');
      if (!j) return [404, { error: 'That one is already running or finished' }];
      j.state = 'error'; j.text = 'Cancelled'; save(); return [200, info()];
    }),
    // New clips for the app's queue, and a way to tell the server they're in
    'GET /api/admin/clipper/finds': owner(() => [200, { finds: state.finds.filter((f) => !f.imported).map(pub) }]),
    'POST /api/admin/clipper/finds/imported': owner((b) => {
      const ids = new Set(Array.isArray(b.ids) ? b.ids.map(String) : []);
      for (const f of state.finds) if (ids.has(f.id)) f.imported = true;
      save(); return [200, { ok: true }];
    }),
    'GET /api/admin/clipper/media': owner((_b, _u, meta) => {
      const f = findOf(String(meta.q.get('id') ?? ''));
      const kind = meta.q.get('kind') === 'thumb' ? 'thumb' : 'clip';
      const p = kind === 'thumb' ? f?.thumb : f?.file;
      if (!f || !p || !existsSync(p) || !p.startsWith(media)) return [404, { error: 'That file is gone' }];
      return [200, readFileSync(p), { 'content-type': kind === 'thumb' ? 'image/jpeg' : 'video/mp4', 'cache-control': 'private, max-age=3600', 'content-length': String(statSync(p).size) }];
    }),
    // A skipped clip's files are freed; an approved one keeps its file until it's posted
    'POST /api/admin/clipper/finds/drop': owner((b) => {
      let n = 0;
      for (const id of Array.isArray(b.ids) ? b.ids.map(String) : []) { const f = findOf(id); if (!f) continue; for (const p of [f.file, f.thumb]) if (p && p.startsWith(media)) rmSync(p, { force: true }); state.finds = state.finds.filter((x) => x !== f); n++; }
      save(); return [200, { dropped: n }];
    }),
    // The biggest streams of a game right now
    'GET /api/admin/clipper/top': owner(async (_b, _u, meta) => {
      const game = String(meta.q.get('game') || 'Grand Theft Auto VI').slice(0, 80);
      const n = Math.max(1, Math.min(10, Number(meta.q.get('n')) || 10));
      try { return [200, await top(game, n)]; } catch (e) { return [502, { error: `Could not ask the platforms: ${String(e.message).slice(0, 160)}` }]; }
    }),
    'POST /api/admin/clipper/keys': owner((b, u, meta) => {
      if (meta?.public) return [403, { error: 'Do this at home: keys never travel over the internet', code: 'home' }];
      const k = readKeys(), next = { ...k };
      for (const f of ['twitchId', 'twitchSecret', 'kickId', 'kickSecret', 'igUser', 'igToken']) {
        if (typeof b[f] === 'string' && b[f].trim()) { if (!/^[\w.:@=-]{4,400}$/.test(b[f].trim())) return [400, { error: 'That key has a character a key never has. Copy it again', field: f }]; next[f] = b[f].trim(); }
      }
      writeKeys(next); for (const x of Object.keys(tok)) delete tok[x];
      log(`${stamp()} Clipper: keys saved by ${u.name} (kept in the Keys folder)`);
      return [200, info()];
    }),
    'POST /api/admin/clipper/keys/remove': owner((b, u, meta) => {
      if (meta?.public) return [403, { error: 'Do this at home', code: 'home' }];
      const k = readKeys();
      const groups = { twitch: ['twitchId', 'twitchSecret'], kick: ['kickId', 'kickSecret'], instagram: ['igUser', 'igToken'] };
      for (const f of groups[String(b.which)] ?? []) delete k[f];
      if (b.which === 'all') writeKeys({}); else writeKeys(k);
      for (const x of Object.keys(tok)) delete tok[x];
      return [200, info()];
    }),
    // The live watcher: which streams, on or off
    'POST /api/admin/clipper/watch': owner((b, u, meta) => {
      const want = (Array.isArray(b.streamers) ? b.streamers : []).slice(0, 10).map((s) => ({ handle: cleanHandle(s.handle), platform: PLATFORMS[s.platform] ? s.platform : 'twitch', need: [2, 3, 4].includes(Number(b.need)) ? Number(b.need) : 3 })).filter((s) => s.handle);
      const t = tools();
      if (want.length && (!t.hasFfmpeg || !t.hasYtdlp)) return [400, { error: 'FFmpeg and yt-dlp must be set up first (Admin > Clipper)' }];
      const keep = new Set(want.map((s) => `${s.platform}:${s.handle}`));
      for (const key of watching()) if (!keep.has(key)) stopWatch(key);
      for (const s of want) startWatch(s);
      record(db, { user: u.id, username: u.username, kind: 'admin', what: want.length ? `started Clipper's live watcher on ${want.length}` : "stopped Clipper's live watcher", ip: meta?.ip });
      return [200, info()];
    }),
    ...post.routes(owner)
  };
  return { routes, info, pump, top, sweep, startWatch, stopWatch, state: () => state, stop() { clearTimeout(saveT); clearInterval(sweeper); llm.stop(); const was = state.watch; for (const k of watching()) stopWatch(k); state.watch = was; post.stop?.(); if (state.jobs.length || state.finds.length || state.watch.length) try { mkdirSync(home, { recursive: true }); writeFileSync(stateFile, JSON.stringify(state)); } catch { /* disk gone */ } } };
}
