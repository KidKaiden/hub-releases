// Clipper's 8-bit art kit. A free AI model can write a story but can't draw, so it only CHOOSES from a kit that is drawn
// here in code: a background, up to two characters (kind, colours, pose, where), up to two props and an effect. Every
// scene is a 40 x 40 grid of 16 colours, made 27 times bigger with hard edges (1080 wide) by the video maker.
export const G = 40;
export const COLORS = { red: 4, blue: 5, green: 6, yellow: 7, purple: 8, orange: 9, pink: 10, brown: 11, grey: 12, white: 3, black: 2 };
export const BGS = ['sky', 'street', 'room', 'night', 'office', 'beach', 'forest', 'space', 'shop'];
export const KINDS = ['man', 'woman', 'kid', 'robot', 'cat', 'dog', 'alien'];
export const POSES = ['stand', 'shout', 'laugh', 'scared', 'point', 'run', 'sleep', 'angry'];
export const PROPS = ['car', 'house', 'tree', 'table', 'phone', 'money', 'fire', 'star', 'heart', 'box', 'cake', 'rocket', 'computer', 'sign', 'bed', 'chair'];
export const SPOTS = ['far left', 'left', 'center', 'right', 'far right'];
export const FX = ['none', 'exclaim', 'question', 'sparkle', 'sweat', 'anger'];
const SPOT_X = { 'far left': 7, left: 13, center: 20, right: 27, 'far right': 33 };
const HAIRS = ['black', 'brown', 'yellow', 'orange', 'red', 'white', 'purple', 'pink', 'blue', 'green', 'grey'];

// index: 0 wall/sky (per background) 1 skin 2 black 3 white 4 red 5 blue 6 green 7 yellow 8 purple 9 orange a pink b brown c grey d dark grey e ground f accent
const BASE = ['#000000', '#f2c9a0', '#14121c', '#ffffff', '#d9382f', '#2f6fe0', '#3fae4a', '#f5d33b', '#8a4fd0', '#f08a2c', '#ee7fb5', '#7a4a2a', '#9aa0aa', '#4a4e5a', '#000000', '#000000'];
const SCHEME = {
  sky: ['#7ec8f0', '#58b055', '#ffffff'], street: ['#f4a77a', '#5b5f6b', '#f5d33b'], room: ['#e8d5b5', '#b07a4a', '#8fc7ee'],
  night: ['#15153a', '#244a2e', '#f4f1c8'], office: ['#cfd8e3', '#8d97a6', '#8fc7ee'], beach: ['#8fd3f4', '#e8cf8e', '#3d8fd6'],
  forest: ['#a7d9a0', '#3d7a3a', '#2c5e2c'], space: ['#07071a', '#2b2b4a', '#c46cff'], shop: ['#f1c6d8', '#a98963', '#fff1b8']
};
export const paletteFor = (bg) => { const [c0, ce, cf] = SCHEME[bg] ?? SCHEME.sky; const p = [...BASE]; p[0] = c0; p[14] = ce; p[15] = cf; return p; };

class Canvas {
  constructor() { this.g = Array.from({ length: G }, () => Array(G).fill(0)); }
  px(x, y, c) { x = Math.round(x); y = Math.round(y); if (x >= 0 && y >= 0 && x < G && y < G) this.g[y][x] = c; }
  r(x, y, w, h, c) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.px(x + i, y + j, c); }
  disc(cx, cy, rad, c) { for (let y = -rad; y <= rad; y++) for (let x = -rad; x <= rad; x++) if (x * x + y * y <= rad * rad + rad * 0.6) this.px(cx + x, cy + y, c); }
  tri(cx, top, half, h, c) { for (let j = 0; j < h; j++) { const w = Math.round((half * (j + 1)) / h); this.r(cx - w, top + j, w * 2 + 1, 1, c); } }
  rows() { return this.g.map((row) => row.map((v) => v.toString(16)).join('')); }
}

// ---------------- Backgrounds (the ground line is row 31) ----------------
export const GROUND = 31;
function background(c, bg) {
  const gy = GROUND;
  c.r(0, gy, G, G - gy, 14);
  if (bg === 'sky') { for (const [x, y, w] of [[4, 5, 9], [24, 9, 11], [14, 14, 7]]) { c.r(x, y, w, 3, 3); c.r(x + 1, y - 1, w - 2, 1, 3); } c.r(0, gy, G, 1, 6); }
  if (bg === 'street') { let x = 0; const hs = [14, 20, 11, 24, 16, 9, 21]; hs.forEach((h, i) => { const w = 6; c.r(x, gy - h, w, h, 13); for (let wy = gy - h + 2; wy < gy - 2; wy += 3) for (let wx = x + 1; wx < x + w - 1; wx += 2) if ((wx + wy + i) % 3) c.px(wx, wy, 7); x += w; }); c.r(0, gy + 3, G, 1, 12); for (let i = 1; i < G; i += 6) c.r(i, gy + 5, 3, 1, 7); }
  if (bg === 'room') { c.r(0, 0, G, gy, 0); c.r(0, gy - 1, G, 1, 11); c.r(24, 6, 10, 10, 11); c.r(25, 7, 8, 8, 15); c.r(28, 7, 1, 8, 11); c.r(25, 11, 8, 1, 11); c.r(5, 8, 8, 6, 11); c.r(6, 9, 6, 4, 5); }
  if (bg === 'night') { for (const [x, y] of [[3, 3], [9, 9], [15, 4], [22, 11], [29, 5], [35, 12], [6, 17], [33, 20], [19, 19], [26, 2]]) c.px(x, y, 3); c.disc(31, 8, 4, 15); c.disc(33, 7, 3, 0); }
  if (bg === 'office') { c.r(0, gy - 1, G, 1, 13); c.r(3, 6, 12, 14, 15); c.r(4, 7, 10, 12, 0); c.r(8, 7, 1, 12, 12); c.r(4, 12, 10, 1, 12); c.r(24, 8, 12, 8, 3); c.r(25, 9, 10, 1, 12); c.r(25, 12, 7, 1, 12); }
  if (bg === 'beach') { c.r(0, 17, G, 14, 15); c.r(0, 17, G, 1, 3); for (let x = 2; x < G; x += 9) c.r(x, 22, 4, 1, 3); c.r(0, gy - 1, G, 1, 14); c.disc(32, 7, 4, 7); }
  if (bg === 'forest') { for (const [x, h] of [[3, 20], [11, 25], [20, 18], [28, 24], [36, 19]]) { c.r(x, gy - 9, 2, 9, 11); c.tri(x + 1, gy - h, 6, h - 8, 15); } c.r(0, gy, G, 1, 6); }
  if (bg === 'space') { for (const [x, y] of [[2, 4], [8, 12], [14, 3], [21, 8], [28, 4], [34, 11], [5, 22], [31, 19], [18, 16], [24, 24], [37, 27]]) c.px(x, y, 3); c.disc(31, 9, 6, 15); c.r(24, 9, 14, 1, 8); c.disc(8, 8, 2, 9); }
  if (bg === 'shop') { c.r(0, 6, G, 2, 11); c.r(0, 14, G, 2, 11); c.r(0, 22, G, 2, 11); for (let x = 1; x < G; x += 5) { c.r(x, 2, 3, 4, [4, 5, 7, 6][x % 4]); c.r(x + 1, 10, 3, 4, [7, 4, 6, 5][x % 4]); c.r(x, 18, 3, 4, [6, 7, 4, 5][x % 4]); } c.r(0, gy - 1, G, 1, 11); }
}

// ---------------- Characters ----------------
const DIMS = { man: { hw: 8, th: 8, lh: 7 }, woman: { hw: 8, th: 8, lh: 7 }, kid: { hw: 7, th: 5, lh: 4 }, alien: { hw: 8, th: 7, lh: 6 } };
function person(c, x, g, o) {
  const d = DIMS[o.kind] ?? DIMS.man, dir = o.dir;
  const shirt = COLORS[o.shirt] ?? 5, hair = COLORS[o.hair] ?? 2, skin = o.kind === 'alien' ? 6 : 1, pants = o.kind === 'woman' ? shirt : 13;
  const hw = d.hw, hx = x - Math.floor(hw / 2), legTop = g - d.lh, tTop = legTop - d.th, hTop = tTop - hw;
  const pose = o.pose;
  if (pose === 'sleep') { // lying down, head to the left
    c.r(x - 9, g - 5, 18, 5, shirt); c.r(x - 13, g - 6, 7, 6, skin); c.r(x - 13, g - 7, 7, 2, hair); c.r(x - 11, g - 4, 2, 1, 2); c.r(x + 9, g - 4, 6, 4, 13); c.r(x - 6, g - 7, 3, 2, 3); return;
  }
  // legs
  const run = pose === 'run';
  c.r(x - 4 + (run ? -1 : 0), legTop - (run ? 1 : 0), 3, d.lh + (run ? 0 : 0), pants); c.r(x + 1 + (run ? 2 : 0), legTop, 3, d.lh - (run ? 1 : 0), pants);
  c.r(x - 5 + (run ? -1 : 0), g - 1, 4, 1, 2); c.r(x + 1 + (run ? 2 : 0), g - 1, 4, 1, 2);
  // torso
  c.r(x - 4, tTop, 8, d.th, shirt);
  if (o.kind === 'woman') { c.r(x - 5, legTop - 1, 10, 2, shirt); }
  // arms (hands in skin)
  const up = pose === 'shout' || pose === 'laugh', scared = pose === 'scared', angry = pose === 'angry';
  if (up) { c.r(x - 7, tTop - 6, 2, 9, shirt); c.r(x - 7, tTop - 8, 2, 2, skin); c.r(x + 5, tTop - 6, 2, 9, shirt); c.r(x + 5, tTop - 8, 2, 2, skin); }
  else if (scared) { c.r(x - 7, tTop - 3, 2, 8, shirt); c.r(x - 6, hTop + 3, 2, 3, skin); c.r(x + 5, tTop - 3, 2, 8, shirt); c.r(x + 4, hTop + 3, 2, 3, skin); }
  else if (angry) { c.r(x - 7, tTop + 1, 2, 6, shirt); c.r(x - 7, tTop + 6, 2, 2, skin); c.r(x + 5, tTop - 4, 2, 9, shirt); c.r(x + 5, tTop - 6, 2, 2, skin); }
  else if (pose === 'point') { c.r(x - 7, tTop + 1, 2, 7, shirt); c.r(x - 7, tTop + 8, 2, 2, skin); const ax = dir > 0 ? x + 4 : x - 12; c.r(ax, tTop + 1, 8, 2, shirt); c.r(dir > 0 ? ax + 8 : ax - 2, tTop + 1, 2, 2, skin); }
  else { c.r(x - 7, tTop + 1, 2, 7, shirt); c.r(x - 7, tTop + 8, 2, 2, skin); c.r(x + 5, tTop + 1, 2, 7, shirt); c.r(x + 5, tTop + 8, 2, 2, skin); }
  // head
  c.r(hx, hTop, hw, hw, skin);
  if (o.kind === 'alien') { c.r(hx - 1, hTop + 1, hw + 2, hw - 2, skin); c.r(x - 1, hTop - 3, 1, 3, 6); c.disc(x - 1, hTop - 4, 1, 4); c.r(hx, hTop + 2, 3, 3, 2); c.r(hx + hw - 3, hTop + 2, 3, 3, 2); c.px(hx + 1, hTop + 3, 3); c.px(hx + hw - 2, hTop + 3, 3); }
  else {
    c.r(hx, hTop - 1, hw, 3, hair); c.r(hx - 1, hTop, 1, 4, hair); c.r(hx + hw, hTop, 1, 4, hair);
    if (o.kind === 'woman') { c.r(hx - 1, hTop, 2, hw + 4, hair); c.r(hx + hw - 1, hTop, 2, hw + 4, hair); }
    const ey = hTop + Math.floor(hw / 2) - 1, e1 = hx + 1, e2 = hx + hw - 3;
    if (scared || pose === 'shout') { c.r(e1, ey - 1, 2, 3, 3); c.r(e2, ey - 1, 2, 3, 3); c.px(e1 + (dir > 0 ? 1 : 0), ey, 2); c.px(e2 + (dir > 0 ? 1 : 0), ey, 2); }
    else { c.r(e1, ey, 2, 2, 2); c.r(e2, ey, 2, 2, 2); }
    if (angry) { c.r(e1 - 1, ey - 2, 3, 1, 2); c.r(e2, ey - 2, 3, 1, 2); }
    const my = hTop + hw - 3;
    if (pose === 'shout' || scared) { c.r(x - 1, my - 1, 3, 3, 2); c.px(x, my + 1, 4); }
    else if (pose === 'laugh') { c.r(x - 2, my - 1, 5, 3, 2); c.r(x - 2, my - 1, 5, 1, 3); }
    else if (angry) { c.r(x - 2, my, 4, 1, 2); c.px(x - 2, my + 1, 2); c.px(x + 1, my + 1, 2); }
    else if (pose === 'point' || pose === 'stand' || run) { c.r(x - 1, my, 3, 1, 2); c.px(x - 2, my - 1, 2); c.px(x + 2, my - 1, 2); }
  }
}
function robot(c, x, g, o) {
  const body = COLORS[o.shirt] ?? 12;
  c.r(x - 4, g - 4, 3, 4, 13); c.r(x + 1, g - 4, 3, 4, 13); c.r(x - 6, g - 1, 5, 1, 2); c.r(x + 1, g - 1, 5, 1, 2);
  c.r(x - 5, g - 14, 10, 10, body); c.r(x - 3, g - 12, 6, 3, 15); c.px(x, g - 8, 4); c.px(x + 2, g - 8, 7);
  const up = o.pose === 'shout' || o.pose === 'laugh';
  c.r(x - 8, up ? g - 19 : g - 13, 3, up ? 9 : 7, 13); c.r(x + 5, up ? g - 19 : g - 13, 3, up ? 9 : 7, 13);
  c.r(x - 4, g - 22, 8, 8, body); c.r(x - 3, g - 20, 2, 2, 4); c.r(x + 1, g - 20, 2, 2, 4); c.r(x - 2, g - 16, 4, 1, 2); c.r(x, g - 26, 1, 4, 13); c.disc(x, g - 27, 1, 4);
}
function animal(c, x, g, o) {
  const col = COLORS[o.shirt] ?? (o.kind === 'cat' ? 9 : 11), dir = o.dir, cat = o.kind === 'cat';
  c.r(x - 6, g - 7, 12, 6, col); c.r(x - 6, g - 2, 2, 2, col); c.r(x + 4, g - 2, 2, 2, col);
  const hx = dir > 0 ? x + 3 : x - 9;
  c.r(hx, g - 12, 6, 6, col); c.px(hx + (dir > 0 ? 1 : 4), g - 13, col); c.px(hx + (dir > 0 ? 4 : 1), g - 13, col);
  if (cat) { c.px(hx, g - 13, col); c.px(hx + 5, g - 13, col); }
  else { c.r(hx + (dir > 0 ? 5 : -1), g - 12, 1, 4, 11); }
  c.px(hx + 1, g - 10, 2); c.px(hx + 4, g - 10, 2); c.px(hx + 2, g - 8, 4);
  const tx = dir > 0 ? x - 9 : x + 6; c.r(tx, g - 10, 3, 2, col); c.r(tx + (dir > 0 ? 0 : 2), g - 12, 1, 3, col);
  if (o.pose === 'shout' || o.pose === 'laugh') c.r(hx + 2, g - 8, 2, 2, 2);
}

// ---------------- Props ----------------
function prop(c, kind, x, g, color) {
  const col = COLORS[color] ?? null;
  if (kind === 'car') { const b = col ?? 4; c.r(x - 10, g - 7, 20, 5, b); c.r(x - 5, g - 12, 11, 5, b); c.r(x - 4, g - 11, 4, 4, 15); c.r(x + 1, g - 11, 4, 4, 15); c.disc(x - 6, g - 2, 2, 2); c.disc(x + 6, g - 2, 2, 2); c.px(x + 10, g - 5, 7); c.px(x - 11, g - 5, 4); }
  if (kind === 'house') { const b = col ?? 3; c.r(x - 9, g - 14, 18, 14, b); c.tri(x, g - 23, 12, 9, 4); c.r(x - 2, g - 8, 4, 8, 11); c.r(x - 7, g - 11, 4, 4, 15); c.r(x + 3, g - 11, 4, 4, 15); }
  if (kind === 'tree') { c.r(x - 1, g - 9, 3, 9, 11); c.disc(x, g - 14, 6, 6); c.disc(x - 3, g - 11, 3, 6); c.disc(x + 4, g - 11, 3, 6); }
  if (kind === 'table') { c.r(x - 8, g - 8, 16, 2, 11); c.r(x - 7, g - 6, 2, 6, 11); c.r(x + 5, g - 6, 2, 6, 11); }
  if (kind === 'chair') { c.r(x - 4, g - 7, 8, 2, 11); c.r(x - 4, g - 14, 2, 8, 11); c.r(x - 4, g - 5, 2, 5, 11); c.r(x + 2, g - 5, 2, 5, 11); }
  if (kind === 'bed') { c.r(x - 10, g - 6, 20, 3, 11); c.r(x - 10, g - 9, 20, 3, col ?? 5); c.r(x - 9, g - 10, 6, 2, 3); c.r(x - 10, g - 3, 2, 3, 11); c.r(x + 8, g - 3, 2, 3, 11); }
  if (kind === 'phone') { c.r(x - 2, g - 9, 5, 9, 2); c.r(x - 1, g - 8, 3, 6, 5); c.px(x, g - 1, 3); }
  if (kind === 'money') { for (let i = 0; i < 3; i++) c.r(x - 5 + i, g - 3 - i * 3, 10, 3, 6); c.r(x - 5, g - 3, 10, 1, 2); c.px(x, g - 8, 7); c.px(x + 1, g - 8, 7); c.px(x, g - 5, 7); }
  if (kind === 'fire') { c.tri(x, g - 13, 5, 13, 9); c.tri(x, g - 9, 3, 9, 7); c.tri(x, g - 6, 1, 6, 3); c.px(x - 6, g - 5, 4); c.px(x + 6, g - 8, 4); }
  if (kind === 'star') { c.r(x - 1, g - 13, 3, 11, 7); c.r(x - 6, g - 9, 13, 3, 7); c.r(x - 4, g - 11, 9, 7, 7); c.px(x, g - 8, 3); }
  if (kind === 'heart') { c.disc(x - 3, g - 11, 3, 4); c.disc(x + 3, g - 11, 3, 4); c.tri(x, g - 11, 6, 8, 4); }
  if (kind === 'box') { c.r(x - 5, g - 9, 10, 9, col ?? 11); c.r(x - 1, g - 9, 2, 9, 7); c.r(x - 5, g - 6, 10, 1, 7); }
  if (kind === 'cake') { c.r(x - 7, g - 5, 14, 5, 10); c.r(x - 5, g - 9, 10, 4, 3); c.r(x - 7, g - 5, 14, 1, 4); c.r(x, g - 13, 1, 4, 7); c.px(x, g - 14, 9); }
  if (kind === 'rocket') { c.r(x - 3, g - 20, 7, 14, 3); c.tri(x, g - 27, 3, 7, 4); c.r(x - 6, g - 9, 3, 6, 4); c.r(x + 4, g - 9, 3, 6, 4); c.disc(x, g - 14, 2, 5); c.tri(x, g - 5, 2, 5, 9); }
  if (kind === 'computer') { c.r(x - 7, g - 14, 14, 10, 13); c.r(x - 6, g - 13, 12, 8, 5); c.r(x - 1, g - 4, 3, 3, 13); c.r(x - 5, g - 1, 11, 1, 13); c.px(x - 3, g - 11, 3); c.px(x - 2, g - 10, 3); }
  if (kind === 'sign') { c.r(x - 1, g - 12, 2, 12, 11); c.r(x - 7, g - 19, 14, 8, 3); c.r(x - 7, g - 19, 14, 1, 2); c.r(x - 7, g - 12, 14, 1, 2); c.r(x - 5, g - 16, 10, 1, 4); c.r(x - 5, g - 14, 7, 1, 12); }
}
function effect(c, fx, x, g) {
  const top = g - 30;
  if (fx === 'exclaim') { c.r(x + 7, top, 2, 6, 4); c.r(x + 7, top + 8, 2, 2, 4); }
  if (fx === 'question') { c.r(x + 6, top, 4, 2, 7); c.r(x + 9, top + 2, 2, 3, 7); c.r(x + 7, top + 5, 2, 2, 7); c.r(x + 7, top + 9, 2, 2, 7); }
  if (fx === 'sparkle') { for (const [dx, dy] of [[-9, 2], [9, 0], [-6, -3], [8, 6]]) { c.px(x + dx, top + dy + 6, 7); c.px(x + dx - 1, top + dy + 6, 7); c.px(x + dx + 1, top + dy + 6, 7); c.px(x + dx, top + dy + 5, 7); c.px(x + dx, top + dy + 7, 7); } }
  if (fx === 'sweat') { c.tri(x + 7, top + 6, 1, 3, 5); c.r(x + 6, top + 9, 3, 2, 5); }
  if (fx === 'anger') { c.r(x - 9, top + 6, 3, 1, 4); c.r(x - 8, top + 5, 1, 3, 4); c.r(x + 7, top + 6, 3, 1, 4); c.r(x + 8, top + 5, 1, 3, 4); }
}

const HALF = { car: 11, house: 10, tree: 7, table: 9, rocket: 7, bed: 11, sign: 8, computer: 8, chair: 5, phone: 3, money: 6, fire: 6, star: 7, heart: 7, box: 6, cake: 8 };
const SMALL = new Set(['phone', 'money', 'cake', 'box', 'heart', 'star', 'fire']);

/** A scene spec (already checked) -> { palette: 16 colours, rows: 40 strings of 40 hex digits } */
export function renderScene(spec, { lift = 0 } = {}) {
  const bg = BGS.includes(spec.bg) ? spec.bg : 'sky';
  const c = new Canvas();
  background(c, bg);
  const g = GROUND;
  const actors = (spec.actors ?? []).slice(0, 2);
  // Props go where they don't hide a character: the asked-for spot if it is free, else the nearest free one
  // Two characters and a big prop: the characters stand at the two ends so the prop shows between them; two at one spot are spread out
  const big = (spec.props ?? []).some((p) => PROPS.includes(p.kind) && !SMALL.has(p.kind));
  let axs = actors.map((a) => SPOT_X[a.at] ?? 20);
  if (actors.length === 2 && (big || Math.abs(axs[0] - axs[1]) < 10)) axs = [big ? 9 : 13, big ? 31 : 27];
  const taken = actors.map((a, i) => ({ x: axs[i], half: a.pose === 'sleep' ? 14 : 8 }));
  const props = (spec.props ?? []).filter((p) => PROPS.includes(p.kind)).slice(0, 2).map((p) => {
    const half = HALF[p.kind] ?? 6, want = SPOT_X[p.at] ?? 20;
    const free = (x) => taken.every((t) => Math.abs(t.x - x) >= t.half + half - 8) && x - half >= -2 && x + half <= G + 2;
    const spots = Object.values(SPOT_X).sort((a, b) => Math.abs(a - want) - Math.abs(b - want));
    const x = free(want) ? want : spots.find(free) ?? want;
    taken.push({ x, half });
    return { ...p, x, front: SMALL.has(p.kind) };
  });
  for (const p of props) if (!p.front) prop(c, p.kind, p.x, g + (p.kind === 'car' ? 2 : 0), p.color);
  for (const [i, a] of actors.entries()) {
    const x = axs[i], o = { kind: KINDS.includes(a.kind) ? a.kind : 'man', shirt: a.shirt, hair: HAIRS.includes(a.hair) ? a.hair : 'brown', pose: POSES.includes(a.pose) ? a.pose : 'stand', dir: x > 20 ? -1 : 1 };
    const gy = g + 2 - lift;
    if (o.kind === 'robot') robot(c, x, gy, o); else if (o.kind === 'cat' || o.kind === 'dog') animal(c, x, gy, o); else person(c, x, gy, o);
  }
  for (const p of props) if (p.front) prop(c, p.kind, p.x, g + 2, p.color);
  if (spec.fx && FX.includes(spec.fx) && spec.fx !== 'none' && actors[0]) effect(c, spec.fx, axs[0], g + 2);
  return { palette: paletteFor(bg), rows: c.rows() };
}
