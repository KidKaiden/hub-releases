// Clipper's engine (plans/clipper/PLAN.md): from one video file, find the moments worth clipping and cut them.
// It uses only FFmpeg (a separate program, called as a process; nothing is copied in): sound jumps, shouting (the voice
// band getting loud) and fast visual change are measured per second; a moment is cut only when enough of these agree
// (the Moment judge), starts a little before the peak (the Ranker), and is laid out for a phone (blurred fill, the
// whole picture centred, a caption on top). What it can't see yet (a face, words said, chat) is named in `blind`.
import { execFile } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { assCaptions, facesOver, mainFace, transcribe } from './clipper-senses.mjs';

const run = (cmd, args, { timeout = 30 * 60_000, cwd } = {}) => new Promise((ok) => {
  execFile(cmd, args, { timeout, windowsHide: true, maxBuffer: 256 << 20, cwd }, (e, out, err) => ok({ ok: !e, out: String(out ?? ''), err: String(err ?? ''), code: e?.code }));
});

/** Where the two tools are: the Hub's Tools\clipper folder (next to the ecosystem folder), or what a test hands over. */
export function toolPaths(dir) {
  const ffdir = join(dir, 'ffmpeg');
  const t = { dir, ffmpeg: join(ffdir, 'ffmpeg.exe'), ffprobe: join(ffdir, 'ffprobe.exe'), ytdlp: join(dir, 'yt-dlp', 'yt-dlp.exe'), ffdir };
  return { ...t, hasFfmpeg: existsSync(t.ffmpeg) && existsSync(t.ffprobe), hasYtdlp: existsSync(t.ytdlp) };
}

// ---------------- Reading what FFmpeg prints ----------------
/** ametadata/astats lines: "frame:..  pts:.. pts_time:12" then "lavfi.astats.Overall.RMS_level=-23.4" */
export function parseLevels(text, key = 'lavfi.astats.Overall.RMS_level') {
  const out = [];
  let t = null;
  for (const line of String(text).split(/\r?\n/)) {
    const m = /pts_time:([\d.]+)/.exec(line);
    if (m) { t = Number(m[1]); continue; }
    if (line.startsWith(key + '=') && t !== null) {
      const v = line.slice(key.length + 1).trim();
      out.push({ t, db: v === '-inf' || v === 'nan' ? -90 : Math.max(-90, Number(v)) });
    }
  }
  return out;
}
/** select='gt(scene,..)' + metadata=print lines: "pts_time:5.2" then "lavfi.scene_score=0.41" */
export function parseScenes(text) {
  const out = [];
  let t = null;
  for (const line of String(text).split(/\r?\n/)) {
    const m = /pts_time:([\d.]+)/.exec(line);
    if (m) { t = Number(m[1]); continue; }
    const s = /lavfi\.scene_score=([\d.]+)/.exec(line);
    if (s && t !== null) out.push({ t, score: Number(s[1]) });
  }
  return out;
}
const bySecond = (list, n, f) => { const a = new Array(n).fill(null); for (const x of list) { const i = Math.min(n - 1, Math.floor(x.t)); if (i >= 0) a[i] = f(x, a[i]); } return a; };
const median = (a) => { const s = a.filter((x) => x !== null && Number.isFinite(x)).sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : 0; };
const clamp01 = (x) => Math.max(0, Math.min(1, x));
const mmss = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
export { mmss };

// ---------------- The judge ----------------
/** Same rule as the app's model.ts: how many different signals are clearly above normal (0.5 or more) */
export const agreeing = (signals) => new Set(signals.filter((s) => s.strength >= 0.5).map((s) => s.id)).size;
export function scoreOf(signals) {
  const best = new Map();
  for (const s of signals) best.set(s.id, Math.max(best.get(s.id) ?? 0, s.strength));
  const v = [...best.values()].sort((a, b) => b - a);
  return Math.round(Math.min(100, v.reduce((t, x, i) => t + x * (i === 0 ? 40 : 20), 0)));
}

/**
 * Per-second strengths (0 to 1) for each signal, from what FFmpeg measured.
 * sound: how far the whole sound is above this video's usual level (15 dB above = 1)
 * voice: the same in the voice band (300 to 3400 Hz): shouting, an excited line (12 dB above = 1)
 * screen: how much the picture changed that second (cuts, a banner, an explosion)
 */
export function strengths({ sound = [], voice = [], scenes = [], chat = [], seconds }) {
  const n = Math.max(1, Math.ceil(seconds));
  const lvl = (list) => { const a = bySecond(list, n, (x, old) => Math.max(old ?? -90, x.db)); const m = median(a); return a.map((x) => (x === null ? 0 : x - m)); };
  const so = lvl(sound), vo = lvl(voice);
  const sc = bySecond(scenes, n, (x, old) => (old ?? 0) + x.score).map((x) => x ?? 0);
  return {
    sound: so.map((d) => clamp01(d / 15)),
    voice: vo.map((d) => clamp01(d / 12)),
    screen: sc.map((s) => clamp01(s / 1.2)),
    // chat: messages that second against this stream's usual (6 times the usual = 1); a trickle never counts
    chat: (() => { const base = Math.max(1, median(chat)); return Array.from({ length: n }, (_, i) => { const c = chat[i] ?? 0; return c >= 3 ? clamp01((c / base - 1) / 5) : 0; }); })(),
    have: { sound: sound.length > 0, voice: voice.length > 0, screen: scenes.length > 0, chat: chat.length > 0 }
  };
}

/**
 * Find moments: windows where enough signals agree.
 * need: how many must agree (2 to 4; capped at what this video can show). len: the clip's length in seconds.
 * Returns the best first, never overlapping.
 */
export function findMoments(st, { seconds, need = 3, len = 22, lead = 4, max = 8, minGap = 10 } = {}) {
  const have = Object.entries(st.have).filter(([, v]) => v).map(([k]) => k);
  const want = Math.max(1, Math.min(need, have.length));
  const n = Math.ceil(seconds);
  const cands = [];
  for (let t = 0; t < n; t++) {
    // look at a 5-second window centred here: the best of each signal
    const best = (arr) => { let b = 0; for (let i = Math.max(0, t - 2); i <= Math.min(n - 1, t + 2); i++) b = Math.max(b, arr[i] ?? 0); return b; };
    const sig = [
      { id: 'sound', strength: best(st.sound) },
      { id: 'speech', strength: best(st.voice) },
      { id: 'screen', strength: best(st.screen) },
      { id: 'chat', strength: best(st.chat ?? []) }
    ].filter((s) => s.strength > 0.15 || have.includes(s.id === 'speech' ? 'voice' : s.id));
    if (agreeing(sig) < want) continue;
    cands.push({ t, signals: sig, score: scoreOf(sig) });
  }
  // best first; keep a moment only if it's far enough from a better one
  cands.sort((a, b) => b.score - a.score || a.t - b.t);
  const out = [];
  for (const c of cands) {
    if (out.length >= max) break;
    if (out.some((o) => Math.abs(o.peak - c.t) < Math.max(minGap, len / 2))) continue;
    const start = Math.max(0, Math.min(c.t - lead, Math.max(0, seconds - len)));
    const length = Math.min(len, Math.max(5, Math.floor(seconds - start)));
    out.push({ peak: c.t, start, length, score: c.score, signals: c.signals });
  }
  return out;
}

const SOUND_WORDS = { sound: (t, s) => `Sound jumped well above normal at ${mmss(t)}`, speech: (t) => `Shouting or a raised voice at ${mmss(t)}`, screen: (t) => `The picture changed fast at ${mmss(t)}`, chat: (t) => `Chat sped up at ${mmss(t)}` };
/** The signals as the app shows them (id, a plain sentence, strength), only the ones that count */
export function describe(m) {
  return m.signals.filter((s) => s.strength >= 0.3).map((s) => ({ id: s.id, strength: Math.round(s.strength * 100) / 100, detail: SOUND_WORDS[s.id](m.peak, s) }));
}
/** A plain title and caption with no AI: who, what stood out. The Hub's AI can rewrite these (clipper.mjs). */
export function plainTitle(m, source = '') {
  const kinds = new Set(m.signals.filter((s) => s.strength >= 0.5).map((s) => s.id));
  const what = kinds.has('speech') && kinds.has('sound') ? 'A loud, shouted moment' : kinds.has('screen') && kinds.has('sound') ? 'Something big happens on screen, and it gets loud' : kinds.has('speech') ? 'A raised voice' : 'A big moment';
  return { title: `${what} at ${mmss(m.peak)}${source ? ` in ${source}` : ''}`.slice(0, 120), caption: kinds.has('speech') ? 'WAIT {FOR} IT' : kinds.has('screen') ? 'WHAT {JUST} HAPPENED' : 'LISTEN {TO} THIS' };
}

// ---------------- FFmpeg ----------------
export async function probe(t, file) {
  const r = await run(t.ffprobe, ['-v', 'error', '-show_entries', 'format=duration:stream=codec_type', '-of', 'json', file], { timeout: 60_000 });
  if (!r.ok) return null;
  try { const j = JSON.parse(r.out); return { seconds: Number(j.format?.duration ?? 0), hasAudio: (j.streams ?? []).some((s) => s.codec_type === 'audio'), hasVideo: (j.streams ?? []).some((s) => s.codec_type === 'video') }; } catch { return null; }
}

/** Measure a whole video: one pass for sound + voice, one for the picture. */
export async function measure(t, file, info, chat = null) {
  let sound = [], voice = [], scenes = [];
  if (info.hasAudio) {
    const af = (extra) => `${extra}aresample=16000,asetnsamples=n=16000:p=0,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-`;
    const [a, b] = await Promise.all([
      run(t.ffmpeg, ['-nostdin', '-v', 'error', '-i', file, '-vn', '-af', af(''), '-f', 'null', '-']),
      run(t.ffmpeg, ['-nostdin', '-v', 'error', '-i', file, '-vn', '-af', af('highpass=f=300,lowpass=f=3400,'), '-f', 'null', '-'])
    ]);
    sound = parseLevels(a.out); voice = parseLevels(b.out);
  }
  if (info.hasVideo) {
    const r = await run(t.ffmpeg, ['-nostdin', '-v', 'error', '-i', file, '-an', '-vf', "fps=4,scale=320:-2,select='gt(scene,0.25)',metadata=print:file=-", '-f', 'null', '-']);
    scenes = parseScenes(r.out);
  }
  return strengths({ sound, voice, scenes, chat: chat ?? [], seconds: info.seconds });
}

const esc = (p) => p.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "\\'");
const FONT = 'C:/Windows/Fonts/arialbd.ttf';
const FONTS_DIR = 'C:/Windows/Fonts';

/**
 * Cut one moment into a phone-shaped (1080 x 1920) clip.
 *   With a face (a streamer's webcam): the face zoomed on top, the whole game under it, captions below: face first.
 *   Without: the whole picture centred over a blurred copy of itself.
 * Captions: the words said, a few at a time, the word being said in yellow (an ASS file), else a headline on top.
 */
export async function cut(t, file, m, out, { caption = '', work, ass = '', face = null } = {}) {
  mkdirSync(dirname(out), { recursive: true });
  const dirw = work ?? dirname(out);
  const blur = '[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=24:6[bg]';
  let chain;
  if (face) {
    const fw = Math.min(1, Math.max(face.w * 3.4, 0.18)).toFixed(4), cx = (face.x + face.w / 2).toFixed(4), cy = (face.y + face.h / 2).toFixed(4);
    chain = `[0:v]split=3[a][b][c];${blur};[b]crop=w='min(ih,iw*${fw}*2/3)*3/2':h='min(ih,iw*${fw}*2/3)':x='clip(iw*${cx}-out_w/2,0,iw-out_w)':y='clip(ih*${cy}-out_h/2,0,ih-out_h)',scale=1080:720[f];[c]scale=1080:608:force_original_aspect_ratio=decrease[g];[bg][f]overlay=0:150[t1];[t1][g]overlay=(W-w)/2:910[v0]`;
  } else chain = `[0:v]split[a][b];${blur};[b]scale=1080:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2[v0]`;
  let last = 'v0';
  if (ass && existsSync(FONTS_DIR)) {
    const af = join(dirw, `cap-${Date.now()}-${Math.round(Math.random() * 1e6)}.ass`);
    writeFileSync(af, ass, 'utf8');
    chain += `;[${last}]ass='${esc(af)}':fontsdir='${esc(FONTS_DIR)}'[v1]`;
    last = 'v1';
  } else if (caption && existsSync(FONT)) {
    const tf = join(dirw, `cap-${Date.now()}-${Math.round(Math.random() * 1e6)}.txt`);
    writeFileSync(tf, caption.replace(/[{}]/g, '').trim().toUpperCase().slice(0, 60));
    chain += `;[${last}]drawtext=fontfile='${esc(FONT)}':textfile='${esc(tf)}':fontsize=84:fontcolor=white:borderw=6:bordercolor=black:x=(w-text_w)/2:y=220[v1]`;
    last = 'v1';
  }
  const r = await run(t.ffmpeg, ['-nostdin', '-y', '-v', 'error', '-ss', String(m.start), '-t', String(m.length), '-i', file, '-filter_complex', chain, '-map', `[${last}]`, '-map', '0:a?', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', out], { timeout: 10 * 60_000 });
  if (!r.ok || !existsSync(out)) return { ok: false, error: (r.err || 'FFmpeg could not cut this').slice(-300) };
  return { ok: true };
}
export async function thumb(t, clipFile, out) {
  const r = await run(t.ffmpeg, ['-nostdin', '-y', '-v', 'error', '-ss', '1.5', '-i', clipFile, '-frames:v', '1', '-vf', 'scale=360:-2', out], { timeout: 60_000 });
  return r.ok && existsSync(out);
}

/** Make the cut start and end on whole words (never mid-word), and not trail off into silence. Pure. */
export function snapToWords(m, words, seconds) {
  let start = m.start, end = Math.min(seconds, m.start + m.length);
  const cross = (x) => words.find((w) => w.t0 < x && x < w.t1);
  const a = cross(start); if (a) start = a.t0;
  const b = cross(end); if (b) end = Math.min(seconds, b.t1 + 0.25);
  const inside = words.filter((w) => w.t0 >= start && w.t1 <= end);
  if (inside.length && end - (inside[inside.length - 1].t1 + 0.6) > 1.5 && inside[inside.length - 1].t1 + 0.6 - start >= 8) end = inside[inside.length - 1].t1 + 0.6;
  return { ...m, start, length: Math.max(5, end - start) };
}

/**
 * The whole job for one video file: measure, find, then for each moment hear the words, find the face, cut.
 * senses: sensePaths(...) (optional); chat: messages per second of this file (optional); titler: async ({ text, source, signals }) -> { title, caption } | null.
 */
export async function clipFile(t, file, { outDir, source = '', need = 3, len = 22, max = 8, on = () => {}, senses = null, chat = null, titler = null } = {}) {
  const info = await probe(t, file);
  if (!info || !info.seconds) return { ok: false, error: "FFmpeg couldn't read this video" };
  on({ step: 'listening', text: `Listening to ${mmss(info.seconds)} of video` });
  const chatArr = typeof chat === 'function' ? chat(info.seconds) : chat;
  const st = await measure(t, file, info, chatArr);
  const moments = findMoments(st, { seconds: info.seconds, need, len, max });
  const blind = [];
  if (!senses?.hasFace) blind.push('A face to start the clip on');
  if (!senses?.hasWhisper) blind.push('The words said (captions word by word)');
  if (!chatArr) blind.push('Chat speed');
  if (!moments.length) return { ok: true, seconds: info.seconds, clips: [], blind, have: st.have };
  const clips = [];
  for (let i = 0; i < moments.length; i++) {
    let m = moments[i];
    on({ step: 'cutting', text: `Clip ${i + 1} of ${moments.length}: ${senses?.hasWhisper ? 'listening to the words' : 'cutting'}` });
    let words = [], text = '';
    if (senses?.hasWhisper) {
      const ws = Math.max(0, m.start - 3), we = Math.min(info.seconds, m.start + m.length + 3);
      const tr = await transcribe(t, senses, file, { start: ws, length: we - ws, work: outDir }).catch(() => ({ ok: false }));
      if (tr.ok && tr.words.length) {
        const abs = tr.words.map((w) => ({ ...w, t0: w.t0 + ws, t1: w.t1 + ws }));
        m = snapToWords(m, abs, info.seconds);
        words = abs.filter((w) => w.t0 >= m.start && w.t1 <= m.start + m.length).map((w) => ({ ...w, t0: w.t0 - m.start, t1: w.t1 - m.start }));
        text = words.map((w) => w.text).join(' ');
      }
    }
    let face = null;
    const signals = describe(m);
    if (senses?.hasFace) {
      const fo = await facesOver(t, senses, file, { start: m.start, length: Math.min(8, m.length) }).catch(() => ({ ok: false }));
      if (fo.ok) { face = mainFace(fo.frames); if (face && face.first <= 1.5) signals.push({ id: 'screen', strength: 0.9, detail: 'A face is on screen from the first second' }); }
    }
    let { title, caption } = plainTitle(m, source);
    if (titler && text.length > 20) { const x = await titler({ text, source, signals }).catch(() => null); if (x?.title) { title = String(x.title).slice(0, 120); caption = String(x.caption || caption).slice(0, 60); } }
    const id = `c${Date.now().toString(36)}${i}`;
    const out = join(outDir, `${id}.mp4`);
    const c = await cut(t, file, m, out, { caption, work: outDir, ass: assCaptions(words, { y: face ? 1560 : 1330 }), face });
    if (!c.ok) { on({ step: 'cutting', text: `Clip ${i + 1} failed: ${c.error}` }); continue; }
    const th = join(outDir, `${id}.jpg`);
    const hasThumb = await thumb(t, out, th);
    clips.push({ id, file: out, thumb: hasThumb ? th : '', start: m.start, seconds: Math.round(m.length), peak: m.peak, score: Math.min(100, m.score + (face ? 8 : 0)), signals, title, caption, words: words.length, face: !!face });
  }
  return { ok: true, seconds: info.seconds, clips, blind, have: st.have };
}

// ---------------- Fetching a video from a link ----------------
/** Only http(s) links, nothing that starts with a dash, no spaces or shell characters */
export const goodLink = (u) => /^https?:\/\/[^\s"'<>`|&;$\\]{4,500}$/i.test(String(u ?? '').trim());
export async function fetchVideo(t, url, dir, { maxHeight = 720 } = {}) {
  mkdirSync(dir, { recursive: true });
  const r = await run(t.ytdlp, ['--no-playlist', '--no-warnings', '--ffmpeg-location', t.ffdir, '-f', `bv*[height<=${maxHeight}]+ba/b[height<=${maxHeight}]/b`, '--merge-output-format', 'mp4', '-o', join(dir, '%(id)s.%(ext)s'), '--print', 'after_move:filepath', '--print', 'before_dl:%(title)s', '--', url], { timeout: 3 * 3600_000 });
  const lines = r.out.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  const file = [...lines].reverse().find((l) => /\.(mp4|mkv|webm|mov)$/i.test(l) && existsSync(l));
  if (!r.ok || !file) return { ok: false, error: (r.err.split(/\r?\n/).filter(Boolean).pop() || 'yt-dlp could not get that video').slice(0, 300) };
  return { ok: true, file, title: lines.find((l) => l !== file) ?? '' };
}
