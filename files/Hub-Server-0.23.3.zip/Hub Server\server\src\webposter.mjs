// Posting through a real browser, signed in as the owner: the way to post to Instagram, TikTok, Facebook (and YouTube without Google's
// developer keys) without any developer account, API key or approval. It does what a person does: open the site, choose the video,
// type the caption, press the post button. It uses the PC's own Edge (or Chrome), with a separate profile kept in the Publisher folder.
//
// Signing in is done by the owner in a normal browser window (no automation running, so Google and the others do not object):
// connect() opens that window on the sign-in page, the owner signs in and closes it, and the server then checks the profile holds a
// session. Posting later opens the same profile under automation, does the steps, and closes it.
// The profile (cookies) stays on this PC, in the Publisher folder, encrypted by the browser with the Windows account's key.
//
// Each site is a small "flow" (a list of steps in plain words over the Driver below), so when a site changes its page only its flow
// needs a line changed. A failed run saves a screenshot in Publisher/errors so the page it got stuck on can be seen.
// *[To test]* the flows follow what the sites' pages looked like when written and need the owner's real accounts to be proven.
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { spawn } from 'node:child_process';

export const WEB_PLATFORMS = ['instagram', 'tiktok', 'facebook', 'youtube'];
/** Where to sign in, and which cookies prove a session is there */
export const SITES = {
  instagram: { name: 'Instagram', login: 'https://www.instagram.com/accounts/login/', cookies: [{ host: 'instagram.com', names: ['sessionid'] }] },
  tiktok: { name: 'TikTok', login: 'https://www.tiktok.com/login', cookies: [{ host: 'tiktok.com', names: ['sessionid', 'sid_tt'] }] },
  facebook: { name: 'Facebook', login: 'https://www.facebook.com/login/', cookies: [{ host: 'facebook.com', names: ['c_user'] }, { host: 'facebook.com', names: ['xs'] }] },
  youtube: { name: 'YouTube', login: 'https://accounts.google.com/ServiceLogin?service=youtube&continue=https://studio.youtube.com', cookies: [{ host: 'google.com', names: ['SAPISID', '__Secure-3PAPISID'] }] }
};

/** Is a session there? cookies: what the browser holds (name, domain) */
export function hasSession(platform, cookies) {
  const s = SITES[platform]; if (!s) return false;
  return s.cookies.every((rule) => cookies.some((c) => String(c.domain ?? '').replace(/^\./, '').endsWith(rule.host) && rule.names.includes(c.name) && String(c.value ?? 'x').length > 0));
}

const BROWSERS = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
];
export const findBrowser = (override) => [override, ...BROWSERS].filter(Boolean).find((p) => existsSync(p)) ?? null;

// ---------------------------------------------------------------------------------------------------------------- the Driver
/**
 * What a flow can do, in plain words. A "target" is a CSS selector, { role, name } or { text }, or a list of them (the first that is
 * there is used, so a flow can name the old and the new wording of a button). Frames are searched too (TikTok used one).
 */
export class Driver {
  constructor(page, { sleep = (ms) => new Promise((r) => setTimeout(r, ms)), jitter = true } = {}) { this.page = page; this.sleep = sleep; this.jitter = jitter; }
  #loc(frame, t) {
    if (typeof t === 'string') return frame.locator(t);
    if (t.role) return frame.getByRole(t.role, { name: t.name });
    if (t.text) return frame.getByText(t.text);
    if (t.label) return frame.getByLabel(t.label);
    return frame.locator(t.css);
  }
  #all(targets) { const ts = [].concat(targets); const out = []; for (const f of this.page.frames()) for (const t of ts) out.push(this.#loc(f, t)); return out; }
  async pause(ms = 800) { await this.sleep(this.jitter ? ms * (0.7 + Math.random() * 0.8) : ms); }
  async goto(url) { await this.page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60_000 }); await this.pause(1500); }
  /** The first target that is on the page now (visible), or null */
  async find(targets) {
    for (const l of this.#all(targets)) { try { const f = l.first(); if (await f.isVisible({ timeout: 200 })) return f; } catch { /* not here */ } }
    return null;
  }
  async has(targets) { return !!(await this.find(targets)); }
  /** Wait until one is there, then return it */
  async wait(targets, { timeout = 20_000, optional = false } = {}) {
    const end = Date.now() + timeout;
    for (;;) { const f = await this.find(targets); if (f) return f; if (Date.now() > end) { if (optional) return null; throw new Error(`The page never showed ${describe(targets)}`); } await this.sleep(400); }
  }
  async click(targets, o = {}) { const f = await this.wait(targets, o); if (!f) return false; await f.click({ timeout: 15_000 }); await this.pause(900); return true; }
  /** Press a button that may stay greyed out for a while (like Post while a video is still uploading) */
  async clickWhenReady(targets, { timeout = 600_000 } = {}) {
    const end = Date.now() + timeout;
    for (;;) {
      const f = await this.find(targets);
      if (f) { let on = true; try { on = await f.isEnabled({ timeout: 300 }); const aria = await f.getAttribute('aria-disabled', { timeout: 300 }); if (aria === 'true') on = false; } catch { /* treat as enabled */ } if (on) { await f.click({ timeout: 15_000 }); await this.pause(900); return; } }
      if (Date.now() > end) throw new Error(`${describe(targets)} never became ready (the video may still be uploading)`);
      await this.sleep(1500);
    }
  }
  /** Give the page the video: it is put straight into the page's file box */
  async upload(path, { timeout = 30_000 } = {}) {
    const end = Date.now() + timeout;
    for (;;) {
      for (const f of this.page.frames()) { const box = f.locator('input[type="file"]'); if (await box.count().catch(() => 0)) { await box.first().setInputFiles(path); await this.pause(1500); return; } }
      if (Date.now() > end) throw new Error('The page never offered a place to put the video');
      await this.sleep(500);
    }
  }
  /** Replace what is in a text box with the text */
  async type(targets, text, o = {}) {
    const f = await this.wait(targets, o); if (!f) return false;
    await f.click({ timeout: 15_000 }); await this.page.keyboard.press('Control+A'); await this.page.keyboard.press('Delete');
    await this.page.keyboard.insertText(String(text)); await this.pause(600); return true;
  }
  /** Set a drop-down: open it and pick the wanted option. True when it ends up as wanted, false when the page does not offer that option. */
  async pick(trigger, option, already) {
    const box = await this.wait(trigger, { timeout: 30_000 });
    let now = ''; try { now = String(await box.innerText({ timeout: 2000 })).trim(); } catch { /* unreadable: open it anyway */ }
    if (already.test(now)) return true;
    await box.click({ timeout: 15_000 }); await this.pause(800);
    const o = await this.wait(option, { timeout: 4000, optional: true });
    if (!o) { await this.press('Escape'); return false; }
    await o.click({ timeout: 15_000 }); await this.pause(800); return true;
  }
  async press(key) { try { await this.page.keyboard.press(key); } catch { /* nothing focused */ } await this.pause(400); }
  /**
   * Sites throw questions and tips over the page just when it is needed (a "turn on checks?" box, a "new features" tip). Anything that
   * covers the page stops every click, so this clears them: it presses the "not now" kind of buttons and, for boxes with no such button,
   * Escape. It never presses an accepting button (Allow, Accept, Turn on) by itself: a flow that is meant to accept one says so, by name.
   */
  async clearPopups(boxes = [], { rounds = 6 } = {}) {
    const later = [{ role: 'button', name: /^(got it|not now|maybe later|no thanks|dismiss|skip for now|remind me later)$/i }];
    let quiet = 0;
    for (let i = 0; i < rounds && quiet < 2; i++) {
      let did = false;
      const b = await this.find(later); if (b) { try { await b.click({ timeout: 4000 }); did = true; await this.pause(500); } catch { /* it went by itself */ } }
      if (boxes.length && await this.find(boxes)) { await this.press('Escape'); did = true; }
      if (did) quiet = 0; else { quiet++; await this.sleep(700); }
    }
  }
  async seen(regexOrTargets, { timeout = 30_000 } = {}) {
    const ts = regexOrTargets instanceof RegExp ? [{ text: regexOrTargets }] : regexOrTargets;
    try { await this.wait(ts, { timeout }); return true; } catch { return false; }
  }
  async shot(path) { try { await this.page.screenshot({ path, fullPage: false }); } catch { /* no picture */ } }
}
const describe = (t) => [].concat(t).map((x) => (typeof x === 'string' ? x : x.role ? `${x.role} "${x.name}"` : x.text ? `text ${x.text}` : x.label ? `label ${x.label}` : x.css)).slice(0, 2).join(' or ');

// ---------------------------------------------------------------------------------------------------------------------- flows
/** job: { path, caption, title, description, format, privacy } */
export const FLOWS = {
  async instagram(d, job) {
    await d.goto('https://www.instagram.com/');
    await d.click([{ role: 'button', name: /^(not now|decline optional cookies)$/i }], { optional: true, timeout: 3000 });
    await d.clearPopups([], { rounds: 3 });
    await d.click([{ role: 'link', name: /^(new post|create)$/i }, 'svg[aria-label="New post"]', { text: /^create$/i }]);
    await d.click([{ role: 'link', name: /^post$/i }, { role: 'menuitem', name: /^post$/i }, { text: /^post$/i }], { optional: true, timeout: 4000 });
    await d.upload(job.path);
    await d.click([{ role: 'button', name: /^ok$/i }], { optional: true, timeout: 6000 }); // "video posts are now shared as reels"
    for (let i = 0; i < 2; i++) await d.click([{ role: 'button', name: /^next$/i }, { text: /^next$/i }], { timeout: 120_000 });
    await d.type(['div[aria-label="Write a caption..."]', { role: 'textbox', name: /caption/i }, '[contenteditable="true"]'], job.caption);
    await d.clickWhenReady([{ role: 'button', name: /^share$/i }, { text: /^share$/i }]);
    if (!(await d.seen(/(post|reel) (has been )?shared|your (post|reel) (has been )?shared/i, { timeout: 300_000 }))) throw new Error('Instagram never said the post was shared');
    return { url: '' };
  },
  async tiktok(d, job) {
    await d.goto('https://www.tiktok.com/tiktokstudio/upload');
    await d.upload(job.path, { timeout: 60_000 });
    // TikTok asks "turn on automatic content checks?" and shows a "new editing features" tip as soon as the video is in; they cover the page and
    // block every click, so they are dealt with first. The owner said to turn the content checks on (TikTok's own copyright check on their
    // account), so that one box is accepted; nothing else is: any other box is only closed or dismissed.
    const BOXES = [{ text: /turn on automatic content checks/i }];
    await d.wait(BOXES.concat([{ role: 'button', name: /^got it$/i }]), { optional: true, timeout: 20_000 });
    if (await d.has(BOXES)) await d.click([{ role: 'button', name: /^turn on$/i }], { optional: true, timeout: 5000 });
    await d.clearPopups(BOXES);
    // the caption starts as the file's name: it is replaced with the real one
    await d.type(['.public-DraftEditor-content[contenteditable="true"]', 'div[contenteditable="true"][role="combobox"]', '[contenteditable="true"]'], job.caption, { timeout: 60_000 });
    await d.clearPopups(BOXES, { rounds: 3 });
    // who can see it: TikTok starts at "Followers". Never post with the wrong audience: if the wanted one is not offered, stop.
    const want = { public: { word: 'Everyone', rx: /^(everyone|public)$/i }, followers: { word: 'Followers', rx: /^(followers|friends)\b/i } /* a public account is offered "Friends" in its place */, private: { word: 'Only you', rx: /^only you$/i } }[job.visibility ?? 'public'] ?? { word: 'Everyone', rx: /^(everyone|public)$/i };
    const set = await d.pick(['[data-e2e="video_visibility_container"] [role="combobox"]', { role: 'combobox', name: /followers|everyone|only you|friends/i }], [{ role: 'option', name: want.rx }], want.rx);
    if (!set) throw new Error(`TikTok does not offer "${want.word}" for who can see the post on this account${want.word === 'Everyone' ? ' (usually because the account is set to Private: turn off Private account in TikTok > Settings and privacy > Privacy)' : ''}. Nothing was posted`);
    await d.clickWhenReady(['[data-e2e="post_video_button"]', { role: 'button', name: /^post$/i }], { timeout: 600_000 });
    await d.click([{ role: 'button', name: /^post now$/i }], { optional: true, timeout: 6000 }); // the "post anyway?" question
    if (!(await d.seen(/(video|post) (has been )?(uploaded|published)|manage your posts|your video is being uploaded|upload another video/i, { timeout: 120_000 }))) throw new Error('TikTok never confirmed the post');
    return { url: '' };
  },
  async facebook(d, job) {
    await d.goto('https://www.facebook.com/reels/create');
    await d.upload(job.path, { timeout: 60_000 });
    for (let i = 0; i < 2; i++) await d.click([{ role: 'button', name: /^next$/i }, { text: /^next$/i }], { optional: i === 1, timeout: 90_000 });
    await d.type([{ role: 'textbox', name: /describe your reel|description/i }, 'div[aria-label*="escribe" i][contenteditable="true"]', '[contenteditable="true"]'], job.caption, { optional: true, timeout: 20_000 });
    await d.clickWhenReady([{ role: 'button', name: /^publish$/i }, { text: /^publish$/i }]);
    if (!(await d.seen(/(your )?reel (is|has been) (now )?(published|shared|live)|processing|you.?ve shared/i, { timeout: 120_000 }))) throw new Error('Facebook never confirmed the reel');
    return { url: '' };
  },
  async youtube(d, job) {
    await d.goto('https://studio.youtube.com/');
    await d.click(['#create-icon', { role: 'button', name: /^create$/i }]);
    await d.click(['#text-item-0', { role: 'menuitem', name: /upload videos?/i }]);
    await d.upload(job.path, { timeout: 60_000 });
    await d.type(['#title-textarea #textbox', { role: 'textbox', name: /title/i }], String(job.title).slice(0, 100), { timeout: 60_000 });
    await d.type(['#description-textarea #textbox', { role: 'textbox', name: /description/i }], job.description, { optional: true });
    await d.click(['[name="VIDEO_MADE_FOR_KIDS_NOT_MADE_FOR_KIDS"]', { text: /no, it.?s not made for kids/i }]);
    for (let i = 0; i < 3; i++) await d.click(['#next-button', { role: 'button', name: /^next$/i }], { timeout: 120_000 });
    const vis = { public: 'PUBLIC', unlisted: 'UNLISTED', private: 'PRIVATE' }[job.privacy] ?? 'PUBLIC';
    await d.click([`[name="${vis}"]`, { text: new RegExp(`^${vis}$`, 'i') }]);
    await d.clickWhenReady(['#done-button', { role: 'button', name: /^(publish|save|done)$/i }], { timeout: 900_000 });
    if (!(await d.seen(/video (is )?(published|uploaded)|video published|processing will begin|upload complete/i, { timeout: 120_000 }))) throw new Error('YouTube never confirmed the upload');
    return { url: '' };
  }
};

// ----------------------------------------------------------------------------------------------------------------- the poster
/**
 * dir: the Publisher folder. impl (for tests): launch(profileDir, { show }) -> { page, cookies(), close() }, spawnBrowser, flows, sleep.
 */
export function webPoster({ dir, browserPath, log = () => {}, impl = {} }) {
  const profiles = join(dir, 'Browser'), errors = join(dir, 'errors'), file = join(dir, 'web.json');
  let saved = {}; try { saved = JSON.parse(readFileSync(file, 'utf8')); } catch { /* none yet */ }
  const live = {}; // sign-ins in progress: { platform: { waiting, error, child } }
  const write = () => { try { mkdirSync(dir, { recursive: true }); writeFileSync(file, JSON.stringify(saved)); } catch { /* it is only a note */ } };
  const profileOf = (p) => join(profiles, p);
  const browser = () => findBrowser(browserPath);

  /** A browser on the profile under automation (the real one; tests give their own) */
  async function launch(platform, { show = false } = {}) {
    if (impl.launch) return impl.launch(profileOf(platform), { show });
    const exe = browser(); if (!exe) throw new Error('Edge or Chrome was not found on this PC');
    const { chromium } = await import('playwright-core');
    const ctx = await chromium.launchPersistentContext(profileOf(platform), {
      executablePath: exe, headless: !show && impl.headless === true, viewport: { width: 1280, height: 900 }, acceptDownloads: false,
      ignoreDefaultArgs: ['--enable-automation'],
      args: ['--disable-blink-features=AutomationControlled', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows', '--disable-features=CalculateNativeWinOcclusion', ...(show ? [] : ['--window-position=-2400,60'])]
    });
    const page = ctx.pages()[0] ?? (await ctx.newPage());
    return { page, cookies: () => ctx.cookies(), close: () => ctx.close() };
  }
  async function verify(platform) {
    let b; try { b = await launch(platform, { show: false }); const ok = hasSession(platform, await b.cookies()); return ok; } catch (e) { log(`Web poster: could not check ${platform} (${e.message})`); return false; } finally { try { await b?.close(); } catch { /* closed */ } }
  }
  const markConnected = (platform, ok) => { if (ok) saved[platform] = { at: Date.now() }; else delete saved[platform]; write(); };

  return {
    available: () => !!(impl.launch || browser()),
    status() { return Object.fromEntries(WEB_PLATFORMS.map((p) => [p, { connected: !!saved[p], waiting: !!live[p]?.waiting, error: live[p]?.error ?? '' }])); },
    /** Open an ordinary browser window on the site's sign-in page. The owner signs in and closes the window; then it is checked. */
    async connect(platform) {
      const site = SITES[platform]; if (!site) throw new Error('Unknown platform');
      if (live[platform]?.waiting) return;
      const exe = browser(); if (!exe && !impl.spawnBrowser) throw new Error('Edge or Chrome was not found on this PC');
      mkdirSync(profileOf(platform), { recursive: true });
      live[platform] = { waiting: true, error: '' };
      const args = [`--user-data-dir=${profileOf(platform)}`, '--no-first-run', '--no-default-browser-check', '--new-window', site.login];
      const done = async (code) => {
        const ok = await verify(platform);
        markConnected(platform, ok);
        live[platform] = { waiting: false, error: ok ? '' : `${site.name} was not signed in when the window closed. Press Connect and sign in, then close the window` };
        log(`Web poster: ${site.name} ${ok ? 'connected' : 'not signed in'}`);
      };
      if (impl.spawnBrowser) { void impl.spawnBrowser(args).then(done); return; }
      const child = spawn(exe, args, { stdio: 'ignore', detached: false });
      live[platform].child = child;
      child.on('exit', () => { void done(); });
      child.on('error', (e) => { live[platform] = { waiting: false, error: `Could not open the browser: ${e.message}` }; });
    },
    async disconnect(platform) {
      try { live[platform]?.child?.kill(); } catch { /* gone */ }
      delete live[platform]; markConnected(platform, false);
      try { rmSync(profileOf(platform), { recursive: true, force: true }); } catch { /* in use */ }
    },
    /** Post one video. Returns { url }. Throws with a plain sentence. */
    async post(platform, job) {
      if (!saved[platform]) throw new Error(`${SITES[platform]?.name ?? platform} is not connected (Publish > Where do they go?)`);
      const flow = (impl.flows ?? FLOWS)[platform]; if (!flow) throw new Error('No way to post to that yet');
      let b;
      try {
        b = await launch(platform, { show: false });
        const d = impl.driver ? impl.driver(b.page) : new Driver(b.page, { sleep: impl.sleep });
        if (!hasSession(platform, await b.cookies())) { markConnected(platform, false); throw new Error(`${SITES[platform].name} has signed you out. Connect it again`); }
        const out = await Promise.race([flow(d, job), new Promise((_, rej) => { const t = setTimeout(() => rej(new Error('It took more than 30 minutes, so it was stopped')), impl.limitMs ?? 30 * 60_000); t.unref?.(); })]);
        return out ?? { url: '' };
      } catch (e) {
        try { mkdirSync(errors, { recursive: true }); await new Driver(b?.page ?? { screenshot: async () => {} }).shot(join(errors, `${Date.now()}-${platform}.png`)); } catch { /* no picture */ }
        throw new Error(String(e.message ?? e).split('\n')[0].slice(0, 200));
      } finally { try { await b?.close(); } catch { /* closed */ } }
    },
    stop() { for (const l of Object.values(live)) { try { l.child?.kill(); } catch { /* gone */ } } }
  };
}
