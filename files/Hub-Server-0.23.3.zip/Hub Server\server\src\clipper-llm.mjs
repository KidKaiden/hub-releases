// Clipper's free AI: llama.cpp's own server (MIT) running Qwen2.5-VL (a model that reads text and pictures) on this PC's
// graphics card through Vulkan. Nothing leaves the PC and nothing is billed. It starts when a job needs it and stops
// by itself a few minutes after the last question, so it doesn't sit on the graphics card.
import { spawn } from 'node:child_process';
import { existsSync, readdirSync, statSync } from 'node:fs';
import net from 'node:net';
import { join } from 'node:path';

/** Where the program and the model files are (null parts when missing) */
export function llmPaths(toolsDir) {
  const root = join(toolsDir, 'llm');
  const find = (dir, name, depth = 3) => {
    try {
      for (const f of readdirSync(dir)) {
        const p = join(dir, f);
        if (f.toLowerCase() === name) return p;
        if (depth && statSync(p).isDirectory()) { const r = find(p, name, depth - 1); if (r) return r; }
      }
    } catch { /* no folder */ }
    return '';
  };
  const server = find(join(root, 'bin'), 'llama-server.exe');
  const model = join(root, 'qwen2.5-vl-7b-q4_k_m.gguf'), mmproj = join(root, 'qwen2.5-vl-mmproj-f16.gguf');
  return { server, model, mmproj, has: !!server && existsSync(model) && existsSync(mmproj) };
}

const freePort = () => new Promise((ok, no) => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => ok(p)); }); s.on('error', no); });

export function localLlm(toolsDir, { idleMs = 5 * 60_000, log = () => {}, fetch: doFetch = fetch, spawn: doSpawn = spawn } = {}) {
  const p = llmPaths(toolsDir);
  let child = null, port = 0, starting = null, idle = null, queue = Promise.resolve();

  async function up() {
    if (child && port) return;
    if (starting) return starting;
    starting = (async () => {
      port = await freePort();
      child = doSpawn(p.server, ['-m', p.model, '--mmproj', p.mmproj, '--host', '127.0.0.1', '--port', String(port), '-ngl', '99', '-c', '8192', '--no-webui', '--jinja'], { windowsHide: true, stdio: ['ignore', 'ignore', 'ignore'] });
      child.on('close', () => { child = null; port = 0; });
      for (let i = 0; i < 240; i++) {
        if (!child) throw new Error('The free AI program stopped as it started. The graphics card may be busy');
        try { const r = await doFetch(`http://127.0.0.1:${port}/health`); if (r.ok) return; } catch { /* still loading the model */ }
        await new Promise((r) => setTimeout(r, 1000));
      }
      throw new Error('The free AI took too long to start');
    })().finally(() => { starting = null; });
    return starting;
  }
  const down = () => { clearTimeout(idle); idle = null; try { child?.kill(); } catch { /* gone */ } child = null; port = 0; };
  const touch = () => { clearTimeout(idle); idle = setTimeout(down, idleMs); idle.unref?.(); };

  /**
   * One question. content: a string, or [{ text }, { image: { type, data } }] for a picture (base64 data).
   * schema: a JSON schema the answer must follow (the server forces it). One question at a time (the card is shared).
   * Returns { text } or { error } in plain words.
   */
  function ask({ system, content, max = 2000, schema = null, temperature = 0.7 }) {
    const run = async () => {
      if (!p.has) return { error: 'The free AI is not installed on this PC yet' };
      try {
        await up(); touch();
        const user = typeof content === 'string' ? content : content.map((c) => (c.image ? { type: 'image_url', image_url: { url: `data:${c.image.type};base64,${c.image.data}` } } : { type: 'text', text: c.text }));
        const r = await doFetch(`http://127.0.0.1:${port}/v1/chat/completions`, {
          method: 'POST', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ messages: [{ role: 'system', content: system }, { role: 'user', content: user }], max_tokens: max, temperature, ...(schema ? { response_format: { type: 'json_schema', json_schema: { name: 'answer', strict: true, schema } } } : {}) })
        });
        if (!r.ok) return { error: `The free AI said ${r.status}` };
        const j = await r.json();
        touch();
        return { text: String(j.choices?.[0]?.message?.content ?? '') };
      } catch (e) { log(`Clipper free AI: ${e.message}`); return { error: String(e.message ?? e).slice(0, 200) }; }
    };
    const next = queue.then(run, run);
    queue = next.catch(() => {});
    return next;
  }
  return { ask, has: () => p.has, paths: p, stop: down, running: () => !!child };
}
