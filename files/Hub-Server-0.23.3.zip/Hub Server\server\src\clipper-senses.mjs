// Clipper's other senses, each a separate small program or model run as a process, never copied in:
//   hearing words: whisper.cpp (MIT) with the small English model -> every word with its time -> word-by-word captions
//   seeing a face: YuNet (OpenCV zoo, Apache) through onnxruntime-node -> where a streamer's face is -> the face-first layout
//   reading chat: Twitch's own public chat (read-only, no sign-in) -> messages per second
// Each is optional: when one isn't installed, Clipper says so and carries on without it.
import { execFile } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

const run = (cmd, args, timeout = 20 * 60_000) => new Promise((ok) => execFile(cmd, args, { timeout, windowsHide: true, maxBuffer: 512 << 20, encoding: 'buffer' }, (e, out, err) => ok({ ok: !e, out, err: String(err ?? e?.message ?? '') })));

export function sensePaths(toolsDir) {
  const wd = join(toolsDir, 'whisper'), fd = join(toolsDir, 'face');
  const p = { whisper: join(wd, 'whisper-cli.exe'), model: join(wd, 'ggml-small.en.bin'), yunet: join(fd, 'yunet.onnx') };
  return { ...p, hasWhisper: existsSync(p.whisper) && existsSync(p.model), hasFace: existsSync(p.yunet) };
}

// ---------------- Words ----------------
/** whisper.cpp's JSON (one word per entry, times in ms) -> [{ t0, t1, text }] in seconds, offset by `shift` */
export function parseWords(json, shift = 0) {
  let j; try { j = typeof json === 'string' ? JSON.parse(json) : json; } catch { return []; }
  const out = [];
  for (const s of j?.transcription ?? []) {
    const text = String(s.text ?? '').trim();
    if (!text || /^\[.*\]$|^\(.*\)$|^♪/.test(text)) continue; // [MUSIC], (laughs), notes: not words
    out.push({ t0: shift + (s.offsets?.from ?? 0) / 1000, t1: shift + (s.offsets?.to ?? 0) / 1000, text });
  }
  return out;
}
/** Every word of a video, with its time. Only the part from `start` for `length` seconds when given (a clip). */
export async function transcribe(t, s, file, { start = 0, length = 0, work }) {
  if (!s.hasWhisper) return { ok: false, error: 'Speech to text is not installed' };
  mkdirSync(work, { recursive: true });
  const wav = join(work, `w-${Date.now()}-${Math.round(Math.random() * 1e5)}.wav`);
  const a = await run(t.ffmpeg, ['-nostdin', '-y', '-v', 'error', ...(length ? ['-ss', String(start), '-t', String(length)] : []), '-i', file, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', wav], 10 * 60_000);
  if (!a.ok || !existsSync(wav)) return { ok: false, error: 'No sound to listen to' };
  const base = wav.replace(/\.wav$/, '');
  const r = await run(s.whisper, ['-m', s.model, '-f', wav, '-oj', '-ml', '1', '-sow', '-of', base, '-np', '-t', '8', '-l', 'en'], 40 * 60_000);
  const jf = `${base}.json`;
  if (!existsSync(jf)) return { ok: false, error: `Speech to text failed: ${r.err.slice(-160)}` };
  return { ok: true, words: parseWords(readFileSync(jf, 'utf8'), 0) };
}

/** Groups of up to 3 words that fit on one line, each with the time it shows */
export function groups(words, { max = 3, gap = 0.7 } = {}) {
  const out = [];
  let cur = [];
  for (const w of words) {
    if (cur.length && (cur.length >= max || w.t0 - cur[cur.length - 1].t1 > gap)) { out.push(cur); cur = []; }
    cur.push(w);
  }
  if (cur.length) out.push(cur);
  return out;
}
const assTime = (s) => { const c = Math.max(0, Math.round(s * 100)); return `${Math.floor(c / 360000)}:${String(Math.floor(c / 6000) % 60).padStart(2, '0')}:${String(Math.floor(c / 100) % 60).padStart(2, '0')}.${String(c % 100).padStart(2, '0')}`; };
const assText = (s) => s.replace(/[{}\\]/g, '').toUpperCase();
/**
 * Word-by-word captions as an ASS file: each group of words shows while it's spoken, the word being said is yellow.
 * `words` are in the clip's own time (0 = the clip's first frame). y: where the text sits on the 1080 x 1920 picture.
 */
export function assCaptions(words, { y = 1480, size = 84 } = {}) {
  const head = `[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\nWrapStyle: 2\n\n[V4+ Styles]\nFormat: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\nStyle: Cap,Arial,${size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,7,2,8,60,60,${y},1\n\n[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n`;
  const lines = [];
  for (const g of groups(words)) {
    for (let i = 0; i < g.length; i++) {
      const from = g[i].t0, to = i + 1 < g.length ? g[i + 1].t0 : Math.max(g[i].t1, g[i].t0 + 0.25);
      const text = g.map((w, k) => (k === i ? `{\\c&H00E2FF&}${assText(w.text)}{\\c&HFFFFFF&}` : assText(w.text))).join(' ');
      lines.push(`Dialogue: 0,${assTime(from)},${assTime(to)},Cap,,0,0,0,,${text}`);
    }
  }
  return lines.length ? head + lines.join('\n') + '\n' : '';
}

// ---------------- Faces ----------------
let ort = null, session = null, sessionFor = '';
async function yunet(path) {
  if (!ort) ort = await import('onnxruntime-node');
  if (!session || sessionFor !== path) { session = await ort.InferenceSession.create(path); sessionFor = path; }
  return { ort, session };
}
/** YuNet's twelve outputs -> faces [{ x, y, w, h, score }] in the picture's own pixels. Pure, so it can be tested. */
export function decodeYunet(out, W, H, { threshold = 0.6, nms = 0.3 } = {}) {
  const boxes = [];
  [8, 16, 32].forEach((stride) => {
    const cls = out[`cls_${stride}`], obj = out[`obj_${stride}`], bb = out[`bbox_${stride}`];
    const cols = Math.floor(W / stride), rows = Math.floor(H / stride);
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      const k = r * cols + c;
      const sc = Math.sqrt(Math.min(1, Math.max(0, cls[k])) * Math.min(1, Math.max(0, obj[k])));
      if (sc < threshold) continue;
      const cx = (c + bb[k * 4]) * stride, cy = (r + bb[k * 4 + 1]) * stride, w = Math.exp(bb[k * 4 + 2]) * stride, h = Math.exp(bb[k * 4 + 3]) * stride;
      boxes.push({ x: cx - w / 2, y: cy - h / 2, w, h, score: sc });
    }
  });
  boxes.sort((a, b) => b.score - a.score);
  const keep = [];
  const iou = (a, b) => { const x1 = Math.max(a.x, b.x), y1 = Math.max(a.y, b.y), x2 = Math.min(a.x + a.w, b.x + b.w), y2 = Math.min(a.y + a.h, b.y + b.h); const i = Math.max(0, x2 - x1) * Math.max(0, y2 - y1); return i / (a.w * a.h + b.w * b.h - i || 1); };
  for (const b of boxes) if (keep.every((k) => iou(k, b) < nms)) keep.push(b);
  return keep;
}
/** Faces in one raw RGB frame (width x height, 3 bytes a pixel). Sizes are rounded to a multiple of 32 by padding. */
export async function facesIn(s, rgb, width, height) {
  const { ort, session } = await yunet(s.yunet);
  const W = Math.ceil(width / 32) * 32, H = Math.ceil(height / 32) * 32;
  const data = new Float32Array(3 * H * W);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const p = (y * width + x) * 3, q = y * W + x;
    data[q] = rgb[p + 2]; data[H * W + q] = rgb[p + 1]; data[2 * H * W + q] = rgb[p]; // BGR, 0 to 255
  }
  const out = await session.run({ input: new ort.Tensor('float32', data, [1, 3, H, W]) });
  const flat = {}; for (const k of Object.keys(out)) flat[k] = out[k].data;
  return decodeYunet(flat, W, H).filter((f) => f.x + f.w / 2 < width && f.y + f.h / 2 < height);
}
/** Faces through a stretch of video, sampled twice a second: [{ t, faces }]. Frames are 640 wide. */
export async function facesOver(t, s, file, { start = 0, length = 10, fps = 2 } = {}) {
  if (!s.hasFace) return { ok: false, error: 'Face finding is not installed' };
  const W = 640;
  const r = await run(t.ffmpeg, ['-nostdin', '-v', 'error', '-ss', String(start), '-t', String(length), '-i', file, '-an', '-vf', `fps=${fps},scale=${W}:-2`, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], 5 * 60_000);
  if (!r.ok || !r.out.length) return { ok: false, error: 'Could not read frames' };
  const p = await run(t.ffprobe, ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0', file], 30_000);
  const [vw, vh] = String(p.out).trim().split(',').map(Number);
  if (!vw || !vh) return { ok: false, error: 'Could not read the size' };
  const H = Math.round((W * vh) / vw / 2) * 2, size = W * H * 3, n = Math.floor(r.out.length / size);
  const frames = [];
  for (let i = 0; i < n; i++) frames.push({ t: i / fps, faces: (await facesIn(s, r.out.subarray(i * size, (i + 1) * size), W, H)).map((f) => ({ x: f.x / W, y: f.y / H, w: f.w / W, h: f.h / H, score: Math.round(f.score * 100) / 100 })) });
  return { ok: true, frames };
}
/** The face to build the layout on: the biggest steady face (a webcam), as the fraction of the picture. Null when none. */
export function mainFace(frames) {
  const seen = frames.filter((f) => f.faces.length);
  if (seen.length < Math.max(2, frames.length * 0.4)) return null;
  const best = seen.map((f) => [...f.faces].sort((a, b) => b.w * b.h - a.w * a.h)[0]);
  const med = (k) => [...best].map((b) => b[k]).sort((a, b) => a - b)[Math.floor(best.length / 2)];
  return { x: med('x'), y: med('y'), w: med('w'), h: med('h'), seen: seen.length / frames.length, first: seen[0].t };
}

// ---------------- Chat ----------------
/** Twitch chat, read only, with no sign-in. Counts messages; ask `rate(seconds)` for messages per second. */
export function twitchChat(handle, { WS = globalThis.WebSocket, url = 'wss://irc-ws.chat.twitch.tv:443' } = {}) {
  const stamps = [];
  let ws = null, closed = false, timer = null;
  const connect = () => {
    if (closed) return;
    try { ws = new WS(url); } catch { return; }
    ws.onopen = () => { ws.send('PASS SCHMOOPIIE'); ws.send(`NICK justinfan${Math.floor(10000 + Math.random() * 80000)}`); ws.send(`JOIN #${String(handle).toLowerCase()}`); };
    ws.onmessage = (e) => {
      for (const line of String(e.data).split('\r\n')) {
        if (line.startsWith('PING')) ws.send('PONG :tmi.twitch.tv');
        else if (/ PRIVMSG #/.test(line)) { stamps.push(Date.now()); if (stamps.length > 20000) stamps.splice(0, 5000); }
      }
    };
    ws.onclose = () => { if (!closed) timer = setTimeout(connect, 5000); };
    ws.onerror = () => { try { ws.close(); } catch { /* closed */ } };
  };
  connect();
  return {
    stamps,
    /** messages in each whole second between two times (ms): an array, one per second */
    perSecond(fromMs, toMs) { const n = Math.max(1, Math.floor((toMs - fromMs) / 1000)); const a = new Array(n).fill(0); for (const t of stamps) if (t >= fromMs && t < toMs) a[Math.min(n - 1, Math.floor((t - fromMs) / 1000))]++; return a; },
    close() { closed = true; clearTimeout(timer); try { ws?.close(); } catch { /* closed */ } }
  };
}
