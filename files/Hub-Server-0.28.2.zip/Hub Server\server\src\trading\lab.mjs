// Trading lab, the PC server's side (plans/trading-lab/PLAN.md). Each account has its own lab: its own free Tiingo key
// (Tiingo's free licence is for one person's own use, so one account's prices are never shown to another), its own
// prices, strategies and locked records, in HUB\Trading Lab\<account>. Long work runs as jobs (jobs.mjs) so it waits
// while the PC is off and catches up:
//   lab-fetch   daily prices from Tiingo for the account's symbols, inside the free limits (50 an hour, 1,000 a day,
//               500 symbols a month); past a limit it waits and carries on by itself.
//   lab-phase1  the Phase 1 run in Python (tools/trading-lab, vectorbt and Backtrader), its progress read line by line.
// A dry run uses made-up prices (no key needed), in its own folder, and every screen says so.
import { spawn as nodeSpawn } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync, rmSync, statSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const LAB_CODE = resolve(HERE, '..', '..', '..', 'tools', 'trading-lab');
/** Broad funds first: they rarely disappear, so leaving out delisted companies matters little (see the plan) */
export const DEFAULT_UNIVERSE = ['SPY', 'QQQ', 'IWM', 'DIA', 'XLK', 'XLF', 'XLE', 'XLV', 'XLY', 'XLP', 'XLI', 'XLU', 'XLB', 'TLT'];
export const TIINGO_LIMITS = { hour: 50, day: 1000, month: 500 };
const TIINGO = 'https://api.tiingo.com';

export function lab(ctx, impl = {}) {
  const { db, cfg, jobs } = ctx;
  const root = impl.dir ?? cfg.tradingLab?.dir ?? resolve(cfg.dataDir, '..', 'Trading Lab');
  const python = () => impl.python ?? cfg.tradingLab?.python ?? resolve(cfg.dataDir, '..', 'Tools', 'trading-lab', 'venv', 'Scripts', 'python.exe');
  const doFetch = impl.fetch ?? fetch;
  const spawn = impl.spawn ?? nodeSpawn;
  const keysDir = () => cfg.keysDir || resolve(cfg.dataDir, '..', 'Keys');
  const safe = (id) => String(id).replace(/[^\w-]/g, '');
  const dirOf = (uid, ...p) => join(root, safe(uid), ...p);
  const keyFile = (uid) => join(keysDir(), `tiingo-${safe(uid)}.json`);
  const readKey = (uid) => { try { const f = keyFile(uid); return existsSync(f) ? JSON.parse(db.keys ? db.keys.readSecret(f) : readFileSync(f, 'utf8')).key : null; } catch { return null; } };
  const writeKey = (uid, key) => { mkdirSync(keysDir(), { recursive: true }); const s = JSON.stringify({ key }); if (db.keys) db.keys.writeSecret(keyFile(uid), s); else writeFileSync(keyFile(uid), s, { mode: 0o600 }); };
  const readJson = (f, d) => { try { return JSON.parse(readFileSync(f, 'utf8')); } catch { return d; } };
  const children = new Set();

  // ---- Tiingo's free limits, counted per account (each account has its own key) ----
  function use(uid) {
    const u = readJson(dirOf(uid, 'tiingo-use.json'), { calls: [], month: '', symbols: [] });
    const now = Date.now(), m = new Date(now).toISOString().slice(0, 7);
    u.calls = u.calls.filter((t) => now - t < 86_400_000);
    if (u.month !== m) { u.month = m; u.symbols = []; }
    return u;
  }
  const saveUse = (uid, u) => { mkdirSync(dirOf(uid), { recursive: true }); writeFileSync(dirOf(uid, 'tiingo-use.json'), JSON.stringify(u)); };
  /** How long to wait before the next call is allowed (0: now) */
  function waitFor(u, sym) {
    const now = Date.now(), hour = u.calls.filter((t) => now - t < 3_600_000);
    if (!u.symbols.includes(sym) && u.symbols.length >= TIINGO_LIMITS.month - 5) return { ms: 86_400_000, why: 'Tiingo\'s free 500 symbols this month are used up: carrying on next month' };
    if (u.calls.length >= TIINGO_LIMITS.day - 10) return { ms: Math.max(60_000, u.calls[0] + 86_400_000 - now), why: 'Tiingo\'s free 1,000 calls a day are used: carrying on tomorrow' };
    if (hour.length >= TIINGO_LIMITS.hour - 2) return { ms: Math.max(60_000, hour[0] + 3_600_000 - now), why: 'Tiingo\'s free 50 calls an hour are used: carrying on in under an hour' };
    return { ms: 0 };
  }

  const csv = (rows) => 'date,open,high,low,close,volume\n' + rows.map((r) => [String(r.date).slice(0, 10), r.adjOpen, r.adjHigh, r.adjLow, r.adjClose, r.adjVolume ?? r.volume].join(',')).join('\n') + '\n';

  jobs.on('lab-fetch', async (job, ctl) => {
    const uid = job.account, key = readKey(uid);
    if (!key) throw new Error('No Tiingo key for this account: add it in Trading > Lab');
    const want = job.args.universe ?? DEFAULT_UNIVERSE, have = new Set(job.progress?.fetched ?? []);
    mkdirSync(dirOf(uid, 'bars'), { recursive: true });
    for (const sym of want) {
      if (have.has(sym)) continue;
      // fetched in the last 18 hours: daily prices haven't changed, so the free allowance isn't spent again
      try { if (Date.now() - statSync(dirOf(uid, 'bars', `${sym}.csv`)).mtimeMs < 18 * 3_600_000) { have.add(sym); continue; } } catch { /* not fetched yet */ }
      if (ctl.cancelled()) return { done: true, note: 'Cancelled' };
      const u = use(uid), w = waitFor(u, sym);
      if (w.ms) { ctl.progress({ stage: 'Waiting for Tiingo', note: w.why }); return { wait: w.ms, note: w.why }; }
      u.calls.push(Date.now()); if (!u.symbols.includes(sym)) u.symbols.push(sym); saveUse(uid, u);
      const r = await doFetch(`${TIINGO}/tiingo/daily/${encodeURIComponent(sym.toLowerCase())}/prices?startDate=1990-01-01&format=json`, { headers: { authorization: `Token ${key}`, 'content-type': 'application/json' } });
      if (r.status === 429) return { wait: 3_600_000, note: 'Tiingo asked to slow down: carrying on in an hour' };
      if (r.status === 401 || r.status === 403) throw new Error('Tiingo refused the key: check it in Trading > Lab');
      const rows = await r.json().catch(() => null);
      if (!r.ok || !Array.isArray(rows)) throw new Error(`Tiingo had no prices for ${sym} (${r.status})`);
      const good = rows.filter((x) => x && x.date && [x.adjOpen, x.adjHigh, x.adjLow, x.adjClose].every((v) => Number.isFinite(v) && v > 0));
      if (good.length < 300) { have.add(sym); ctl.progress({ fetched: [...have], skipped: [...(job.progress?.skipped ?? []), sym] }); continue; }
      writeFileSync(dirOf(uid, 'bars', `${sym}.csv`), csv(good));
      have.add(sym);
      ctl.progress({ stage: 'Fetching prices', done: have.size, total: want.length, fetched: [...have], note: `${sym}: ${good.length} days from ${String(good[0].date).slice(0, 10)}` });
    }
    writeFileSync(dirOf(uid, 'bars', 'source.json'), JSON.stringify({ source: 'Tiingo (free, personal use)', at: Date.now(), symbols: want }));
    return { done: true, note: `Prices for ${have.size} symbols` };
  });

  jobs.on('lab-phase1', (job, ctl) => new Promise((done, fail) => {
    const uid = job.account, dry = !!job.args.dry, py = python();
    if (!existsSync(py)) return fail(new Error('The trading lab is not set up on this PC: double-click tools\\trading\\Set up Trading Lab.cmd'));
    const base = dirOf(uid, dry ? 'dry' : 'live');
    if (dry) rmSync(join(base, 'bars'), { recursive: true, force: true });
    const args = ['-m', 'lab.phase1', '--home', join(base, 'home'), '--bars', dry ? join(base, 'bars') : dirOf(uid, 'bars')];
    if (dry) args.push('--made-up'); else args.push('--source', 'Tiingo (free, personal use)', '--universe', (job.args.universe ?? DEFAULT_UNIVERSE).join(','));
    mkdirSync(base, { recursive: true });
    const p = spawn(py, args, { cwd: LAB_CODE, windowsHide: true, env: { ...process.env, PYTHONUNBUFFERED: '1', PYTHONIOENCODING: 'utf-8' } });
    children.add(p);
    let buf = '', last = null, err = '';
    p.stdout.on('data', (d) => {
      buf += d; let i;
      while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); try { last = JSON.parse(line); ctl.progress({ stage: last.stage, done: last.done ?? null, total: last.total ?? null, note: last.error ?? '' }); } catch { /* not a progress line */ } }
    });
    p.stderr.on('data', (d) => { err = (err + d).slice(-4000); });
    p.on('error', (e) => { children.delete(p); fail(e); });
    p.on('close', (code) => {
      children.delete(p);
      if (code === 0 && last?.ok) done({ done: true, note: `Run ${last.run}: ${last.passed} of ${last.tested} passed`, result: { run: last.run, dry } });
      else fail(new Error(last?.error || err.split('\n').filter(Boolean).slice(-2).join(' ') || `The lab stopped (code ${code})`));
    });
  }));

  // ---- what the app sees ----
  function runs(uid, dry) {
    const home = dirOf(uid, dry ? 'dry' : 'live', 'home', 'runs');
    if (!existsSync(home)) return [];
    return readdirSync(home).sort().reverse().map((id) => {
      const rec = readJson(join(home, id, 'record.json'), null);
      if (!rec) return null; // (a run that never finished has no record)
      const best = rec.strategies.filter((s) => s.verdict === 'passed').sort((a, b) => b.hidden.sharpe - a.hidden.sharpe).slice(0, 5)
        .map((s) => ({ id: s.id, family: s.family, hidden: { sharpe: s.hidden.sharpe, ret: s.hidden.ret, maxdd: s.hidden.maxdd, trades: s.hidden.trades }, inSample: { sharpe: s.in_sample.sharpe, ret: s.in_sample.ret } }));
      const bh = Object.values(rec.buy_hold_hidden ?? {});
      return { run: rec.run, dry, finished: rec.finished, seconds: rec.seconds, source: rec.source, label: rec.label, universe: rec.universe, split: rec.split, costs: rec.costs, counts: rec.counts, canary: rec.canary, reused: rec.hidden_year_reused, buyHold: bh.length ? bh.reduce((a, b) => a + b, 0) / bh.length : null, best };
    }).filter(Boolean).slice(0, 30);
  }
  function view(uid) {
    const src = readJson(dirOf(uid, 'bars', 'source.json'), null), u = use(uid);
    const bars = existsSync(dirOf(uid, 'bars')) ? readdirSync(dirOf(uid, 'bars')).filter((f) => f.endsWith('.csv')).map((f) => f.replace(/\.csv$/, '')) : [];
    return {
      key: !!readKey(uid), python: existsSync(python()), universe: DEFAULT_UNIVERSE, prices: { symbols: bars, source: src?.source ?? null, at: src?.at ?? null },
      tiingo: { lastHour: u.calls.filter((t) => Date.now() - t < 3_600_000).length, today: u.calls.length, symbolsThisMonth: u.symbols.length, limits: TIINGO_LIMITS },
      jobs: jobs.list(uid).filter((j) => j.kind.startsWith('lab-')).slice(-12).reverse().map((j) => ({ id: j.id, kind: j.kind, label: j.label, state: j.state, note: j.note, progress: j.progress ? { stage: j.progress.stage, done: j.progress.done, total: j.progress.total, note: j.progress.note } : null, at: j.at, end: j.end ?? null, until: j.until ?? null, dry: !!j.args?.dry })),
      runs: [...runs(uid, false), ...runs(uid, true)].sort((a, b) => String(b.finished).localeCompare(String(a.finished)))
    };
  }
  const signedIn = (u) => (u && !u.disabled ? null : [403, { error: 'Sign in first' }]);
  const home = (meta) => (meta?.public ? [403, { error: 'Do this at home, on the home Wi-Fi or the PC itself: keys never travel over the internet', code: 'home' }] : null);

  const routes = {
    'GET /api/trading/lab': (b, u) => signedIn(u) ?? [200, view(u.id)],
    // the account's own free Tiingo key: checked with Tiingo, kept encrypted in the Keys folder, never sent back
    'POST /api/trading/lab/key': async (b, u, meta) => {
      const no = signedIn(u) ?? home(meta); if (no) return no;
      const key = String(b.key ?? '').trim();
      if (!/^[A-Za-z0-9]{20,64}$/.test(key)) return [400, { error: 'That does not look like a Tiingo key (letters and numbers, from tiingo.com > Account > API)', field: 'key' }];
      const r = await doFetch(`${TIINGO}/api/test`, { headers: { authorization: `Token ${key}`, 'content-type': 'application/json' } }).catch(() => null);
      if (!r || !r.ok) return [400, { error: r ? 'Tiingo did not accept that key. Copy it again from tiingo.com > Account > API' : 'Could not reach Tiingo: is the PC online?', field: 'key' }];
      writeKey(u.id, key);
      ctx.log?.(`${ctx.stamp?.() ?? ''} Trading lab: ${u.name} saved a Tiingo key (kept in the Keys folder)`);
      return [200, view(u.id)];
    },
    'POST /api/trading/lab/key/remove': (b, u, meta) => { const no = signedIn(u) ?? home(meta); if (no) return no; rmSync(keyFile(u.id), { force: true }); return [200, view(u.id)]; },
    // a run: fetch the prices (if not fetched today), then Phase 1. dry: made-up prices, no key needed.
    'POST /api/trading/lab/run': (b, u) => {
      const no = signedIn(u); if (no) return no;
      if (jobs.list(u.id).some((j) => j.kind.startsWith('lab-') && ['queued', 'running', 'waiting'].includes(j.state))) return [409, { error: 'A run is already going: wait for it, or cancel it' }];
      if (b.dry) { jobs.add('lab-phase1', u.id, { dry: true }, { label: 'Dry run (made-up prices)' }); return [200, view(u.id)]; }
      if (!readKey(u.id)) return [400, { error: 'Add your free Tiingo key in Trading > Lab first' }];
      const universe = DEFAULT_UNIVERSE;
      const f = jobs.add('lab-fetch', u.id, { universe }, { label: 'Fetch prices from Tiingo' });
      jobs.add('lab-phase1', u.id, { universe }, { after: f.id, label: 'Phase 1 run' });
      return [200, view(u.id)];
    },
    'POST /api/trading/lab/cancel': (b, u) => {
      const no = signedIn(u); if (no) return no;
      const j = jobs.get(String(b.id)); if (!j || j.account !== u.id) return [404, { error: 'That job is gone' }];
      jobs.cancel(j.id, u.id);
      if (jobs.busy()?.id === j.id) for (const c of children) c.kill();
      return [200, view(u.id)];
    },
    // one run's full locked record, or its report page
    'GET /api/trading/lab/record': (b, u, meta) => {
      const no = signedIn(u); if (no) return no;
      const id = safe(meta?.q?.get('run') ?? ''), dry = meta?.q?.get('dry') === '1';
      const f = dirOf(u.id, dry ? 'dry' : 'live', 'home', 'runs', id, meta?.q?.get('as') === 'html' ? 'report.html' : 'record.json');
      if (!id || !existsSync(f)) return [404, { error: 'That run is gone' }];
      return [200, meta?.q?.get('as') === 'html' ? { html: readFileSync(f, 'utf8') } : JSON.parse(readFileSync(f, 'utf8'))];
    }
  };
  return { routes, view, stop() { for (const c of children) c.kill(); }, root };
}
