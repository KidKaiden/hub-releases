// Hub > AI: the chat that can act across the apps (Hub upgrade, 2026-11-11).
//
// How it's split, so nothing important leaves the person's device:
//  - The apps' data stays on the device. The app (apps/hub/src/pages/Ai.svelte) sends the conversation and the list of
//    actions it allows (each app's manifest `actions`, marked read or change). This server only passes that to Claude
//    and hands Claude's answer back. When Claude asks for an action, the DEVICE runs it: reads straight away, changes
//    only after the person presses Do it (or allowed it), each with Undo.
//  - The Anthropic API key lives only on this PC: typed by the owner in Hub > Settings > AI, from home (never through
//    the outside link), kept in the Keys folder beside the project (never in git, never sent back, never logged).
//  - Who can use it: the owner, and (if the owner allows) people with unlimited space. It costs the owner money, so
//    each person has a limit per hour.
import Anthropic from '@anthropic-ai/sdk';
import { existsSync, readFileSync, writeFileSync, mkdirSync, unlinkSync } from 'node:fs';
import { resolve, join } from 'node:path';

export const MODELS = ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-5-5'];
const EFFORTS = ['low', 'medium', 'high'];
const PER_HOUR = 120;
const SYSTEM = `You are the AI inside Hub, a family's own set of apps (To Do, Notes, Finance, Messages, Trading and more).
You help the person get things done in their apps through the tools you're given. Each tool belongs to one app.
- Read tools run at once. Change tools are shown to the person, who presses "Do it" or "Skip"; if they skip, accept it.
- Only use a tool when it helps with what they asked. Look things up (list or find) before changing something by id.
- When they want something kept (a summary, a plan, a list from this chat), save it with the Notes tool.
- Money: you can read numbers; you never move money or place trades. Trading orders only ever go to the person's
  approval queue, and the server's own limits decide what is allowed.
- Write in short, plain British English. No jargon. Say plainly when you're guessing.`;

export function ai(ctx) {
  const { db, cfg, log, stamp } = ctx;
  db.data.settings.ai ??= { model: MODELS[0], effort: 'low', who: 'owner', allowChanges: false };
  const set = () => db.data.settings.ai;
  const keysDir = () => cfg.keysDir || resolve(cfg.dataDir, '..', 'Keys');
  const keyFile = () => join(keysDir(), 'anthropic-api.key');
  const readKey = () => { try { return cfg.ai?.key || (existsSync(keyFile()) ? readFileSync(keyFile(), 'utf8').trim() : ''); } catch { return ''; } };
  const isAdmin = (u) => !!db.data.roles?.[u.role]?.admin;
  const allowed = (u) => isAdmin(u) || (set().who === 'unlimited' && !!ctx.space?.unlimited(u));
  let client = null, clientKey = '';
  const api = () => {
    const k = readKey();
    if (!k) return null;
    if (!client || k !== clientKey) { client = new Anthropic({ apiKey: k, baseURL: cfg.ai?.base || undefined, maxRetries: 2, timeout: 120_000 }); clientKey = k; }
    return client;
  };
  const uses = new Map(); // account id -> times this hour
  const tooMany = (id) => { const now = Date.now(); const t = (uses.get(id) ?? []).filter((x) => now - x < 3600_000); t.push(now); uses.set(id, t); return t.length > PER_HOUR; };

  // What the device may send: a list of tools (from the apps' manifests) and the conversation so far
  function checkTools(tools) {
    if (!Array.isArray(tools) || tools.length > 80) return null;
    const out = [];
    for (const t of tools) {
      if (!t || typeof t.name !== 'string' || !/^[a-zA-Z0-9_-]{1,64}$/.test(t.name)) return null;
      if (typeof t.description !== 'string' || t.description.length > 2000) return null;
      if (!t.input_schema || t.input_schema.type !== 'object' || JSON.stringify(t.input_schema).length > 8000) return null;
      out.push({ name: t.name, description: t.description, input_schema: t.input_schema });
    }
    return out;
  }
  function checkMessages(m) {
    if (!Array.isArray(m) || !m.length || m.length > 300) return null;
    for (const x of m) if (!x || !['user', 'assistant'].includes(x.role) || (typeof x.content !== 'string' && !Array.isArray(x.content))) return null;
    if (m[0].role !== 'user') return null;
    return m;
  }
  const status = (u) => ({ ready: !!readKey(), allowed: allowed(u), owner: isAdmin(u), model: set().model, effort: set().effort, who: set().who, allowChanges: !!set().allowChanges, models: MODELS });

  const routes = {
    'GET /api/ai/status': (_b, u) => [200, status(u)],
    // The owner's settings: which model, how hard it thinks, who may use it
    'POST /api/ai/settings': (b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      const s = set();
      if (MODELS.includes(b.model)) s.model = b.model;
      if (EFFORTS.includes(b.effort)) s.effort = b.effort;
      if (b.who === 'owner' || b.who === 'unlimited') s.who = b.who;
      if (typeof b.allowChanges === 'boolean') s.allowChanges = b.allowChanges;
      db.save();
      return [200, status(u)];
    },
    // The key: typed by the owner at home. Written to the Keys folder; only "set or not" ever comes back.
    'POST /api/ai/key': (b, u, meta) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      if (meta?.public) return [403, { error: 'Do this at home, on the home Wi-Fi or the PC itself: the key never travels over the internet', code: 'home' }];
      const k = String(b.key ?? '').trim();
      if (!/^sk-ant-[A-Za-z0-9_-]{20,300}$/.test(k)) return [400, { error: "That doesn't look like an Anthropic API key (it starts with sk-ant-)" }];
      mkdirSync(keysDir(), { recursive: true });
      writeFileSync(keyFile(), k + '\n', { mode: 0o600 });
      client = null;
      log(`${stamp()} AI: key set by ${u.name} (kept in the Keys folder)`);
      return [200, status(u)];
    },
    'POST /api/ai/key/remove': (_b, u, meta) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      if (meta?.public) return [403, { error: 'Do this at home', code: 'home' }];
      try { if (existsSync(keyFile())) unlinkSync(keyFile()); } catch { /* already gone */ }
      client = null;
      log(`${stamp()} AI: key removed by ${u.name}`);
      return [200, status(u)];
    },
    // Check the key works, with the smallest possible question
    'POST /api/ai/test': async (_b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      const c = api();
      if (!c) return [200, { ok: false, error: 'No key yet' }];
      try {
        const r = await c.messages.create({ model: set().model, max_tokens: 64, output_config: { effort: 'low' }, messages: [{ role: 'user', content: 'Say OK.' }] });
        return [200, { ok: true, model: r.model }];
      } catch (e) { return [200, { ok: false, error: words(e) }]; }
    },
    // One turn: the conversation and the allowed actions go to Claude; its answer comes back for the device to show
    // (and to run any action it asked for). Nothing of the chat is kept on the server.
    'POST /api/ai/chat': async (b, u) => {
      if (!allowed(u)) return [403, { error: 'The AI is only for the owner here. Ask them if you need it', code: 'notallowed' }];
      const c = api();
      if (!c) return [503, { error: 'The AI needs its key first: the owner adds it in Hub > Settings > AI', code: 'nokey' }];
      const tools = checkTools(b.tools ?? []);
      const messages = checkMessages(b.messages);
      if (!tools || !messages) return [400, { error: "The chat couldn't be sent. Start a new chat" }];
      if (tooMany(u.id)) return [429, { error: 'That is a lot of questions for one hour. Try again a bit later', code: 'slow' }];
      const about = `Today is ${new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Europe/London' })}. You're talking with ${String(u.name).slice(0, 60)}.`;
      try {
        const r = await c.beta.messages.create({
          model: set().model,
          max_tokens: 16000,
          betas: ['server-side-fallback-2026-07-01'],
          fallbacks: 'default',
          output_config: { effort: set().effort },
          system: [{ type: 'text', text: SYSTEM, cache_control: { type: 'ephemeral' } }, { type: 'text', text: about }],
          tools,
          messages
        });
        ctx.sync?.note?.(u, { kind: 'ai' });
        return [200, { content: r.content, stop_reason: r.stop_reason, model: r.model, usage: { in: r.usage?.input_tokens ?? 0, out: r.usage?.output_tokens ?? 0 } }];
      } catch (e) {
        log(`${stamp()} AI: a question from ${u.name} failed (${e?.status ?? 'no answer'})`);
        return [e?.status === 429 ? 429 : 502, { error: words(e), code: 'api' }];
      }
    }
  };
  return { routes };
}

// The API's errors in plain words (never the key, never the request)
function words(e) {
  if (e instanceof Anthropic.AuthenticationError) return 'The key was turned down. Check it in your Anthropic account and add it again';
  if (e instanceof Anthropic.PermissionDeniedError) return "The key isn't allowed to use this model";
  if (e instanceof Anthropic.RateLimitError) return 'Anthropic says slow down a moment. Try again in a minute';
  if (e instanceof Anthropic.BadRequestError) return /credit|billing/i.test(String(e.message)) ? 'Your Anthropic account needs credit (Plans and billing)' : "Anthropic couldn't read that chat. Start a new chat";
  if (e instanceof Anthropic.InternalServerError) return 'Anthropic is busy right now. Try again in a minute';
  if (e instanceof Anthropic.APIConnectionError) return "This PC couldn't reach Anthropic. Check the internet";
  return 'Something went wrong asking the AI. Try again';
}
