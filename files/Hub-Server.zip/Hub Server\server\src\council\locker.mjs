// The prediction locker: an append-only file. Each line is one locked entry (a prediction, or a score of one) with the
// time it was locked, the hash of its content and the previous line's hash, so nothing can be changed or taken out
// without verify() finding it. There is no way to edit or remove an entry: only to add one. Imports nothing but Node.
import { createHash } from 'node:crypto';
import { appendFileSync, chmodSync, existsSync, mkdirSync, readFileSync } from 'node:fs';
import { dirname } from 'node:path';

const sha = (s) => createHash('sha256').update(s).digest('hex');
const canon = (o) => JSON.stringify(o, Object.keys(o).sort());

export function locker(file, now = () => Date.now()) {
  const read = () => (existsSync(file) ? readFileSync(file, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)) : []);
  return {
    /** Lock an entry. Returns it with its id (its hash). The content is frozen: the returned object cannot be changed either. */
    add(kind, content) {
      const all = read(), prev = all.at(-1)?.hash ?? null;
      const entry = { kind, at: new Date(now()).toISOString(), content, prev };
      entry.hash = sha(canon({ kind: entry.kind, at: entry.at, content: JSON.stringify(content), prev }));
      mkdirSync(dirname(file), { recursive: true });
      try { chmodSync(file, 0o666); } catch { /* first entry */ }
      appendFileSync(file, JSON.stringify(entry) + '\n');
      try { chmodSync(file, 0o444); } catch { /* read-only where the system allows */ }
      return Object.freeze({ ...entry, content: deepFreeze(structuredClone(content)) });
    },
    list: (kind) => read().filter((e) => !kind || e.kind === kind).map((e) => deepFreeze(e)),
    get: (hash) => { const e = read().find((x) => x.hash === hash); return e ? deepFreeze(e) : null; },
    /** Every line's hash recomputed and every link checked */
    verify() {
      let prev = null, n = 0;
      for (const e of read()) {
        n++;
        if (e.prev !== prev) return { ok: false, entries: n, why: `entry ${n} does not follow the one before` };
        if (sha(canon({ kind: e.kind, at: e.at, content: JSON.stringify(e.content), prev: e.prev })) !== e.hash) return { ok: false, entries: n, why: `entry ${n} was changed after it was locked` };
        prev = e.hash;
      }
      return { ok: true, entries: n };
    },
    edit() { throw new Error('A locked prediction can never be changed: add a new one instead'); },
    remove() { throw new Error('A locked prediction can never be removed'); }
  };
}
function deepFreeze(o) { if (o && typeof o === 'object') { for (const v of Object.values(o)) deepFreeze(v); Object.freeze(o); } return o; }
