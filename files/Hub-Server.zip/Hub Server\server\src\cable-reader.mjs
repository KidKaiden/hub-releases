// Cable's reader: opens a streaming website in the PC's own Edge (headless, so the site draws itself exactly as it does for
// you, scripts and all), and reads what is on the page: its big banner and its rows of posters with their titles, which
// are the site's own recommendations. The same reader works for any such site; nothing is made up and nothing comes from
// a movie database. It also types a search into the site's own search box and reads the results.
// Safety (the server is on your home network): only web addresses that resolve to public computers are ever opened,
// downloads are refused, and a site gets no camera, microphone, location or notifications.
import dns from 'node:dns/promises';
import net from 'node:net';
import { existsSync } from 'node:fs';
import { chromium } from 'playwright-core';

const EDGE = [
  process.env.CABLE_BROWSER,
  process.env['ProgramFiles(x86)'] && `${process.env['ProgramFiles(x86)']}\\Microsoft\\Edge\\Application\\msedge.exe`,
  process.env.ProgramFiles && `${process.env.ProgramFiles}\\Microsoft\\Edge\\Application\\msedge.exe`,
  process.env.ProgramFiles && `${process.env.ProgramFiles}\\Google\\Chrome\\Application\\chrome.exe`,
  '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
].filter(Boolean);
export const browserPath = () => EDGE.find((p) => existsSync(p)) ?? '';

// ---------------- Which addresses may be opened ----------------
export function privateIp(ip) {
  const a = String(ip).replace(/^::ffff:/i, '');
  if (net.isIPv4(a)) {
    const [x, y] = a.split('.').map(Number);
    return x === 10 || x === 127 || x === 0 || (x === 169 && y === 254) || (x === 172 && y >= 16 && y <= 31) || (x === 192 && y === 168) || (x === 100 && y >= 64 && y <= 127) || x >= 224;
  }
  if (net.isIPv6(a)) { const l = a.toLowerCase(); return l === '::1' || l === '::' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe8') || l.startsWith('fe9') || l.startsWith('fea') || l.startsWith('feb'); }
  return true;
}
const known = new Map(); // host -> { ok, at }
export async function publicHost(host, lookup = dns.lookup) {
  const h = String(host).replace(/^\[|\]$/g, '').toLowerCase();
  if (!h || h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal')) return false;
  if (net.isIP(h)) return !privateIp(h);
  const c = known.get(h);
  if (c && Date.now() - c.at < 5 * 60_000) return c.ok;
  let ok = false;
  try { const r = await lookup(h, { all: true }); ok = r.length > 0 && r.every((x) => !privateIp(x.address)); } catch { ok = false; }
  known.set(h, { ok, at: Date.now() });
  return ok;
}
/** A web address the owner may add: http or https, no user name or password, a public computer */
export async function checkUrl(raw, lookup) {
  let u;
  try { u = new URL(String(raw).trim().includes('://') ? String(raw).trim() : `https://${String(raw).trim()}`); } catch { return { ok: false, error: 'That is not a web address' }; }
  if (!/^https?:$/.test(u.protocol)) return { ok: false, error: 'Only http and https addresses work' };
  if (u.username || u.password) return { ok: false, error: 'Leave the user name and password out of the address' };
  if (!(await publicHost(u.hostname, lookup))) return { ok: false, error: "That address isn't a public website (Cable never opens computers on your own network)" };
  u.hash = '';
  return { ok: true, url: u.href };
}

// Ad and tracker hosts: not loaded while reading (faster, and no pop-up chains)
const ADS = ['doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'adservice.google.com', 'taboola.com', 'outbrain.com', 'popads.net', 'propellerads.com', 'adsterra.com', 'exoclick.com', 'juicyads.com', 'trafficjunky.com', 'adnxs.com', 'rubiconproject.com', 'pubmatic.com', 'openx.net', 'criteo.com', 'scorecardresearch.com', 'hotjar.com', 'mgid.com', 'revcontent.com', 'onclickads.net', 'popcash.net', 'clickadu.com', 'hilltopads.net', 'smartadserver.com', 'amazon-adsystem.com', 'moatads.com', 'adsafeprotected.com', 'yieldmo.com'];
export const isAdHost = (h) => ADS.some((d) => h === d || h.endsWith(`.${d}`));

// ---------------- The page reader (runs inside the page) ----------------
/* eslint-disable */
// Collects the raw material: every link with a picture and a title, and every short bold line that could name a row.
// It looks inside web components too (some sites build their tiles in shadow roots). Positions are page positions, so
// the same card seen again after scrolling lands in the same place.
export function collectInPage() {
  const abs = (u) => { try { const x = new URL(u, location.href); return /^https?:$/.test(x.protocol) ? x.href : ''; } catch { return ''; } };
  const clean = (s) => String(s ?? '').replace(/\s+/g, ' ').trim();
  const JUNK = /^(watch|play|play now|watch now|more|see all|view all|learn more|sign in|log in|login|menu|next|previous|prev|close|home|search|ad|advertisement|skip|continue|share|trailer|subscribe|get started|show more|more info|details|follow|like|add to list|my list)$/i;
  const sy = window.scrollY, sx = window.scrollX;
  const q = (sel) => { const out = []; const walk = (root) => { out.push(...root.querySelectorAll(sel)); for (const el of root.querySelectorAll('*')) if (el.shadowRoot) walk(el.shadowRoot); }; walk(document); return out; };
  const closestDeep = (el, sel) => { let n = el; while (n) { if (n.matches && n.matches(sel)) return n; n = n.parentElement || (n.getRootNode && n.getRootNode().host) || null; } return null; };
  const CHROME = 'nav, header, footer, [role=navigation], [role=banner], [role=contentinfo], [class*=cookie i], [id*=cookie i], [class*=consent i]';
  const bgOf = (el) => { const b = getComputedStyle(el).backgroundImage; const m = b && b !== 'none' ? b.match(/url\(["']?(.*?)["']?\)/) : null; return m ? m[1] : ''; };
  const imgSrc = (img) => {
    if (!img) return '';
    const ss = img.getAttribute('srcset') || img.getAttribute('data-srcset') || '';
    const first = ss ? ss.split(',').map((x) => x.trim().split(/\s+/)[0]).filter(Boolean).pop() : '';
    return abs(img.currentSrc || img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.getAttribute('data-original') || img.getAttribute('src') || first || '');
  };
  const deepIn = (el, sel) => { const r = [...el.querySelectorAll(sel)]; for (const c of el.querySelectorAll('*')) if (c.shadowRoot) r.push(...c.shadowRoot.querySelectorAll(sel)); return r; };
  const cards = []; const seen = new Set();
  for (const a of q('a[href]')) {
    const raw = a.getAttribute('href') || '';
    const href = abs(raw);
    if (!href || /^javascript:/i.test(raw) || href === location.href || seen.has(href)) continue;
    if (closestDeep(a, CHROME)) continue;
    const imgEl = deepIn(a, 'img')[0] || (a.shadowRoot ? a.shadowRoot.querySelector('img') : null);
    let src = imgSrc(imgEl), box = imgEl ? imgEl.getBoundingClientRect() : null;
    if (!src) { const el = [a, ...deepIn(a, '*')].find((e) => bgOf(e)); if (el) { src = abs(bgOf(el)); box = el.getBoundingClientRect(); } }
    if (!src || /^data:image\/(gif|svg)/.test(src)) continue;
    if (/(^|\/)(logo|sprite|icon)[^/]*\.(png|svg)/i.test(src) && !imgEl) continue;
    const r = a.getBoundingClientRect();
    const w = Math.max(r.width, box ? box.width : 0), h = Math.max(r.height, box ? box.height : 0);
    if (w < 70 || h < 60) continue;
    let title = clean(a.getAttribute('aria-label') || a.getAttribute('title') || (imgEl && imgEl.getAttribute('alt')) || '');
    if (!title || JUNK.test(title)) {
      const lines = (a.innerText || a.textContent || '').split('\n').map(clean).filter((x) => x && !JUNK.test(x) && x.length > 1);
      title = lines.sort((x, y) => y.length - x.length)[0] || '';
      if (title.length > 90) title = title.slice(0, 90).replace(/\s\S*$/, '');
    }
    if (!title || JUNK.test(title)) continue;
    seen.add(href);
    cards.push({ title, href, img: src, w: Math.round(r.width || w), h: Math.round(r.height || h), top: Math.round(r.top + sy), left: Math.round(r.left + sx) });
  }
  // short bold or large lines of text (row names, hero titles), not inside a card
  const heads = [];
  const scan = (root) => {
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = tw.nextNode())) {
      const t = clean(n.nodeValue);
      if (t.length < 2 || t.length > 60 || JUNK.test(t)) continue;
      const el = n.parentElement;
      if (!el || /^(SCRIPT|STYLE|NOSCRIPT|OPTION|BUTTON)$/.test(el.tagName)) continue;
      const card = closestDeep(el, 'a[href]');
      if (card && (deepIn(card, 'img').length || bgOf(card))) continue;
      if (closestDeep(el, CHROME)) continue;
      const cs = getComputedStyle(el), fs = parseFloat(cs.fontSize) || 0, wt = parseInt(cs.fontWeight) || 400;
      if (!(fs >= 15 || wt >= 600)) continue;
      const r = el.getBoundingClientRect();
      if (r.width < 8 || r.height < 8 || cs.visibility === 'hidden') continue;
      heads.push({ text: t, top: Math.round(r.top + sy), bottom: Math.round(r.bottom + sy), left: Math.round(r.left + sx), fs, wt });
    }
    for (const el of root.querySelectorAll('*')) if (el.shadowRoot) scan(el.shadowRoot);
  };
  scan(document.body || document);
  const icon = abs((document.querySelector('link[rel~=icon]') || {}).href || '/favicon.ico');
  return { vw: innerWidth, cards, heads, pageTitle: clean(document.title).slice(0, 120), icon };
}
/* eslint-enable */

/**
 * Turn what the passes collected into a banner and rows. Pure, so it is tested on saved pages (no browser needed).
 * passes: results of collectInPage taken at different scroll positions of the same page.
 */
export function assemble(passes) {
  const MAX_ROWS = 16, MAX_ITEMS = 30;
  const vw = Math.max(...passes.map((p) => p.vw || 0), 1);
  const byHref = new Map(); const headMap = new Map();
  for (const p of passes) {
    for (const c of p.cards) if (!byHref.has(c.href)) byHref.set(c.href, c);
    for (const h of p.heads) { const k = `${h.text}|${Math.round(h.top / 12)}`; if (!headMap.has(k)) headMap.set(k, h); }
  }
  const cards = [...byHref.values()];
  const heads = [...headMap.values()];
  // the banner: one very wide, tall picture near the top of the page
  const hc = cards.filter((c) => c.w >= vw * 0.55 && c.h >= 220 && c.top < 1400).sort((a, b) => a.top - b.top)[0];
  let hero = null;
  if (hc) {
    const inside = heads.filter((h) => h.top >= hc.top - 20 && h.bottom <= hc.top + hc.h + 40 && h.left >= hc.left - 10).sort((a, b) => b.fs - a.fs || a.top - b.top);
    const name = inside.find((h) => h.fs >= 22 && h.text.length < 70) ?? inside[0];
    hero = { title: name ? name.text : hc.title, href: hc.href, img: hc.img, about: '' };
  }
  const items = cards.filter((c) => c !== hc).sort((a, b) => a.top - b.top || a.left - b.left);
  const rows = [];
  for (const c of items) {
    const row = rows.find((r) => Math.abs(r.top - c.top) <= 14 && Math.abs(r.h - c.h) <= Math.max(24, r.h * 0.25));
    if (row) row.cards.push(c); else rows.push({ top: c.top, h: c.h, cards: [c] });
  }
  for (const r of rows) {
    r.cards.sort((a, b) => a.left - b.left);
    r.left = r.cards[0].left;
    const near = heads.filter((h) => h.bottom <= r.top + 8 && r.top - h.bottom <= 150 && Math.abs(h.left - r.left) <= 360 && !(hc && h.top >= hc.top - 20 && h.bottom <= hc.top + hc.h + 40)).sort((a, b) => b.bottom - a.bottom || b.fs - a.fs)[0];
    r.heading = near ? near.text : '';
  }
  rows.sort((a, b) => a.top - b.top);
  const joined = [];
  for (const r of rows) { // a grid is many lines; lines with no heading right after a line of the same size join it
    const prev = joined[joined.length - 1];
    if (!r.heading && prev && Math.abs(prev.h - r.h) <= 24 && r.top - prev.lastTop <= r.h + 90) { prev.cards.push(...r.cards); prev.lastTop = r.top; }
    else joined.push({ heading: r.heading, h: r.h, top: r.top, lastTop: r.top, cards: [...r.cards] });
  }
  const out = [];
  for (const r of joined) {
    const uniq = []; const names = new Set();
    for (const c of r.cards) { const k = c.title.toLowerCase(); if (names.has(k)) continue; names.add(k); uniq.push({ title: c.title, href: c.href, img: c.img, w: c.w, h: c.h }); if (uniq.length >= MAX_ITEMS) break; }
    if (uniq.length < (r.heading ? 2 : 4)) continue;
    const ratio = uniq.reduce((s, c) => s + c.h / Math.max(1, c.w), 0) / uniq.length;
    out.push({ title: r.heading, shape: ratio > 1.15 ? 'poster' : 'wide', items: uniq.map(({ w, h, ...x }) => x) });
    if (out.length >= MAX_ROWS) break;
  }
  return { pageTitle: passes[0].pageTitle, icon: passes[0].icon, hero, rows: out, cardCount: cards.length };
}

const settle = async (page, ms = 9000) => { await page.waitForLoadState('domcontentloaded', { timeout: ms }).catch(() => {}); await page.waitForLoadState('networkidle', { timeout: Math.min(ms, 7000) }).catch(() => {}); };
/** Scroll down the page in steps, collecting at each stop (lazy rows load as they come into view; some sites drop rows that scroll away) */
async function collectWhileScrolling(page, steps = 12) {
  const passes = [];
  const take = async () => { const r = await page.evaluate(collectInPage).catch(() => null); if (r) passes.push(r); };
  await take();
  for (let i = 1; i <= steps; i++) {
    const more = await page.evaluate(() => { const before = window.scrollY; window.scrollBy(0, Math.round(innerHeight * 0.85)); return window.scrollY > before; }).catch(() => false);
    await page.waitForTimeout(380);
    if (i % 2 === 0) await take();
    if (!more) break;
  }
  await take();
  await page.evaluate(() => window.scrollTo(0, 0)).catch(() => {});
  return passes;
}
/** Cookie and consent boxes get in the way of reading: say no to tracking (the privacy-friendly answer), else close them */
async function dismissBanners(page) {
  const NO = /^(no thanks|no, thanks|reject all|reject|decline|deny|only necessary|necessary only|use necessary cookies only|refuse|disagree|continue without accepting|not now)$/i;
  const YES = /^(accept all|accept|i agree|agree|got it|ok|okay|allow all|close)$/i;
  for (const re of [NO, YES]) {
    for (const b of await page.getByRole('button', { name: re }).all().catch(() => [])) {
      if (await b.isVisible().catch(() => false)) { await b.click({ timeout: 1500 }).catch(() => {}); await page.waitForTimeout(500); return true; }
    }
  }
  return false;
}
export function reader({ lookup, launch = (o) => chromium.launch(o), log = () => {} } = {}) {
  let browser = null, starting = null, idle = null, active = 0;
  const waiting = [];
  const MAX = 2;
  async function ensure() {
    if (browser?.isConnected()) return browser;
    if (starting) return starting;
    const p = browserPath();
    if (!p) throw new Error('No Edge or Chrome was found on this PC');
    starting = launch({ executablePath: p, headless: true, args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--mute-audio', '--autoplay-policy=user-gesture-required'] }).then((b) => { browser = b; b.on('disconnected', () => { browser = null; }); return b; }).finally(() => { starting = null; });
    return starting;
  }
  const touch = () => { clearTimeout(idle); idle = setTimeout(() => { if (!active) { browser?.close().catch(() => {}); browser = null; } else touch(); }, 4 * 60_000); idle.unref?.(); };
  const slot = () => new Promise((ok) => { const go = () => { active++; ok(() => { active--; waiting.shift()?.(); }); }; if (active < MAX) go(); else waiting.push(go); });

  /** A fresh, locked-down page: no downloads, no permissions, only public hosts, no ads or video files */
  async function page(b) {
    const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, locale: 'en-GB', acceptDownloads: false, permissions: [], serviceWorkers: 'block', ignoreHTTPSErrors: false });
    await ctx.route('**/*', async (route) => {
      const req = route.request();
      let host = '';
      try { host = new URL(req.url()).hostname; } catch { return route.abort(); }
      if (!/^https?:/.test(req.url()) && !/^(data|blob|about):/.test(req.url())) return route.abort();
      if (/^https?:/.test(req.url())) {
        if (isAdHost(host) || ['media', 'font'].includes(req.resourceType())) return route.abort();
        if (!(await publicHost(host, lookup))) return route.abort();
      }
      return route.continue();
    });
    const p = await ctx.newPage();
    p.on('popup', (x) => x.close().catch(() => {}));
    p.on('dialog', (d) => d.dismiss().catch(() => {}));
    return { p, ctx };
  }
  async function withPage(fn) {
    const release = await slot();
    let box = null;
    try { const b = await ensure(); touch(); box = await page(b); return await fn(box.p); }
    finally { await box?.ctx.close().catch(() => {}); release(); }
  }

  /** Read a site's front page: { pageTitle, icon, hero, rows } or { error } */
  async function read(url) {
    const c = await checkUrl(url, lookup);
    if (!c.ok) return { error: c.error };
    try {
      return await withPage(async (p) => {
        await p.goto(c.url, { waitUntil: 'domcontentloaded', timeout: 30_000 });
        await settle(p);
        await dismissBanners(p);
        const passes = await collectWhileScrolling(p);
        const r = assemble(passes.length ? passes : [{ vw: 1366, cards: [], heads: [], pageTitle: '', icon: '' }]);
        if (!r.rows.length && !r.hero) return { error: r.cardCount ? 'The site shows its titles in a way Cable cannot sort into rows yet' : "No posters or titles were found on that page. It may need a sign-in, or it may be blocking automatic readers" };
        return { ...r, url: p.url() };
      });
    } catch (e) { log(`Cable: could not read ${c.url} (${e.message})`); return { error: /Timeout/i.test(e.message) ? 'The site took too long to open' : `Could not open the site: ${String(e.message).split('\n')[0].slice(0, 120)}` }; }
  }

  /** Type a search into the site's own search box and read what it shows */
  async function search(url, q) {
    const c = await checkUrl(url, lookup);
    if (!c.ok) return { error: c.error };
    const term = String(q).trim().slice(0, 80);
    if (!term) return { results: [] };
    const tokens = term.toLowerCase().split(/[^a-z0-9]+/).filter((x) => x.length >= 3);
    try {
      return await withPage(async (p) => {
        /** What the page shows now: titles that match the words typed (a results page also shows the site's own picks) */
        const grab = async () => {
          await p.waitForTimeout(1500); await settle(p, 8000);
          let found = [], last = -1, still = 0;
          for (let i = 0; i < 8 && still < 2; i++) {
            found = await collectWhileScrolling(p, 3);
            const n = new Set(found.flatMap((x) => x.cards.map((k) => k.href))).size;
            still = n === last ? still + 1 : 0; last = n;
            if (still < 2) await p.waitForTimeout(1200);
          }
          const r = assemble(found.length ? found : [{ vw: 1366, cards: [], heads: [], pageTitle: '', icon: '' }]);
          const all = [...(r.hero ? [{ title: r.hero.title, href: r.hero.href, img: r.hero.img }] : []), ...r.rows.flatMap((x) => x.items)];
          const seen = new Set(); const out = [];
          for (const it of tokens.length ? all.filter((x) => tokens.some((tk) => x.title.toLowerCase().includes(tk))) : all) { if (seen.has(it.href)) continue; seen.add(it.href); out.push({ title: it.title, href: it.href, img: it.img }); }
          return out;
        };
        await p.goto(c.url, { waitUntil: 'domcontentloaded', timeout: 30_000 });
        await settle(p, 7000); await dismissBanners(p);
        const SEL = ['input[type=search]', '[role=search] input[type=text]', '[role=search] input', 'input[name=q]', 'input[name=s]', 'input[name=search]', 'input[name=query]', 'input[name=keyword]', 'input[placeholder*="earch" i]', 'input[aria-label*="earch" i]', 'input[placeholder*="Find" i]'].join(', ');
        const find = async () => { for (const l of await p.locator(SEL).all()) if (await l.isVisible().catch(() => false)) return l; return null; };
        let results = [];
        let box = await find();
        if (!box) { // the box may sit behind a search button
          for (const b of await p.locator('[aria-label*="earch" i], button[class*="search" i], a[class*="search" i], [data-testid*="search" i], a[href*="search"]').all()) { if (await b.isVisible().catch(() => false)) { await b.click({ timeout: 2000 }).catch(() => {}); await p.waitForTimeout(600); box = await find(); if (box) break; } }
        }
        if (box) { await box.click({ timeout: 3000 }).catch(() => {}); await box.fill(term, { timeout: 3000 }).catch(() => {}); await box.press('Enter').catch(() => {}); results = await grab(); }
        // No box, or it showed nothing: the usual address shapes
        if (!results.length) {
          const base = new URL(c.url);
          for (const t of [`/search/${encodeURIComponent(term)}`, `/search?q=${encodeURIComponent(term)}`, `/?s=${encodeURIComponent(term)}`, `/search?query=${encodeURIComponent(term)}`, `/search/?q=${encodeURIComponent(term)}`]) {
            const r = await p.goto(new URL(t, base).href, { waitUntil: 'domcontentloaded', timeout: 15_000 }).catch(() => null);
            if (!r || !r.ok()) continue;
            await dismissBanners(p);
            results = await grab();
            if (results.length) break;
          }
        }
        return { results: results.slice(0, 60), url: p.url() };
      });
    } catch (e) { return { error: /Timeout/i.test(e.message) ? 'The site took too long to answer' : `Search failed: ${String(e.message).split('\n')[0].slice(0, 120)}` }; }
  }  return { read, search, stop() { clearTimeout(idle); browser?.close().catch(() => {}); browser = null; }, ready: () => !!browserPath() };
}
