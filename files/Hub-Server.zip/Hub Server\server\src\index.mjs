// Start the ecosystem server: node src/index.mjs (or npm start in this folder).
import { loadConfig } from './config.mjs';
import { openDb } from './db.mjs';
import { createApp } from './app.mjs';

const cfg = loadConfig();
const db = openDb(cfg.dataDir, { backupDir: cfg.backupDir, keep: cfg.backupDays });
const app = createApp(cfg, db);
const port = await app.start();
console.log(`Ecosystem server on port ${port}. Email: ${cfg.email.provider}, text: ${cfg.sms.provider}.`);
console.log(`  Data:    ${cfg.dataDir}`);
console.log(`  Backups: ${cfg.backupDir ?? cfg.dataDir + '\\backups'} (one a day, last ${cfg.backupDays} days)`);
console.log(`  Updates: ${cfg.updatesDir}`);
if (cfg.phoneDir) console.log(`  Phone app: ${cfg.phoneDir} (download on the phone at http://<this PC's address>:${port}/phone)`);
if (cfg.webDir) console.log(`  Web Hub: ${cfg.webDir} (iPhone: Safari at http://<this PC's address>:${port}, then Add to Home Screen)`);
for (const s of ['SIGINT', 'SIGTERM']) process.on(s, async () => { await app.stop(); process.exit(0); });
