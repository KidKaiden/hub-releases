// Clipper's extra judges (Clipper additions, 2026-11-23). Pure where it can be, so the tests run without FFmpeg:
//   replay:    YouTube's "most replayed" graph (yt-dlp's heatmap) -> a per-second signal, the opening ignored
//   dead air:  silent gaps (whisper's word gaps and FFmpeg's silencedetect agreeing) -> the parts to cut, reversibly
//   grades:    hook, flow and value, 0 to 10 each, with the reason in words
//   stranger:  "would someone who has never seen this get it in 2 seconds?", the local vision model on 3 frames
//   music:     a guess (labelled as one) that a song is playing, from how steady the sound is outside the voice band

const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const clamp01 = (x) => clamp(x, 0, 1);
const median = (a) => { const s = a.filter(Number.isFinite).sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : 0; };

// ---------------- Most replayed ----------------
/** yt-dlp prints the heatmap as JSON ("NA" or "null" when the video has none) */
export function parseHeatmap(text) {
  try { const j = JSON.parse(String(text ?? '').trim()); return Array.isArray(j) ? j.filter((p) => Number.isFinite(p?.start_time) && Number.isFinite(p?.end_time) && Number.isFinite(p?.value)) : null; } catch { return null; }
}
/**
 * The heatmap (about 100 points, value 0 to 1) -> one strength a second. The opening is ignored (the first point is nearly
 * always the peak: people start at the start). Strength = how far above this video's usual a second is replayed.
 */
export function replaySignal(heatmap, seconds, { skip = Math.max(seconds * 0.03, heatmap?.[1]?.end_time ?? 0) } = {}) {
  const n = Math.max(1, Math.ceil(seconds));
  const raw = new Array(n).fill(0);
  if (!heatmap?.length) return null;
  for (const p of heatmap) for (let t = Math.max(0, Math.floor(p.start_time)); t < Math.min(n, Math.ceil(p.end_time)); t++) raw[t] = Math.max(raw[t], p.value);
  for (let t = 0; t < Math.min(n, Math.ceil(skip)); t++) raw[t] = 0;
  const rest = raw.slice(Math.ceil(skip));
  const top = Math.max(...rest, 0), mid = median(rest);
  if (top <= 0 || top - mid < 0.05) return new Array(n).fill(0);
  return raw.map((v) => Math.round(clamp01((v - mid) / (top - mid)) * 100) / 100);
}

// ---------------- Dead air ----------------
/** FFmpeg silencedetect's lines -> [{ t0, t1 }] (seconds, in the measured stretch's own time) */
export function parseSilences(text, shift = 0) {
  const out = []; let start = null;
  for (const line of String(text).split(/\r?\n/)) {
    const a = /silence_start:\s*(-?[\d.]+)/.exec(line); if (a) { start = Math.max(0, Number(a[1])); continue; }
    const b = /silence_end:\s*([\d.]+)/.exec(line); if (b && start !== null) { out.push({ t0: start + shift, t1: Number(b[1]) + shift }); start = null; }
  }
  return out;
}
/**
 * The silent stretches inside a clip worth cutting. A gap counts only when nobody speaks (no word in it, when the words
 * are known) and FFmpeg hears quiet, it is long enough after leaving a little air each side, and nothing big happens on
 * screen then. The first second and a half is never cut (the hook). Times are the clip's own (0 = first frame).
 * Returns { cuts: [[a, b]], removed, left } where left is the dead air kept because the screen was busy.
 */
export function deadAir({ length, words = null, silences = [], screen = [], pad = 0.15, min = 0.7, hook = 1.5 }) {
  const cuts = []; let left = 0;
  for (const s of silences) {
    let a = Math.max(hook, s.t0) + pad, b = Math.min(length - 0.3, s.t1) - pad;
    if (words?.length) for (const w of words) if (w.t1 > a && w.t0 < b) { if (w.t0 - a > b - w.t1) b = w.t0 - pad; else a = w.t1 + pad; }
    if (b - a < min) continue;
    const busy = screen.slice(Math.floor(a), Math.ceil(b)).some((x) => x >= 0.5);
    if (busy) { left += b - a; continue; }
    cuts.push([Math.round(a * 100) / 100, Math.round(b * 100) / 100]);
  }
  return { cuts, removed: Math.round(cuts.reduce((t, [a, b]) => t + b - a, 0) * 10) / 10, left: Math.round(left * 10) / 10 };
}
/** What stays when the cuts come out: [[a, b]] covering 0..length */
export function keepSegments(length, cuts) {
  const out = []; let at = 0;
  for (const [a, b] of [...cuts].sort((x, y) => x[0] - y[0])) { if (a > at) out.push([at, a]); at = Math.max(at, b); }
  if (at < length) out.push([at, length]);
  return out.filter(([a, b]) => b - a > 0.05);
}
/** A time in the uncut clip -> its time after the cuts (null when it falls inside a cut) */
export function shiftTime(t, cuts) {
  let back = 0;
  for (const [a, b] of [...cuts].sort((x, y) => x[0] - y[0])) { if (t >= b) back += b - a; else if (t > a) return null; }
  return t - back;
}
/** The words moved to match the cut clip; a word that falls in a cut is dropped */
export const shiftWords = (words, cuts) => words.map((w) => ({ ...w, t0: shiftTime(w.t0, cuts), t1: shiftTime(w.t1, cuts) })).filter((w) => w.t0 !== null && w.t1 !== null);

// ---------------- Grades ----------------
/**
 * Hook: does it grab in the first 1.5 s (a face, something loud or moving at the start, the stranger test).
 * Flow: how much dead air is left, and is it short. Value: the local AI's read of the words (null when it couldn't).
 */
export function gradeClip({ face = false, opening = 0, stranger = null, deadLeft = 0, seconds = 20, value = null, valueWhy = '' }) {
  const why = [];
  const hook = Math.round(clamp((face ? 4 : 0) + opening * 3 + (stranger === null ? 1.5 : stranger * 0.3), 0, 10));
  why.push(face ? 'A face from the first second' : 'No face at the start');
  if (opening >= 0.5) why.push('Something loud or moving in the first 2 seconds'); else why.push('A slow first 2 seconds');
  if (stranger !== null) why.push(`Stranger test ${stranger} of 10`);
  const ratio = seconds > 0 ? deadLeft / seconds : 0;
  const flow = Math.round(clamp(10 - ratio * 30 - (seconds > 35 ? 1 : 0), 0, 10));
  why.push(deadLeft >= 0.5 ? `${deadLeft} s of quiet left in it` : 'No dead air left');
  if (value !== null && valueWhy) why.push(String(valueWhy).slice(0, 140));
  return { hook, flow, value: value === null ? null : Math.round(clamp(Number(value), 0, 10)), why };
}

// ---------------- Stranger test ----------------
export const STRANGER = { type: 'object', additionalProperties: false, required: ['score', 'what'], properties: { score: { type: 'integer', minimum: 0, maximum: 10 }, what: { type: 'string' } } };
const STRANGER_SYSTEM = 'You judge short gameplay clips for social media. Someone who has never seen this game or streamer scrolls past. Score 0 to 10: would they understand what is happening and why it is interesting within 2 seconds, from these frames alone? 10 = obvious and striking (a crash, a fall, a clear fail or win); 0 = nothing readable. Answer in JSON: score and a short "what" (under 15 words).';
/** frames: base64 JPEGs one second apart. Returns { score, what } or null when the AI couldn't answer. */
export async function strangerTest(ask, frames) {
  if (!frames?.length) return null;
  const r = await ask({ system: STRANGER_SYSTEM, content: [{ text: 'Frames one second apart:' }, ...frames.map((data) => ({ image: { type: 'image/jpeg', data } }))], max: 120, schema: STRANGER, temperature: 0.2 });
  if (!r || r.error) return null;
  try { const j = JSON.parse(r.text); return Number.isFinite(j.score) ? { score: clamp(Math.round(j.score), 0, 10), what: String(j.what ?? '').slice(0, 100) } : null; } catch { return null; }
}

// ---------------- Music (a guess) ----------------
/**
 * Per-second levels (dB) of the whole sound and of the sound outside the voice band, over a clip. A song keeps the
 * outside-the-voice part loud and steady; talk and game sounds come and go. A guess, never proof: the app labels it so.
 */
export function musicGuess(full, other) {
  const n = Math.min(full.length, other.length);
  if (n < 5) return { maybe: false, why: 'Too short to tell' };
  const share = median(Array.from({ length: n }, (_, i) => other[i] - full[i]));       // dB: 0 = all of it, -12 = a sixteenth
  const lv = other.slice(0, n).filter((x) => x > -80);
  if (lv.length < n * 0.8) return { maybe: false, why: 'Mostly quiet outside the voice' };
  const mean = lv.reduce((t, x) => t + x, 0) / lv.length;
  const spread = Math.sqrt(lv.reduce((t, x) => t + (x - mean) ** 2, 0) / lv.length);   // dB: a song stays within a few
  const maybe = share > -8 && spread < 4 && mean > -40;
  return { maybe, why: maybe ? 'Steady sound outside the voice, like a song (a guess)' : 'No steady song-like sound (a guess)' };
}
