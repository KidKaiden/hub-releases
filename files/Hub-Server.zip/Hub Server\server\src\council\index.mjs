// The prediction council on the PC server: research only, it NEVER trades. It is handed only its own folder and a log
// (not the server's context), imports nothing outside server/src/council, and has no route that could reach trading
// (tests/council: server/test/council.test.mjs). Not connected to the chart-testing system: only after months of
// proven predictions, and only with Kaiden's say-so, may that change.
// Its folder (HUB\Council): config.json (teams, skills, sources, the chair's numbers: edit or replace it, no code),
// locker.jsonl (locked predictions and scores). Team weights are never stored: they are replayed from the locked scores,
// so every weight can be traced to the scores that made it.
import { copyFileSync, existsSync, mkdirSync, readFileSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkConfig, checkRecord, runChecks, accepted, score, newWeight, teamLead, chair } from './core.mjs';
import { locker } from './locker.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));

export function council({ dir, log = () => {}, now = () => Date.now(), isOwner = () => false }) {
  const cfgFile = join(dir, 'config.json');
  // made on first use (the placeholders, until Kaiden's researched list arrives)
  const ready = () => { if (!existsSync(cfgFile)) { mkdirSync(dir, { recursive: true }); copyFileSync(join(HERE, 'placeholder-config.json'), cfgFile); } };
  const lock = locker(join(dir, 'locker.jsonl'), now);
  const config = () => { ready(); try { const c = JSON.parse(readFileSync(cfgFile, 'utf8')); return { c, errors: checkConfig(c) }; } catch (e) { return { c: null, errors: [`config.json could not be read: ${e.message}`] }; } };

  function weights(c) {
    const w = Object.fromEntries((c?.teams ?? []).map((t) => [t.id, Number(t.weight) || c.chair.startWeight]));
    for (const s of lock.list('score')) { const t = s.content.team; if (t in w) w[t] = newWeight(w[t], s.content.score.total, c.chair); }
    return w;
  }
  function view() {
    const { c, errors } = config(), preds = lock.list('prediction'), scores = lock.list('score');
    const w = c && !errors.length ? weights(c) : {};
    return {
      ok: !errors.length, errors, note: c?.note ?? '', chair: c?.chair ?? null, shared: c?.shared ?? [], sources: c?.sources ?? [],
      teams: (c?.teams ?? []).map((t) => ({ id: t.id, name: t.name, placeholder: !!t.placeholder, weight: w[t.id] ?? null, skills: (c.skills ?? []).filter((s) => s.team === t.id).map((s) => ({ id: s.id, name: s.name, area: s.area ?? '', runner: s.runner ?? 'manual', sources: s.sources ?? [], placeholder: !!s.placeholder })), scored: scores.filter((s) => s.content.team === t.id).length })),
      predictions: preds.slice(-60).reverse().map((p) => ({ id: p.hash, at: p.at, team: p.content.record.team, skill: p.content.record.skill, question: p.content.record.question, prediction: p.content.record.prediction, horizonDays: p.content.record.horizonDays, due: new Date(Date.parse(p.at) + p.content.record.horizonDays * 86_400_000).toISOString(), score: scores.find((s) => s.content.prediction === p.hash)?.content.score ?? null })),
      locker: lock.verify()
    };
  }
  const signedIn = (u) => (u && !u.disabled ? null : [403, { error: 'Sign in first' }]);
  const owner = (u) => (isOwner(u) ? null : [403, { error: 'Only the owner can add to the council', code: 'owner' }]);

  const routes = {
    'GET /api/council': (b, u) => signedIn(u) ?? [200, view()],
    // A skill's record goes in; if every shared check passes it is locked (timestamped, never editable). Otherwise it says why.
    'POST /api/council/submit': (b, u) => {
      const no = signedIn(u) ?? owner(u); if (no) return no;
      const { c, errors } = config(); if (errors.length) return [400, { error: 'The council file has problems: fix config.json first', errors }];
      const r = b.record, bad = checkRecord(r, c);
      if (bad.length) return [400, { error: 'That record is not in the shared format', errors: bad }];
      const checks = runChecks(r, c);
      if (!accepted(checks)) return [400, { error: 'Not accepted: a shared check did not pass', checks }];
      const e = lock.add('prediction', { record: r, checks, by: u.id });
      log(`Council: prediction locked (${r.team}/${r.skill}) ${e.hash.slice(0, 12)}`);
      return [200, { id: e.hash, at: e.at, view: view() }];
    },
    // Score a locked prediction once its time is up: the score is locked too, and moves the team's weight
    'POST /api/council/score': (b, u) => {
      const no = signedIn(u) ?? owner(u); if (no) return no;
      const { errors } = config(); if (errors.length) return [400, { error: 'Fix config.json first', errors }];
      const p = lock.get(String(b.id ?? '')); if (!p || p.kind !== 'prediction') return [404, { error: 'No locked prediction with that id' }];
      if (lock.list('score').some((s) => s.content.prediction === p.hash)) return [409, { error: 'It is already scored: a score is locked too' }];
      if (now() < Date.parse(p.at) + p.content.record.horizonDays * 86_400_000) return [400, { error: 'Its time is not up yet' }];
      if (typeof b.happened !== 'boolean') return [400, { error: 'Say whether it happened (true or false)' }];
      const checkedClaims = Array.isArray(b.checkedClaims) ? b.checkedClaims.map((x) => ({ id: String(x?.id ?? ''), status: ['matches', 'does not match', 'no source yet', 'cannot compare'].includes(x?.status) ? x.status : 'cannot compare' })) : [];
      const s = score(p.content.record, { happened: b.happened, checkedClaims });
      lock.add('score', { prediction: p.hash, team: p.content.record.team, skill: p.content.record.skill, happened: b.happened, checkedClaims, score: s, by: u.id });
      return [200, view()];
    }
  };
  return { routes, view, config, teamLead, chair, lock };
}

export const councilDir = (cfg) => cfg.council?.dir ?? resolve(cfg.dataDir, '..', 'Council');
