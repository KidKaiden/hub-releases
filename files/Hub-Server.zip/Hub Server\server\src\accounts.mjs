// Accounts: the server holds them, every device asks the same server. The first account on an empty server is
// the owner; later accounts are made by the owner (Hub > Admin). Sign-in is username and password; email is
// optional and only used for sending reminders.
import { randomUUID } from 'node:crypto';
import {
  hashPassword, checkPassword, hashAnswer, checkAnswer, passwordProblem, usernameProblem, cleanUsername,
  newToken, revoke, revokeAll, tokenKey
} from './auth.mjs';
import { record, addr } from './history.mjs';

export const QUESTIONS = [
  'What was the name of your first pet?',
  'What street did you grow up on?',
  'What was your first school called?',
  'What is your favourite film?',
  "What is your mum's middle name?"
];

/** The rules in force now: "Stricter" raises the minimum and shortens sessions. */
export function rules(db) {
  const s = db.data.settings;
  const strict = s.securityLevel === 'stricter';
  return {
    passwordMin: strict ? Math.max(10, s.passwordMin) : s.passwordMin,
    securityLevel: s.securityLevel,
    sessionDays: strict ? Math.min(30, s.sessionDays) : s.sessionDays,
    lockout: strict ? { tries: 5, minutes: 15 } : null,
    // Hook for a later second step (for example a code sent by email). Off in both levels for now.
    secondStep: false
  };
}

export const pub = (u) => ({
  accountId: u.id, username: u.username, name: u.name, email: u.email ?? '', role: u.role ?? 'user',
  mustChange: !!u.mustChange, hasQuestion: !!u.answer, question: u.question ?? ''
});
export const findUser = (db, name) => {
  const n = cleanUsername(name);
  if (!n) return undefined;
  return Object.values(db.data.users).find((x) => x.username === n || (x.email && x.email === n));
};
const deviceLabel = (d) => [d?.name, d?.platform].filter(Boolean).join(' · ').slice(0, 60);

export function accountRoutes(ctx) {
  const { db, cfg, log, stamp } = ctx;
  const ipFails = new Map(); // login tries per address (both levels)
  const userFails = new Map(); // login tries per username (Stricter: lockout)
  const forgotTries = new Map(); // forgot-password tries per username and per address

  const tooMany = (map, key, max, ms) => {
    const f = map.get(key);
    return f && f.until > Date.now() && f.n >= max;
  };
  const bump = (map, key, ms) => {
    const f = map.get(key);
    if (!f || f.until < Date.now()) map.set(key, { n: 1, until: Date.now() + ms });
    else f.n++;
  };

  function makeUser({ username, name, password, role, email, question, answer }) {
    const u = {
      id: randomUUID(), username: cleanUsername(username), name: String(name ?? '').trim().slice(0, 60) || cleanUsername(username),
      email: email ? String(email).trim().toLowerCase().slice(0, 120) : undefined,
      pw: hashPassword(password), role, created: Date.now()
    };
    if (question && answer) { u.question = String(question).trim().slice(0, 160); u.answer = hashAnswer(answer); }
    db.data.users[u.id] = u;
    return u;
  }
  ctx.makeUser = makeUser;

  function signIn(u, b, ip, what = 'signed in') {
    const r = rules(db);
    u.lastSignIn = Date.now();
    const token = newToken(db, u.id, r.sessionDays, b.device ?? {}, addr(ip));
    record(db, { user: u.id, username: u.username, kind: 'signin', what, device: deviceLabel(b.device), ip });
    log(`${stamp()} ${u.name} ${what} from ${addr(ip)}`);
    return [200, { token, expires: Date.now() + r.sessionDays * 86400000, ...pub(u) }];
  }

  return {
    'GET /api/health': (_b, _u, meta) => {
      const r = rules(db);
      return [200, {
        ok: true, time: Date.now(), version: 1, api: 2,
        server: { id: db.data.server.id, name: db.data.server.name },
        hasAccounts: Object.keys(db.data.users).length > 0,
        rules: { passwordMin: meta?.public ? Math.max(r.passwordMin, cfg.publicPasswordMin) : r.passwordMin, securityLevel: meta?.public ? 'stricter' : r.securityLevel },
        publicUrl: cfg.publicUrl || undefined, public: !!meta?.public,
        questions: QUESTIONS
      }];
    },

    // First account (the owner) on an empty server. Later accounts come from the owner's console.
    'POST /api/register': (b, _u, { ip, public: outside }) => {
      if (outside) return [403, { error: 'Accounts are made at home: the owner on the home network, others in Hub > Admin', code: 'closed' }];
      const users = Object.values(db.data.users);
      const email = String(b.email ?? '').trim().toLowerCase();
      // Older hub versions only sent an email: make a username from it
      const username = cleanUsername(b.username ?? (b.name ? String(b.name).replace(/\s+/g, '') : email.split('@')[0]));
      if (users.length > 0) {
        const legacy = email && cfg.allowSignup.includes(email);
        if (!legacy) {
          log(`${stamp()} new account refused for ${username || email} from ${addr(ip)} (the owner makes accounts in Hub > Admin)`);
          return [403, { error: 'This server already has an owner. Ask them to make your account (Hub > Admin)', code: 'closed' }];
        }
      }
      const uerr = usernameProblem(username);
      if (uerr) return [400, { error: uerr, field: 'username' }];
      if (findUser(db, username)) return [409, { error: 'That username is taken', field: 'username' }];
      if (email && users.some((u) => u.email === email)) return [409, { error: 'That email already has an account', field: 'email' }];
      const perr = passwordProblem(b.password, { username, name: b.name }, rules(db).passwordMin);
      if (perr) return [400, { error: perr, field: 'password' }];
      const u = makeUser({ username, name: b.name, password: String(b.password), role: users.length ? 'user' : 'owner', email: email || undefined, question: b.question, answer: b.answer });
      // A new server is named after its PC until it has an owner; then it's "<their name>'s Hub" (changeable in Admin)
      if (u.role === 'owner' && /\sserver$/.test(db.data.server.name ?? '')) { db.data.server.name = `${u.name.split(/\s+/)[0]}'s Hub`.slice(0, 40); db.save(); }
      log(`${stamp()} account created for ${u.name} (${u.username}${u.role === 'owner' ? ', owner' : ''}) from ${addr(ip)}`);
      record(db, { user: u.id, username: u.username, kind: 'admin', what: u.role === 'owner' ? 'created the owner account' : 'created an account', ip });
      return signIn(u, b, ip, 'signed in for the first time');
    },

    'POST /api/login': (b, _u, { ip, public: outside }) => {
      if (tooMany(ipFails, ip, 5)) return [429, { error: 'Too many tries. Wait a minute and try again', code: 'slow' }];
      // A new server has no accounts: say so, instead of "wrong password" (it only tells that the server is empty)
      if (!Object.keys(db.data.users).length) return [401, { error: 'No accounts on this server yet. Create the first one', code: 'empty' }];
      const name = b.username ?? b.email;
      const u = findUser(db, name);
      const r0 = rules(db);
      // Through the outside link the stricter rules always apply
      const r = outside ? { ...r0, lockout: r0.lockout ?? { tries: 5, minutes: 15 } } : r0;
      if (u && r.lockout && tooMany(userFails, u.id, r.lockout.tries)) {
        return [429, { error: `Too many wrong tries for this account. Wait ${r.lockout.minutes} minutes or ask the owner`, code: 'locked' }];
      }
      if (!u || !checkPassword(String(b.password ?? ''), u.pw)) {
        bump(ipFails, ip, 60_000);
        if (u && r.lockout) bump(userFails, u.id, r.lockout.minutes * 60_000);
        record(db, { user: u?.id, username: u?.username ?? cleanUsername(name).slice(0, 40), kind: 'fail', what: 'wrong username or password', device: deviceLabel(b.device), ip });
        log(`${stamp()} wrong username or password from ${addr(ip)}`);
        return [401, { error: 'Username or password is wrong', code: 'wrong' }];
      }
      if (u.disabled) {
        record(db, { user: u.id, username: u.username, kind: 'fail', what: 'tried to sign in to a turned-off account', ip });
        return [403, { error: 'This account is turned off. Ask the owner', code: 'disabled' }];
      }
      ipFails.delete(ip); userFails.delete(u.id);
      if (outside && String(b.password).length < cfg.publicPasswordMin) {
        record(db, { user: u.id, username: u.username, kind: 'fail', what: 'password too short for the outside link', ip });
        return [403, { error: `From outside, passwords need ${cfg.publicPasswordMin} or more characters. Sign in at home and change yours in Settings > Account`, code: 'short-public' }];
      }
      return signIn(u, b, ip, outside ? 'signed in from outside' : 'signed in');
    },

    'POST /api/logout': (_b, u, { ip, token, session }) => {
      revoke(db, token);
      record(db, { user: u.id, username: u.username, kind: 'signout', what: 'signed out', device: deviceLabel(session?.device), ip });
      return [200, { ok: true }];
    },
    'GET /api/me': (_b, u) => [200, pub(u)],

    'POST /api/account/password': (b, u, { ip, token }) => {
      if (!checkPassword(String(b.current ?? ''), u.pw)) return [401, { error: 'Your current password is wrong', field: 'current', code: 'wrong' }];
      const perr = passwordProblem(b.password, u, rules(db).passwordMin);
      if (perr) return [400, { error: perr, field: 'password' }];
      u.pw = hashPassword(String(b.password));
      delete u.mustChange;
      // Other devices stay signed in unless asked (a reset by the owner signs everyone out instead)
      if (b.signOutOthers) for (const [k, v] of Object.entries(db.data.tokens)) if (v.userId === u.id && k !== tokenKey(token)) delete db.data.tokens[k];
      db.save();
      record(db, { user: u.id, username: u.username, kind: 'password', what: 'changed their password', ip });
      return [200, pub(u)];
    },
    'POST /api/account/question': (b, u, { ip }) => {
      if (!checkPassword(String(b.password ?? ''), u.pw)) return [401, { error: 'Your password is wrong', field: 'password', code: 'wrong' }];
      const q = String(b.question ?? '').trim(), a = String(b.answer ?? '').trim();
      if (q.length < 5) return [400, { error: 'Pick or write a question', field: 'question' }];
      if (a.length < 2) return [400, { error: 'Write an answer', field: 'answer' }];
      u.question = q.slice(0, 160); u.answer = hashAnswer(a);
      db.save();
      record(db, { user: u.id, username: u.username, kind: 'password', what: 'changed their security question', ip });
      return [200, pub(u)];
    },
    'POST /api/account/profile': (b, u) => {
      if (b.name !== undefined) u.name = String(b.name).trim().slice(0, 60) || u.name;
      if (b.email !== undefined) {
        const e = String(b.email).trim().toLowerCase();
        if (e && !/^[^@\s]+@[^@\s]+$/.test(e)) return [400, { error: 'That email looks wrong', field: 'email' }];
        if (e && Object.values(db.data.users).some((x) => x !== u && x.email === e)) return [409, { error: 'Another account uses that email', field: 'email' }];
        u.email = e || undefined;
      }
      db.save();
      return [200, pub(u)];
    },

    // Forgot password: username -> question -> answer -> new password. Limited per username and per address.
    'POST /api/forgot': (b, _u, { ip }) => {
      const u = findUser(db, b.username);
      if (tooMany(forgotTries, `ip:${ip}`, 10)) return [429, { error: 'Too many tries. Wait 15 minutes and try again', code: 'slow' }];
      bump(forgotTries, `ip:${ip}`, 15 * 60_000);
      if (!u) return [404, { error: 'No account with that username', field: 'username' }];
      if (!u.answer) return [400, { error: 'This account has no security question. Ask the owner to reset your password', code: 'noquestion' }];
      return [200, { question: u.question }];
    },
    'POST /api/forgot/reset': (b, _u, { ip, public: outside }) => {
      const u = findUser(db, b.username);
      if (!u) return [404, { error: 'No account with that username', field: 'username' }];
      if (tooMany(forgotTries, `u:${u.id}`, 5) || tooMany(forgotTries, `ip:${ip}`, 10)) {
        return [429, { error: 'Too many tries. Wait 15 minutes or ask the owner', code: 'slow' }];
      }
      if (!checkAnswer(b.answer, u.answer)) {
        bump(forgotTries, `u:${u.id}`, 15 * 60_000); bump(forgotTries, `ip:${ip}`, 15 * 60_000);
        record(db, { user: u.id, username: u.username, kind: 'fail', what: 'wrong security answer', ip });
        return [401, { error: "That answer doesn't match", field: 'answer', code: 'wrong' }];
      }
      const perr = passwordProblem(b.password, u, outside ? Math.max(rules(db).passwordMin, cfg.publicPasswordMin) : rules(db).passwordMin);
      if (perr) return [400, { error: perr, field: 'password' }];
      u.pw = hashPassword(String(b.password));
      delete u.mustChange;
      revokeAll(db, u.id);
      forgotTries.delete(`u:${u.id}`);
      record(db, { user: u.id, username: u.username, kind: 'password', what: 'reset their password with the security question', ip });
      log(`${stamp()} ${u.name} reset their password with the security question`);
      return signIn(u, b, ip);
    }
  };
}
