// Friends and the leaderboard (Update 2, D9). Friendship is between Hub accounts, not one app: someone asks, the
// other accepts, and only then do they see each other on the leaderboard. The leaderboard shares numbers only
// (level, points, streak, badges): never bills, balances, notes or tasks. Either side can remove the friendship.
import { randomUUID } from 'node:crypto';
import { findUser } from './accounts.mjs';
import { record } from './history.mjs';

const person = (u) => ({ accountId: u.id, username: u.username, name: u.name || u.username });
const num = (v, max = 1e9) => Math.max(0, Math.min(max, Math.round(Number(v) || 0)));

export function friendRoutes(ctx) {
  const { db } = ctx;
  const list = () => (db.data.friends ??= []);
  const stats = () => (db.data.stats ??= {});
  const between = (a, b) => list().find((f) => (f.from === a && f.to === b) || (f.from === b && f.to === a));
  const friendsOf = (id) => list().filter((f) => f.status === 'accepted' && (f.from === id || f.to === id)).map((f) => (f.from === id ? f.to : f.from));
  const note = (u, what) => record(db, { user: u.id, username: u.username, kind: 'action', what });

  return {
    'GET /api/friends': (_b, u) => {
      const users = db.data.users;
      const friends = list().filter((f) => f.status === 'accepted' && (f.from === u.id || f.to === u.id))
        .map((f) => users[f.from === u.id ? f.to : f.from]).filter(Boolean).map((x) => ({ ...person(x), since: between(u.id, x.id)?.answered ?? null }));
      const incoming = list().filter((f) => f.status === 'pending' && f.to === u.id && users[f.from]).map((f) => ({ id: f.id, from: person(users[f.from]), created: f.created }));
      const outgoing = list().filter((f) => f.status === 'pending' && f.from === u.id && users[f.to]).map((f) => ({ id: f.id, to: person(users[f.to]), created: f.created }));
      return [200, { friends, incoming, outgoing }];
    },
    'POST /api/friends/request': (b, u) => {
      const to = findUser(db, String(b.username ?? '').trim().toLowerCase());
      if (!to || to.disabled) return [404, { error: `No account called "${String(b.username ?? '').trim()}" on this Hub`, field: 'username' }];
      if (to.id === u.id) return [400, { error: "That's you", field: 'username' }];
      const f = between(u.id, to.id);
      if (f?.status === 'accepted') return [409, { error: `You and ${to.name || to.username} are already friends` }];
      if (f?.status === 'pending' && f.from === u.id) return [409, { error: `You asked ${to.name || to.username} already. Waiting for them to accept` }];
      if (f?.status === 'pending' && f.to === u.id) {
        // They already asked you: asking back is a yes
        f.status = 'accepted'; f.answered = Date.now(); db.save();
        note(u, `became friends with ${to.username}`);
        return [200, { status: 'accepted', friend: person(to) }];
      }
      list().push({ id: randomUUID(), from: u.id, to: to.id, status: 'pending', created: Date.now() });
      db.save();
      note(u, `asked ${to.username} to be friends`);
      return [200, { status: 'pending', to: person(to) }];
    },
    'POST /api/friends/answer': (b, u) => {
      const f = list().find((x) => x.id === b.id && x.to === u.id && x.status === 'pending');
      if (!f) return [404, { error: 'That request has gone' }];
      const from = db.data.users[f.from];
      if (b.accept) { f.status = 'accepted'; f.answered = Date.now(); note(u, `became friends with ${from?.username ?? 'someone'}`); }
      else { db.data.friends = list().filter((x) => x !== f); note(u, `said no to a friend request`); }
      db.save();
      return [200, { ok: true }];
    },
    /** Remove a friend, or take back a request (either side) */
    'POST /api/friends/remove': (b, u) => {
      const f = between(u.id, String(b.accountId ?? ''));
      if (!f) return [404, { error: 'You are not friends with them' }];
      db.data.friends = list().filter((x) => x !== f);
      db.save();
      note(u, f.status === 'accepted' ? 'removed a friend' : 'took back a friend request');
      return [200, { ok: true }];
    },
    /** My leaderboard numbers (sent by the Finance app). Numbers only: nothing else is accepted. */
    'POST /api/stats': (b, u) => {
      stats()[u.id] = { points: num(b.points), level: num(b.level, 1e6), streak: num(b.streak, 1e5), badges: num(b.badges, 100), updated: Date.now() };
      db.save();
      return [200, { ok: true }];
    },
    /** Me and my friends, most points first */
    'GET /api/leaderboard': (_b, u) => {
      const ids = [u.id, ...friendsOf(u.id)];
      const rows = ids.map((id) => db.data.users[id]).filter(Boolean).map((x) => ({ ...person(x), me: x.id === u.id, ...(stats()[x.id] ?? { points: 0, level: 1, streak: 0, badges: 0, updated: null }) }));
      rows.sort((a, b) => b.points - a.points || a.name.localeCompare(b.name));
      return [200, { rows }];
    }
  };
}
