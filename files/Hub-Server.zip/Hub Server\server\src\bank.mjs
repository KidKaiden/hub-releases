// Finance > Business > Bank: a live feed from a business bank account, through Enable Banking.
//
// The rules (Kaiden's, unchanged): this server runs only on the home Windows PC. The Enable Banking application id and
// the PATH of its private key file are settings (EB_APP_ID and EB_KEY_FILE in server/.env), never in code or git; the
// key is read from that file only to sign a request, and is never logged, copied or sent anywhere. The app never sees
// a bank password: the person approves in their own bank's app or website. An approval lasts a set time (the bank
// says how long): the app shows when it runs out and reminds before it does.
//
// What it does: lists banks, starts an approval (the bank sends the person back to /bank/callback), remembers the
// accounts approved (only the last 4 digits of the account number, for telling them apart), lets the person choose
// what each account feeds (Finance > Banking, or one of their businesses), and every few hours (or on "Check now") adds payments that have gone through as money in
// or out of that business, each once (an id made from the bank's own reference), asking the user to check each
// category. A payment the user deleted is never brought back. Partners see the business's money, never the connection.
import { createSign, createHash, randomUUID } from 'node:crypto';
import { readFileSync, existsSync, readdirSync, statSync, mkdirSync, renameSync, copyFileSync, unlinkSync } from 'node:fs';
import { join, resolve, basename } from 'node:path';
import { homedir } from 'node:os';

const DAY = 86_400_000;
const dayOf = (t) => new Date(t).toISOString().slice(0, 10);
const html = (title, text) => `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title>
<body style="font:16px/1.5 system-ui,sans-serif;background:#16141c;color:#eceaf2;display:grid;place-items:center;min-height:90vh;margin:0;padding:16px">
<main style="max-width:420px"><h1 style="font-size:20px;font-weight:600">${title}</h1><p>${text}</p></main></body></html>`;
const esc = (s) => String(s ?? '').replace(/[<>&"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' })[c]);

export function bankFeed(ctx) {
  const { db, cfg, log, stamp } = ctx;
  // The settings: set in Admin > Banking (kept in this server's own data on the PC), or in server\.env. Never in git.
  const eb = {
    get appId() { return db.data.settings.bank?.appId || cfg.bank?.appId || ''; },
    get keyFile() { return db.data.settings.bank?.keyFile || cfg.bank?.keyFile || ''; },
    get redirect() { return cfg.bank?.redirect || ''; },
    get pollHours() { return cfg.bank?.pollHours || 6; }
  };
  const keysDir = () => cfg.keysDir || resolve(cfg.dataDir, '..', 'Keys');
  const base = (cfg.bank?.base || 'https://api.enablebanking.com').replace(/\/+$/, '');
  const redirect = () => eb.redirect || (cfg.publicUrl ? `${cfg.publicUrl}/bank/callback` : '');
  db.data.bankLinks ??= [];
  db.data.bankPending ??= [];
  // Who may connect a bank: anyone with unlimited space on this server (its owners always; others when an owner
  // switches them to unlimited, or with the server's unlimited-space password). Everyone else asks for more space,
  // or sets up their own server. (Enable Banking's rule for a home set-up: it can only read accounts that the
  // application's owner also linked in its Control Panel.)
  const isAdmin = (u) => !!db.data.roles?.[u.role]?.admin;
  const access = (u) => (isAdmin(u) || ctx.space?.unlimited(u) ? 'allowed' : u.spaceAsked ? 'pending' : 'none');

  /** Ready to connect? (the reason in plain words when not) */
  function ready() {
    if (!eb.appId || !eb.keyFile) return { ok: false, why: 'not-set' };
    if (!existsSync(eb.keyFile)) return { ok: false, why: 'no-key' };
    if (!redirect()) return { ok: false, why: 'no-redirect' };
    return { ok: true };
  }
  // A short-lived signed token for each call (RS256, at most an hour)
  function token() {
    const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
    const now = Math.floor(Date.now() / 1000);
    const head = b64({ typ: 'JWT', alg: 'RS256', kid: eb.appId });
    const body = b64({ iss: 'enablebanking.com', aud: 'api.enablebanking.com', iat: now, exp: now + 3600 });
    const sig = createSign('RSA-SHA256').update(`${head}.${body}`).sign(readFileSync(eb.keyFile, 'utf8')).toString('base64url');
    return `${head}.${body}.${sig}`;
  }
  async function call(method, path, body) {
    const r = await fetch(base + path, {
      method,
      headers: { authorization: `Bearer ${token()}`, 'content-type': 'application/json', accept: 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(30_000)
    });
    const t = await r.text();
    let j = {};
    try { j = t ? JSON.parse(t) : {}; } catch { j = {}; }
    if (!r.ok) throw Object.assign(new Error(j.message || j.error || `The bank service said ${r.status}`), { status: r.status });
    return j;
  }

  const tail = (a) => { const n = String(a?.account_id?.iban ?? a?.account_id?.other?.identification ?? a?.account_id?.bban ?? '').replace(/\s/g, ''); return n ? n.slice(-4) : ''; };
  const keyOf = (link, a) => createHash('sha256').update([link.bank, link.country, tail(a), a.currency ?? '', a.name ?? a.product ?? ''].join('|')).digest('hex').slice(0, 16);
  const view = (l) => ({
    id: l.id, bank: l.bank, country: l.country, validUntil: l.validUntil, created: l.created, lastSync: l.lastSync ?? null, error: l.error ?? null,
    accounts: l.accounts.map((a) => ({ key: a.key, name: a.name, tail: a.tail, currency: a.currency, biz: a.biz ?? null, from: a.from ?? null, added: a.added ?? 0, balance: a.balance ?? null }))
  });
  const mine = (u) => db.data.bankLinks.filter((l) => l.owner === u.id);
  const ownBiz = (u, id) => { const r = db.data.recs[`business/${id}`]?.rec; return r && !r.deleted && r.owner === u.id && r.data?.kind === 'biz' ? r : null; };

  // ---------- Bringing payments in ----------
  function add(link, acc, biz, t) {
    if (t.status && t.status !== 'BOOK') return 0; // only payments that have gone through (pending ones change)
    const amount = Number(t.transaction_amount?.amount);
    if (!Number.isFinite(amount) || amount === 0) return 0;
    const dir = t.credit_debit_indicator === 'CRDT' ? 'in' : t.credit_debit_indicator === 'DBIT' ? 'out' : amount < 0 ? 'out' : 'in';
    const date = String(t.booking_date || t.value_date || t.transaction_date || dayOf(Date.now())).slice(0, 10);
    const remit = Array.isArray(t.remittance_information) ? t.remittance_information.join(' ') : String(t.remittance_information ?? '');
    const party = String((dir === 'in' ? t.debtor?.name : t.creditor?.name) ?? '').trim();
    // The bank's own reference when it gives one; otherwise what the payment says (same every time it's read)
    const ref = t.entry_reference || createHash('sha256').update(JSON.stringify([date, amount, dir, remit, party, t.transaction_amount?.currency])).digest('hex').slice(0, 24);
    const hash = createHash('sha256').update(`${acc.key}|${ref}`).digest('hex').slice(0, 24);
    const words = (remit.trim() || party || (dir === 'in' ? 'Money in' : 'Money out')).replace(/\s+/g, ' ').slice(0, 140);
    // Personal: into Finance > Banking (only this person's own devices ever get it)
    if (!biz) {
      const pk = `banktx/btx-${hash}`;
      if (db.data.recs[pk]) return 0;
      const data = { kind: 'tx', dir, amount: Math.abs(amount), currency: String(t.transaction_amount?.currency ?? 'GBP'), date, payee: party || words, what: words, account: acc.key };
      db.data.recs[pk] = { rec: { col: 'banktx', id: `btx-${hash}`, app: 'finance', owner: link.owner, shared: [], rev: 1, updatedAt: Date.now(), deleted: false, data }, seq: db.nextSeq(), by: link.owner };
      return 1;
    }
    const id = `bank-${hash}`;
    const k = `business/${id}`;
    if (db.data.recs[k]) return 0; // already here (or deleted by the user: never brought back)
    const cur = String(t.transaction_amount?.currency ?? biz.data.currency ?? 'GBP');
    const data = {
      kind: 'entry', biz: biz.id, dir, amount: Math.abs(amount), date,
      what: words,
      partyName: party ? party.slice(0, 80) : undefined, paid: true, method: 'Bank',
      // Another currency: kept as it was; the user sets the rate when checking it
      ...(cur !== (biz.data.currency ?? 'GBP') ? { orig: { amount: Math.abs(amount), currency: cur, rate: 1 } } : {}),
      bank: { tx: String(ref).slice(0, 80), account: acc.key, check: true },
      by: 'Bank feed', clock: {}
    };
    const now = Date.now();
    db.data.recs[k] = { rec: { col: 'business', id, app: 'finance', owner: biz.owner, shared: [], rev: 1, updatedAt: now, deleted: false, data: JSON.parse(JSON.stringify(data)) }, seq: db.nextSeq(), by: link.owner };
    return 1;
  }
  async function syncAccount(link, acc) {
    // 'personal' feeds Finance > Banking; otherwise one of the person's own businesses
    const biz = acc.biz && acc.biz !== 'personal' ? db.data.recs[`business/${acc.biz}`]?.rec : null;
    if (acc.biz !== 'personal' && (!biz || biz.deleted || biz.owner !== link.owner)) return 0;
    // From the day chosen (or 90 days back) the first time; after that the last few days again (late bookings)
    const from = acc.last ? dayOf(Date.parse(acc.last) - 5 * DAY) : acc.from ?? dayOf(Date.now() - 90 * DAY);
    let key = null, n = 0, pages = 0;
    do {
      const q = new URLSearchParams({ date_from: from });
      if (key) q.set('continuation_key', key);
      const r = await call('GET', `/accounts/${encodeURIComponent(acc.uid)}/transactions?${q}`);
      for (const t of r.transactions ?? []) n += add(link, acc, biz, t);
      key = r.continuation_key || null;
    } while (key && ++pages < 60);
    acc.last = dayOf(Date.now());
    acc.added = (acc.added ?? 0) + n;
    return n;
  }
  // The balance, for the person's own net worth (Hub upgrade): only ever shown to them, never to the owner or a
  // partner. The bank's own figure: what it expects after pending payments, else the booked one.
  const BAL = ['XPCD', 'CLBD', 'ITBD', 'ITAV', 'CLAV', 'OPBD'];
  async function balanceOf(acc) {
    try {
      const r = await call('GET', `/accounts/${encodeURIComponent(acc.uid)}/balances`);
      const list = Array.isArray(r.balances) ? r.balances : [];
      const b = BAL.map((t) => list.find((x) => x.balance_type === t)).find(Boolean) ?? list[0];
      const amount = Number(b?.balance_amount?.amount);
      if (Number.isFinite(amount)) acc.balance = { amount: Math.round(amount * 100) / 100, currency: String(b.balance_amount.currency ?? acc.currency), type: b.balance_type ?? null, at: Date.now() };
    } catch { /* keeps the last one; the payments still come in */ }
  }
  async function syncLink(link) {
    if (Date.parse(link.validUntil) < Date.now()) { link.error = 'expired'; return 0; }
    let n = 0;
    try {
      for (const acc of link.accounts) if (acc.biz) { n += await syncAccount(link, acc); await balanceOf(acc); }
      link.lastSync = Date.now(); link.error = null;
    } catch (e) {
      link.error = e.status === 401 || e.status === 403 ? 'expired' : 'failed';
      log(`${stamp()} Bank feed: ${link.bank} could not be read (${e.status ?? 'no answer'})`);
    }
    db.save();
    if (n) { log(`${stamp()} Bank feed: ${n} new payment${n === 1 ? '' : 's'} from ${link.bank}`); ctx.poke?.([link.owner]); }
    return n;
  }
  async function syncAll() {
    if (!ready().ok) return;
    // Only for people still allowed a bank (unlimited space): someone switched back to the normal space just pauses
    if (db.data.settings.bank?.paused) return;
    let n = 0, failed = 0, links = 0;
    for (const l of db.data.bankLinks) if (l.accounts.some((a) => a.biz) && l.error !== 'expired' && db.data.users[l.owner] && access(db.data.users[l.owner]) === 'allowed') { links++; n += await syncLink(l); if (l.error === 'failed') failed++; }
    if (links) ctx.runs?.record('bank', { ok: !failed, text: failed ? `${failed} bank${failed === 1 ? '' : 's'} couldn't be read` : `${n} payment${n === 1 ? '' : 's'} in`, n });
  }

  // ---------- Routes ----------
  let banks = { at: 0, country: '', list: [] };
  const routes = {
    'GET /api/bank/status': (_b, u) => [200, { ...ready(), access: access(u), owner: isAdmin(u), links: mine(u).map(view) }],
    // Asking for a bank is asking the owner for unlimited space (space.mjs; they answer in Admin > People)
    'POST /api/bank/request': async (b, u) => {
      if (access(u) === 'allowed') return [200, { access: 'allowed' }];
      const [code, r] = await ctx.space.routes['POST /api/space/request'](b, u);
      return [code, { ...r, access: 'pending' }];
    },
    // The owner: when bank approvals run out, for each person (dates only: never balances or payments)
    'GET /api/admin/bank': (_b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      const people = Object.values(db.data.users).map((p) => ({ accountId: p.id, name: p.name, username: p.username, allowed: access(p) === 'allowed', asked: p.spaceAsked ?? null, banks: db.data.bankLinks.filter((l) => l.owner === p.id).map((l) => ({ bank: l.bank, validUntil: l.validUntil, error: l.error ?? null })) }));
      return [200, { ...ready(), redirect: redirect() || null, appId: eb.appId ? `${eb.appId.slice(0, 4)}…` : null, checkedAt: db.data.settings.bank?.checkedAt ?? null, people }];
    },
    // Admin > Banking set-up, from the PC at home only (never through the outside link): find the key file the
    // browser saved in Downloads, move it into the Keys folder beside the project, and remember its path. Only the
    // file's name and date are ever shown; its contents are never read out, logged or sent anywhere.
    'GET /api/admin/bank/keys': (_b, u, meta) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      if (meta?.public) return [403, { error: 'Do this at home, on the PC itself', code: 'home' }];
      const look = (dir, where) => { try { return readdirSync(dir).filter((f) => /\.pem$/i.test(f)).map((f) => ({ name: f, where, modified: statSync(join(dir, f)).mtimeMs })); } catch { return []; } };
      return [200, { keys: [...look(join(homedir(), 'Downloads'), 'Downloads'), ...look(keysDir(), 'Keys')].sort((a, b) => b.modified - a.modified), keysDir: keysDir(), current: eb.keyFile ? basename(eb.keyFile) : null }];
    },
    'POST /api/admin/bank/setup': (b, u, meta) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      if (meta?.public) return [403, { error: 'Do this at home, on the PC itself', code: 'home' }];
      const name = basename(String(b.name ?? ''));
      if (!/^[\w.-]+\.pem$/i.test(name)) return [400, { error: 'Choose the .pem key file' }];
      const from = b.where === 'Keys' ? join(keysDir(), name) : join(homedir(), 'Downloads', name);
      if (!existsSync(from)) return [404, { error: "That file isn't there any more" }];
      // A private key, by its first line only
      const head = readFileSync(from, 'utf8').slice(0, 64);
      if (!/-----BEGIN (RSA )?PRIVATE KEY-----/.test(head)) return [400, { error: "That file isn't an Enable Banking key" }];
      mkdirSync(keysDir(), { recursive: true });
      const to = join(keysDir(), name);
      if (from !== to) { try { renameSync(from, to); } catch { copyFileSync(from, to); unlinkSync(from); } }
      // The application id is the file's name (Enable Banking names it <application id>.pem), unless typed
      const appId = String(b.appId ?? '').trim() || name.replace(/\.pem$/i, '');
      db.data.settings.bank = { appId, keyFile: to };
      db.save();
      log(`${stamp()} Bank feed: set up by ${u.name} (key kept in the Keys folder)`);
      return [200, { ...ready(), keyFile: name, keysDir: keysDir() }];
    },
    // Admin > Banking > Check it works: really asks Enable Banking (a signed call), so a wrong key, a wrong
    // application id or a missing return address shows here, in words, before anyone tries to connect.
    'POST /api/admin/bank/test': async (_b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      const steps = [];
      const add = (label, ok, detail = '') => { steps.push({ label, ok, detail }); return ok; };
      add('Outside link (where the bank sends people back)', !!redirect(), redirect() || 'Not on yet: double-click outside-link.cmd');
      if (!add('Enable Banking application id', !!eb.appId, eb.appId ? `${eb.appId.slice(0, 8)}…` : 'Not set yet (step 4)')) return [200, { ok: false, steps }];
      if (!add('Key file in the Keys folder', !!eb.keyFile && existsSync(eb.keyFile), eb.keyFile ? basename(eb.keyFile) : 'Not set yet (step 4)')) return [200, { ok: false, steps }];
      try { token(); add('The key can sign requests', true); } catch { add('The key can sign requests', false, "The file isn't a usable private key"); return [200, { ok: false, steps }]; }
      try {
        const app = await call('GET', '/application');
        add('Enable Banking accepts this server', true, app.name ? `Application "${app.name}"${app.environment ? ` (${String(app.environment).toLowerCase()})` : ''}` : '');
        const urls = Array.isArray(app.redirect_urls) ? app.redirect_urls : null;
        if (urls && redirect()) add('Return address listed in the application', urls.includes(redirect()), urls.includes(redirect()) ? redirect() : `Add ${redirect()} to the application's redirect URLs`);
        if (app.active === false) add('Application active', false, 'Not active yet: in the Control Panel, choose Activate by linking accounts');
      } catch (e) {
        add('Enable Banking accepts this server', false, e.status === 401 || e.status === 403 ? 'It turned the key down: the key file and the application id must belong together' : e.status ? `It answered ${e.status}` : "Couldn't reach Enable Banking: check the internet");
      }
      const ok = steps.every((s) => s.ok);
      if (db.data.settings.bank) { db.data.settings.bank.checkedAt = ok ? Date.now() : null; db.save(); }
      log(`${stamp()} Bank feed: connection checked by ${u.name} (${ok ? 'all fine' : 'something to fix'})`);
      return [200, { ok, steps }];
    },
    // The owner takes someone's bank feed away: their connections end at the bank (what came in stays theirs)
    'POST /api/admin/bank/stop': async (b, u) => {
      if (!isAdmin(u)) return [403, { error: 'Only the owner can do this', code: 'owner' }];
      const who = db.data.users[b.accountId];
      if (!who) return [404, { error: 'Not found' }];
      for (const l of db.data.bankLinks.filter((x) => x.owner === who.id)) { if (ready().ok && l.session) await call('DELETE', `/sessions/${encodeURIComponent(l.session)}`).catch(() => {}); db.data.bankLinks = db.data.bankLinks.filter((x) => x !== l); }
      db.save();
      log(`${stamp()} Bank feed: ${u.name} ended ${who.name}'s bank connections`);
      ctx.poke?.([who.id]);
      return [200, { ok: true }];
    },
    'GET /api/bank/banks': async (_b, _u, { q }) => {
      if (!ready().ok) return [503, { error: 'The bank connection is not set up on the PC yet', code: 'not-ready' }];
      const country = /^[A-Z]{2}$/.test(q.get('country') ?? '') ? q.get('country') : 'GB';
      if (banks.country !== country || Date.now() - banks.at > DAY) {
        const r = await call('GET', `/aspsps?country=${country}`);
        banks = { at: Date.now(), country, list: (r.aspsps ?? []).map((a) => ({ name: a.name, country: a.country, logo: a.logo, days: Math.round(Number(a.maximum_consent_validity ?? 7_776_000) / 86_400), psu: a.psu_types ?? ['personal', 'business'] })) };
      }
      return [200, { banks: banks.list }];
    },
    // Start an approval: the app opens the address it gets back, the person approves at their bank
    'POST /api/bank/connect': async (b, u) => {
      if (!ready().ok) return [503, { error: 'The bank connection is not set up on the PC yet', code: 'not-ready' }];
      if (access(u) !== 'allowed') return [403, { error: 'Ask the owner first: they allow banks in Hub > Admin', code: 'ask' }];
      const bank = String(b.bank ?? '').slice(0, 120), country = /^[A-Z]{2}$/.test(b.country ?? '') ? b.country : 'GB';
      if (!bank) return [400, { error: 'Choose a bank' }];
      const days = Math.max(1, Math.min(Number(b.days) || 90, 180));
      const state = randomUUID();
      db.data.bankPending = db.data.bankPending.filter((p) => Date.now() - p.at < 3600_000);
      db.data.bankPending.push({ state, owner: u.id, bank, country, renew: typeof b.renew === 'string' ? b.renew : undefined, at: Date.now() });
      db.save();
      const r = await call('POST', '/auth', { access: { valid_until: new Date(Date.now() + days * DAY).toISOString() }, aspsp: { name: bank, country }, state, redirect_url: redirect(), psu_type: b.psuType === 'personal' ? 'personal' : 'business' });
      return [200, { url: r.url }];
    },
    // The bank sends the person here after they approve (or say no). Opens without a sign-in: the one-time state ties it to them.
    'GET /bank/callback': async (_b, _u, { q }) => {
      const page = (code, t, x) => [code, html(t, x), { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' }];
      const p = db.data.bankPending.find((x) => x.state === q.get('state') && Date.now() - x.at < 3600_000);
      if (!p) return page(400, 'That link has run out', 'Start again from Hub > Finance > Business > Bank.');
      db.data.bankPending = db.data.bankPending.filter((x) => x !== p);
      if (q.get('error') || !q.get('code')) { db.save(); return page(200, 'Not connected', `Nothing was connected. ${esc(q.get('error_description') ?? '')}`); }
      try {
        const s = await call('POST', '/sessions', { code: q.get('code') });
        const old = p.renew ? db.data.bankLinks.find((l) => l.id === p.renew && l.owner === p.owner) : null;
        const link = old ?? { id: randomUUID(), owner: p.owner, bank: p.bank, country: p.country, created: Date.now(), accounts: [] };
        if (old && old.session !== s.session_id) await call('DELETE', `/sessions/${encodeURIComponent(old.session)}`).catch(() => {});
        link.session = s.session_id;
        link.validUntil = s.access?.valid_until ?? new Date(Date.now() + 90 * DAY).toISOString();
        link.error = null;
        // Keep each account's business when renewing (the bank gives new ids, so match on the account itself)
        link.accounts = (s.accounts ?? []).map((a) => {
          const key = keyOf(link, a);
          const was = link.accounts.find((x) => x.key === key);
          return { uid: a.uid, key, name: String(a.name ?? a.product ?? 'Account').slice(0, 60), tail: tail(a), currency: a.currency ?? 'GBP', biz: was?.biz ?? null, from: was?.from, last: was?.last, added: was?.added ?? 0 };
        });
        if (!old) db.data.bankLinks.push(link);
        db.save();
        log(`${stamp()} Bank feed: ${link.bank} ${old ? 'renewed' : 'connected'} (${link.accounts.length} account${link.accounts.length === 1 ? '' : 's'})`);
        if (old) void syncLink(link);
        return page(200, old ? 'Renewed' : 'Bank connected', old ? 'All set. Go back to the app.' : 'Now go back to Hub > Finance > Business > Bank and choose which business each account is for.');
      } catch (e) {
        db.save();
        log(`${stamp()} Bank feed: approval for ${p.bank} could not be finished (${e.status ?? 'no answer'})`);
        return page(502, 'Not connected', 'The bank service could not finish it. Try again in a minute.');
      }
    },
    // Which business an account feeds (only your own businesses), and from which day
    'POST /api/bank/assign': async (b, u) => {
      const link = mine(u).find((l) => l.id === b.link);
      const acc = link?.accounts.find((a) => a.key === b.account);
      if (!acc) return [404, { error: 'Not found' }];
      if (b.biz && b.biz !== 'personal' && !ownBiz(u, b.biz)) return [403, { error: 'Only a business you own can have a bank feed' }];
      const was = acc.biz;
      acc.biz = b.biz || null;
      if (typeof b.from === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(b.from)) acc.from = b.from;
      if (acc.biz !== was) acc.last = undefined;
      db.save();
      const added = acc.biz && ready().ok ? await syncLink(link) : 0;
      return [200, { added, link: view(link) }];
    },
    'POST /api/bank/sync': async (b, u) => {
      if (!ready().ok) return [503, { error: 'The bank connection is not set up on the PC yet', code: 'not-ready' }];
      let added = 0;
      for (const l of mine(u)) if (!b.link || l.id === b.link) added += await syncLink(l);
      return [200, { added, links: mine(u).map(view) }];
    },
    // Disconnect: the approval is ended at the bank too. What was brought in stays.
    'POST /api/bank/remove': async (b, u) => {
      const link = mine(u).find((l) => l.id === b.link);
      if (!link) return [404, { error: 'Not found' }];
      if (ready().ok && link.session) await call('DELETE', `/sessions/${encodeURIComponent(link.session)}`).catch(() => {});
      db.data.bankLinks = db.data.bankLinks.filter((l) => l !== link);
      db.save();
      log(`${stamp()} Bank feed: ${link.bank} disconnected`);
      return [200, { ok: true }];
    }
  };

  let iv = null, first = null;
  return {
    routes,
    syncAll,
    /** Every few hours while the server runs (only when it's set up on the PC) */
    start() {
      // Always ticking: banking can be set up later from Admin (each round does nothing until it's ready)
      const every = Math.max(1, Number(eb.pollHours) || 6) * 3600_000;
      first = setTimeout(() => void syncAll(), 60_000);
      iv = setInterval(() => void syncAll(), every);
      first.unref?.(); iv.unref?.();
    },
    stop() { clearTimeout(first); clearInterval(iv); }
  };
}
