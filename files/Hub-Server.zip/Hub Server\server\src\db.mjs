// Small JSON database with atomic writes and a copy each day in the backup folder (last `keep` days kept).
// Plenty for a family; swap for SQLite/Postgres behind the same functions if it ever grows.
import {
  mkdirSync, readFileSync, writeFileSync, renameSync, existsSync, readdirSync, unlinkSync, statSync,
  openSync, writeSync, fsyncSync, closeSync
} from 'node:fs';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { hostname } from 'node:os';

export const DB_VERSION = 3;
const EMPTY = () => ({
  version: DB_VERSION, seq: 0, users: {}, tokens: {}, recs: {}, links: [], messages: [],
  server: null, settings: {}, roles: {}, events: [], errors: [], friends: [], stats: {}
});
export const DEFAULT_SETTINGS = { passwordMin: 6, securityLevel: 'home', sessionDays: 365 };
/** Roles are data, so more can be added later without code changes elsewhere. */
export const DEFAULT_ROLES = { owner: { label: 'Owner', admin: true }, user: { label: 'User', admin: false } };

const stamp = () => new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
const slug = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9._-]+/g, '').slice(0, 32);

/** Brings an older database up to date. Never drops a user, a password hash or a record. */
export function migrate(input) {
  const data = { ...EMPTY(), ...input };
  if ((input.version ?? 1) < 2) {
    // 1 -> 2: accounts get usernames and roles (the oldest account becomes the owner)
    const taken = new Set();
    const users = Object.values(data.users).sort((a, b) => (a.created ?? 0) - (b.created ?? 0));
    const hasOwner = users.some((u) => u.role === 'owner');
    users.forEach((u, i) => {
      if (!u.username) {
        let base = slug(u.name) || slug(String(u.email ?? '').split('@')[0]) || 'user';
        if (base.length < 2) base = `${base}u`;
        let name = base, n = 2;
        while (taken.has(name) || users.some((o) => o !== u && o.username === name)) name = `${base}${n++}`;
        u.username = name;
      }
      taken.add(u.username);
      u.role ??= !hasOwner && i === 0 ? 'owner' : 'user';
    });
  }
  if ((input.version ?? 1) < 3 && data.settings?.passwordMin === 7) {
    // 2 -> 3: the shortest password is 6 (Kaiden, 2026-11-08; was 7). A minimum the owner changed stays as it is.
    data.settings = { ...data.settings, passwordMin: 6 };
  }
  data.version = DB_VERSION;
  data.server ??= { id: randomUUID(), name: `${hostname() || 'Home'} server`, created: Date.now() };
  data.settings = { ...DEFAULT_SETTINGS, ...data.settings };
  data.roles = { ...DEFAULT_ROLES, ...data.roles };
  data.friends = Array.isArray(data.friends) ? data.friends : [];
  data.stats = data.stats && typeof data.stats === 'object' ? data.stats : {};
  return data;
}

/** Writes and flushes to the disk before returning, so a sudden power-off can't leave a file of zeros
 * (that happened on 2026-11-10: db.json was all zeros after a restart and the server couldn't start). */
function writeDurable(path, text) {
  const fd = openSync(path, 'w');
  try { writeSync(fd, text); fsyncSync(fd); } finally { closeSync(fd); }
}

/** Reads a database file; null if it is missing, empty, zeros or not valid JSON. */
function readJson(path) {
  try {
    const text = readFileSync(path, 'utf8');
    if (!text.replace(/[\s\0]/g, '')) return null;
    const v = JSON.parse(text);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : null;
  } catch { return null; }
}

export function openDb(dir, { backupDir = join(dir, 'backups'), keep = 30 } = {}) {
  mkdirSync(dir, { recursive: true });
  mkdirSync(backupDir, { recursive: true });
  const file = join(dir, 'db.json');
  let raw = existsSync(file) ? readJson(file) : EMPTY();
  if (!raw) {
    // Damaged file: keep it aside, then start from the newest backup that reads, instead of not starting at all
    const broken = `db-broken-${stamp()}.json`;
    renameSync(file, join(backupDir, broken));
    const copies = readdirSync(backupDir).filter((f) => /^db-[\w-]+\.json$/.test(f) && f !== broken)
      .map((name) => ({ name, time: statSync(join(backupDir, name)).mtimeMs })).sort((a, b) => b.time - a.time);
    const good = copies.find((c) => (raw = readJson(join(backupDir, c.name))));
    if (!good) raw = EMPTY();
    console.error(`db.json could not be read (kept as ${broken}); started from ${good ? good.name : 'an empty database'}.`);
    writeDurable(file, JSON.stringify(raw));
  }
  if (existsSync(file) && (raw.version ?? 1) < DB_VERSION) {
    // Keep the old file as it was before changing its shape: this is what a roll back restores
    writeFileSync(join(backupDir, `db-before-v${DB_VERSION}-${stamp()}.json`), JSON.stringify(raw));
  }
  let data = migrate(raw);
  let timer = null;

  function saveNow() {
    clearTimeout(timer); timer = null;
    const tmp = file + '.tmp';
    writeDurable(tmp, JSON.stringify(data));
    renameSync(tmp, file);
    const day = new Date().toISOString().slice(0, 10);
    const bk = join(backupDir, `db-${day}.json`);
    if (!existsSync(bk)) {
      writeDurable(bk, JSON.stringify(data));
      const all = readdirSync(backupDir).filter((f) => /^db-\d{4}-\d\d-\d\d\.json$/.test(f)).sort();
      for (const f of all.slice(0, -keep)) unlinkSync(join(backupDir, f));
    }
  }
  const isBackup = (f) => /^db-[\w-]+\.json$/.test(f);
  return {
    get data() { return data; },
    save() { if (!timer) timer = setTimeout(saveNow, 200); },
    saveNow,
    nextSeq() { return ++data.seq; },
    /** Every copy in the backup folder, newest first. */
    backups() {
      return readdirSync(backupDir).filter(isBackup).map((name) => {
        const st = statSync(join(backupDir, name));
        return { name, size: st.size, time: st.mtimeMs };
      }).sort((a, b) => b.time - a.time);
    },
    /** A copy now (kept apart from the daily ones; the newest 20 are kept). */
    backupNow() {
      saveNow();
      const name = `db-manual-${stamp()}.json`;
      writeFileSync(join(backupDir, name), JSON.stringify(data));
      const manual = readdirSync(backupDir).filter((f) => f.startsWith('db-manual-')).sort();
      for (const f of manual.slice(0, -20)) unlinkSync(join(backupDir, f));
      return name;
    },
    backupPath(name) { return isBackup(name) ? join(backupDir, name) : null; },
    /** Roll back to a backup. What is here now is saved first, so the roll back can itself be undone. */
    restore(name) {
      if (!isBackup(name) || !existsSync(join(backupDir, name))) throw new Error('No such backup');
      const incoming = JSON.parse(readFileSync(join(backupDir, name), 'utf8'));
      writeFileSync(join(backupDir, `db-before-restore-${stamp()}.json`), JSON.stringify(data));
      data = migrate(incoming);
      saveNow();
    },
    file
  };
}
