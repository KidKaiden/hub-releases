const VERSION = "0.12.0+2026-11-13T07:31:38.112Z";
const FILES = ["./","index.html","assets/fredoka-hebrew-500-normal-C-43HJEL.woff2","assets/fredoka-latin-500-normal-BpYxueJ9.woff2","assets/fredoka-hebrew-500-normal-BkmgaUC6.woff","assets/fredoka-latin-500-normal-CFGu1_I7.woff","assets/index-DfbcVeWP.css","assets/App-CnVNd61G.css","assets/App-CwdBVQK1.css","assets/App-CPXhXjJ-.css","assets/App-DacoR-Ap.css","assets/App-Cnx5RyNj.css","assets/App-C-7-t2oU.css","assets/index-KcqXv4rJ.js","assets/index-BmIIH34L.js","assets/index-1U05ovq-.js","assets/sample-BKllv2a7.js","assets/App-BY5dNrwm.js","assets/model-8Piq1tKp.js","assets/App-C4yo7pwF.js","assets/App-DVDsN4Pa.js","assets/App-B7KLBI8f.js","assets/App-Bf7U5Avc.js","assets/App-DkUPR9co.js","assets/clone-BzwFlkN9.js","assets/web-COlVCeDC.js","assets/rfb-CxsXsMUX.js","apple-touch-icon.png","icon.svg","manifest.webmanifest"];
// Hub's service worker, for the web Hub (mainly the iPhone Home Screen app). Browsers only run it on https (the
// outside link) or on the PC itself, never on the plain home address.
//  - Keeps a copy of the app, so Hub opens with your last saved data while the PC is off or out of reach.
//    The page is fetched fresh whenever the server answers, so updates arrive as usual; the copy is the fallback.
//  - Shows notifications pushed by your server (Web Push), and opens the right page when one is tapped.
// The build (vite.config.ts) writes VERSION and FILES (every file of this version) above this line.
const CACHE = `hub-${VERSION}`;
const at = (f) => new URL(f, self.registration.scope).href;
const PAGE = at('./');
// Never from the copy: your data and sign-in (/api), updates, downloads and the version check
const LIVE = /\/(api|updates|phone)(\/|$)|\/(version\.json|sw\.js)$/;
const SLOW_MS = 5000;

self.addEventListener('install', (e) => {
  self.skipWaiting();
  // One missing file must not stop the rest, so each is added on its own
  e.waitUntil(caches.open(CACHE).then((c) => Promise.allSettled(FILES.map((f) => c.add(new Request(at(f), { cache: 'reload' }))))));
});

self.addEventListener('activate', (e) => e.waitUntil((async () => {
  for (const k of await caches.keys()) if (k.startsWith('hub-') && k !== CACHE) await caches.delete(k);
  await self.clients.claim();
})()));

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (!FILES.length || req.method !== 'GET') return; // the dev server's worker keeps nothing
  const url = new URL(req.url);
  if (url.origin !== self.location.origin || LIVE.test(url.pathname)) return;
  if (req.mode === 'navigate') {
    const fresh = fetch(req).then(async (res) => {
      if (res.ok && !res.redirected) await (await caches.open(CACHE)).put(PAGE, res.clone());
      return res;
    });
    e.waitUntil(fresh.then(() => {}, () => {})); // the fresh page still replaces the copy if it comes late
    e.respondWith(page(fresh));
  } else {
    e.respondWith(file(req));
  }
});

// The page: fresh from the server if it answers within a few seconds, otherwise the copy
async function page(fresh) {
  const copy = () => caches.open(CACHE).then((c) => c.match(PAGE));
  try {
    const res = await Promise.race([fresh, new Promise((_, no) => setTimeout(() => no(new Error('slow')), SLOW_MS))]);
    if (res.ok) return res;
    return (await copy()) || res; // the PC is off: Tailscale answers with an error page
  } catch {
    return (await copy()) || fresh.catch(() => Response.error());
  }
}

// The app's files (their names change with every version): the copy first, else the server (and keep it)
async function file(req) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res.ok && res.type === 'basic') await cache.put(req, res.clone());
  return res;
}

self.addEventListener('push', (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch { d = { body: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.title || 'Hub', {
    body: d.body || '',
    tag: d.tag || undefined,
    icon: 'apple-touch-icon.png',
    badge: 'icon.svg',
    data: { route: d.route || '' }
  }));
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const route = (e.notification.data && e.notification.data.route) || '';
  const url = new URL(route ? `./#/${route}` : './', self.registration.scope).href;
  e.waitUntil((async () => {
    const list = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of list) {
      if ('focus' in c) { if (route && 'navigate' in c) await c.navigate(url).catch(() => {}); return c.focus(); }
    }
    return self.clients.openWindow(url);
  })());
});
