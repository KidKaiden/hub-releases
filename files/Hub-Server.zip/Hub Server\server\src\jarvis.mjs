// JARVIS, the Hub's command-centre skin (plans/trading-lab/PLAN.md, slice 5): what the PC server tells it. Read-only and
// real: the PC's own load (processor, memory, the data disk), what this account opens most, its jobs and recent activity,
// the trading lab, and, for the owner, the trading account, the Simulator's upload queue and the AI models. Nothing here
// changes anything, and a source that isn't there says so (null), never a made-up number.
import os from 'node:os';
import { statfsSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const DAY = 86_400_000;
const OLLAMA = 'http://127.0.0.1:11434';

export function jarvis(ctx, { trading, lab, poster, ai, jobs }) {
  const { db, cfg } = ctx;
  const isOwner = (u) => !!db.data.roles?.[u.role]?.admin;

  // ---- The processor's load: the share of time not idle since the last look (the first look waits a moment) ----
  const times = () => os.cpus().reduce((a, c) => { const t = c.times; a.idle += t.idle; a.all += t.user + t.nice + t.sys + t.idle + t.irq; return a; }, { idle: 0, all: 0 });
  let last = times();
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  async function cpu() {
    let now = times();
    if (now.all - last.all < 1) { await wait(250); now = times(); }
    const d = now.all - last.all, busy = d > 0 ? 1 - (now.idle - last.idle) / d : 0;
    last = now;
    return Math.round(Math.max(0, Math.min(1, busy)) * 100);
  }
  function disk() {
    try { const s = statfsSync(cfg.dataDir); const total = s.blocks * s.bsize, free = s.bavail * s.bsize; return { used: total - free, total }; }
    catch { return null; }
  }
  // ---- Local models (free, through Ollama on this PC): running, and which models it has ----
  let models = { at: 0, v: null };
  async function ollama() {
    if (Date.now() - models.at < 60_000) return models.v;
    let v = { installed: false, running: false, models: [] };
    const exe = join(process.env.LOCALAPPDATA ?? '', 'Programs', 'Ollama', 'ollama.exe');
    v.installed = !!process.env.LOCALAPPDATA && existsSync(exe);
    try {
      const r = await fetch(`${OLLAMA}/api/tags`, { signal: AbortSignal.timeout(800) });
      if (r.ok) { const j = await r.json(); v = { installed: true, running: true, models: (j.models ?? []).map((m) => String(m.name)).slice(0, 12) }; }
    } catch { /* not running */ }
    models = { at: Date.now(), v };
    return v;
  }

  /** What this account opened most in the last 30 days (from the sign-in history every device sends) */
  function uses(u) {
    const since = Date.now() - 30 * DAY, n = {};
    for (let i = db.data.events.length - 1; i >= 0; i--) {
      const e = db.data.events[i];
      if (e.t < since) break;
      if (e.user === u.id && e.kind === 'open' && e.app) n[e.app] = (n[e.app] ?? 0) + 1;
    }
    return Object.entries(n).map(([app, opens]) => ({ app, opens })).sort((a, b) => b.opens - a.opens).slice(0, 8);
  }
  /** This account's own recent activity, newest first (what happened, never the contents) */
  function feed(u) {
    const out = [];
    for (let i = db.data.events.length - 1; i >= 0 && out.length < 24; i--) {
      const e = db.data.events[i];
      if (e.user === u.id) out.push({ t: e.t, kind: e.kind, what: e.what, app: e.app ?? null, device: e.device ?? null });
    }
    return out;
  }
  function uploads() {
    const items = poster.info().items, c = { waiting: 0, sending: 0, failed: 0, posted: 0 };
    let next = null;
    for (const it of items) for (const r of Object.values(it.res ?? {})) {
      if (['queued', 'ready'].includes(r.state)) { c.waiting++; next ??= it.label; }
      else if (['sending', 'uploading'].includes(r.state)) c.sending++;
      else if (['error', 'broken'].includes(r.state)) c.failed++;
      else if (['sent', 'done'].includes(r.state)) c.posted++;
    }
    return { ...c, next };
  }
  function tradeView() {
    const v = trading.view();
    return { connected: v.connected.paper || v.connected.live, mode: v.mode, auto: v.auto, killed: v.killed, locked: v.locked,
      equity: v.account?.equity ?? null, dayStart: v.day?.startEquity ?? null, waiting: v.queue.filter((q) => q.status === 'waiting').length,
      paperDays: v.paperDays, provenDays: v.provenDays, signals: v.signals.filter((s) => s.signal).map((s) => ({ symbol: s.symbol, signal: s.signal })) };
  }
  function labView(u) {
    const v = lab.view(u.id), run = v.runs.find((r) => !r.dry) ?? v.runs[0] ?? null, job = v.jobs.find((j) => ['queued', 'running', 'waiting'].includes(j.state)) ?? null;
    return { key: v.key, job: job && { label: job.label, state: job.state, stage: job.progress?.stage ?? null, done: job.progress?.done ?? null, total: job.progress?.total ?? null },
      last: run && { at: run.finished, dry: run.dry, tested: run.counts.tested, passed: run.counts.passed, hiddenYear: run.split.hidden_year, best: run.best[0]?.id ?? null } };
  }

  const routes = {
    'GET /api/jarvis': async (_b, u) => {
      const owner = isOwner(u), [load, llm] = await Promise.all([cpu(), owner ? ollama() : null]);
      const mem = { used: os.totalmem() - os.freemem(), total: os.totalmem() };
      return [200, {
        at: Date.now(),
        pc: { cpu: load, cores: os.cpus().length, mem, disk: disk(), up: os.uptime() * 1000, server: process.uptime() * 1000 },
        uses: uses(u), feed: feed(u),
        jobs: jobs.list(u.id).slice(-8).reverse().map((j) => ({ id: j.id, label: j.label, state: j.state, at: j.at, end: j.end ?? null, stage: j.progress?.stage ?? null, done: j.progress?.done ?? null, total: j.progress?.total ?? null })),
        lab: labView(u),
        // the owner's own: his trading account, the Simulator's uploads, the AI models and the server's errors
        trading: owner ? tradeView() : null,
        uploads: owner ? uploads() : null,
        models: owner ? { claude: ai.ready(), ollama: llm } : null,
        errors24h: owner ? db.data.errors.filter((e) => Date.now() - e.t < DAY).length : null
      }];
    }
  };
  return { routes };
}
