// The Simulator's publisher (plans/simulator/PUBLISH.md). Owner only, on the PC that runs the server.
// The app renders the videos and sends each one here in chunks (the server only takes small JSON bodies). Here they wait in a
// queue with their title, description and tags, and go out at the times the owner chose, one after another, in order:
//   YouTube (and Shorts): YouTube's own upload API, signed in once with Google's "device" flow (a code typed at google.com/device).
//   Instagram Reels: Instagram's own API when the owner has put in their token (vertical videos only).
//   Or, for any of them, a real browser signed in as the owner (webposter.mjs): no developer account, keys or approval needed. The owner signs in\n//   once in a normal window; after that the server opens that profile, uploads, types the caption and presses post.\n//   Anything not connected either way goes to the "Ready to post" folder, video and caption side by side.
// Rules it keeps: a video goes out only when it is due, when every earlier video of its tournament has gone, and when the
// platform's daily limit has room. A failed one holds the rest of its tournament (so the order is never broken) until the owner
// retries it or skips it. Keys live in the Keys folder (db.keys.writeSecret), are never logged and never sent back to an app.
// *[To test]* the YouTube and Instagram calls follow Google's and Meta's published flows and need the owner's real accounts.
import { copyFileSync, existsSync, mkdirSync, openSync, closeSync, readSync, readFileSync, rmSync, statSync, writeFileSync, appendFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { webPoster, WEB_PLATFORMS } from './webposter.mjs';

const PLATFORMS = ['youtube', 'instagram', 'tiktok', 'facebook'];
// Daily limits (from memory, the owner can change them: YouTube's free upload quota allows about 6 a day until Google raises it)
export const DEFAULT_CAPS = { youtube: 6, instagram: 10, tiktok: 10, facebook: 10 }; // (browser posting is kept gentle on purpose)
export const DEFAULT_TEMPLATES = {
  youtube: { title: '{piece} | {title}', description: '{piece}\n{fighters}\n\n{hashtags}' },
  instagram: { title: '{piece}', description: '{piece}\n{fighters}\n{hashtags}' },
  tiktok: { title: '{piece}', description: '{piece} {fighters} {hashtags}' },
  facebook: { title: '{piece}', description: '{title}\n{piece}: {fighters}\n{hashtags}' }
};
/** Who can see a post: public (everyone), followers (TikTok: followers; YouTube: unlisted) or private (only the owner). Only TikTok and YouTube
 *  are set by the app; Instagram and Facebook use what the account does by itself. */
export const VISIBILITIES = ['public', 'followers', 'private'];
export const VISIBILITY_PLATFORMS = ['tiktok', 'youtube'];
export const DEFAULT_VISIBILITY = { tiktok: 'public', youtube: 'public' };
const YT_PRIVACY = { public: 'public', followers: 'unlisted', private: 'private' };
const cleanVis = (v, base = DEFAULT_VISIBILITY) => Object.fromEntries(VISIBILITY_PLATFORMS.map((p) => [p, VISIBILITIES.includes(v?.[p]) ? v[p] : base[p]]));
/** Ready-made post presets (the owner can add, change and delete their own; these only start the list) */
const starterPresets = () => [
  { id: 'public', name: 'Public everywhere', visibility: { tiktok: 'public', youtube: 'public' } },
  { id: 'followers', name: 'Followers only', visibility: { tiktok: 'followers', youtube: 'followers' } },
  { id: 'private', name: 'Only me (test run)', visibility: { tiktok: 'private', youtube: 'private' } }
];
const GRAPH = 'https://graph.instagram.com/v21.0';
const GOOGLE = { device: 'https://oauth2.googleapis.com/device/code', token: 'https://oauth2.googleapis.com/token', upload: 'https://www.googleapis.com/upload/youtube/v3/videos' };
const CHUNK = 8 * 1024 * 1024; // YouTube takes the file in pieces of a multiple of 256 KiB
const MAX_FILE = 4 * 1024 * 1024 * 1024;
const PART = 3 * 1024 * 1024; // the app sends the file in parts of about 3 MB (base64 makes it 4 MB, under the 6 MB body limit)

/**
 * The times a set of videos should go out. Pure, so it can be tested without a clock.
 * items: in running order. opts.mode: 'now' (this minute, then every 5 minutes), 'gap' (startAt, then every gapMin minutes, or
 * the owner's own gaps), 'daily' (as many a day as the smallest limit allows, evenly spread).
 */
export function planTimes(items, opts = {}) {
  const now = opts.now ?? Date.now(), caps = { ...DEFAULT_CAPS, ...(opts.caps ?? {}) };
  const out = []; let at;
  if (opts.mode === 'same') { at = Math.max(now, Number(opts.startAt) || now); return items.map(() => at); } // all at the same time (each set still goes out in its order)
  if (opts.mode === 'now') { at = now; for (let i = 0; i < items.length; i++) { out.push(at); at += (opts.gapMin ?? 5) * 60_000; } return out; }
  at = Math.max(now, Number(opts.startAt) || now);
  const gaps = Array.isArray(opts.gaps) ? opts.gaps.map((g) => Math.max(1, Number(g) || 0)) : null;
  for (let i = 0; i < items.length; i++) {
    if (i > 0) {
      let gapMin = opts.gapMin ?? 120;
      if (opts.mode === 'daily') { const per = Math.min(...(items[i].platforms?.length ? items[i].platforms : PLATFORMS).map((p) => caps[p] ?? 6)); gapMin = (24 * 60) / Math.max(1, per); }
      else if (gaps) gapMin = gaps[Math.min(i - 1, gaps.length - 1)] ?? gapMin;
      at += gapMin * 60_000;
    }
    out.push(at);
  }
  return out;
}

export function publisher(ctx, impl = {}) {
  const { db, cfg, log, stamp } = ctx;
  const home = impl.dir ?? cfg.publisher?.dir ?? resolve(cfg.dataDir, '..', 'Publisher');
  const media = join(home, 'media');
  const ready = join(home, 'Ready to post');
  const stateFile = join(home, 'state.json');
  const keysDir = () => cfg.keysDir || resolve(cfg.dataDir, '..', 'Keys');
  const keyFile = join(keysDir(), 'publisher-keys.json');
  const doFetch = impl.fetch ?? fetch;
  const wait = impl.wait ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
  const isAdmin = (u) => !!db.data.roles?.[u.role]?.admin;
  const owner = (fn) => (b, u, meta) => (isAdmin(u) ? fn(b, u, meta) : [403, { error: 'Only the owner can do this', code: 'owner' }]);

  // ---------- state ----------
  let state = { items: [], settings: { caps: { ...DEFAULT_CAPS }, templates: structuredClone(DEFAULT_TEMPLATES), privacy: 'public', visibility: { ...DEFAULT_VISIBILITY }, preset: '', presets: starterPresets(), hashtags: '#neonarrows #arrows #simulation' } };
  try {
    const s = JSON.parse(readFileSync(stateFile, 'utf8')); state = { ...state, ...s, settings: { ...state.settings, ...(s.settings ?? {}) } };
    // older state: YouTube's one privacy choice becomes its visibility
    if (!s.settings?.visibility && ['public', 'unlisted', 'private'].includes(s.settings?.privacy)) state.settings.visibility.youtube = s.settings.privacy === 'unlisted' ? 'followers' : s.settings.privacy;
  } catch { /* first time */ }
  state.settings.visibility = cleanVis(state.settings.visibility);
  /** How a video should be seen on a platform right now (the setting, or the owner's own choice for that one video) */
  const visOf = (it, platform) => (VISIBILITIES.includes(it?.visibility?.[platform]) ? it.visibility[platform] : state.settings.visibility[platform] ?? 'public');
  for (const it of state.items) for (const p of Object.values(it.res ?? {})) if (p.state === 'sending') p.state = 'queued'; // the server restarted mid-upload: it will try again
  for (const it of state.items) if (it.state === 'uploading' && !it.finished) it.state = 'broken';
  let saveT = null;
  const saveNow = () => { try { mkdirSync(home, { recursive: true }); writeFileSync(stateFile, JSON.stringify(state)); } catch (e) { log(`${stamp()} Publisher: could not save its state (${e.message})`); } };
  const save = () => { clearTimeout(saveT); saveT = setTimeout(saveNow, 300); saveT.unref?.(); };
  const newId = () => `p${Date.now().toString(36)}${Math.floor(Math.random() * 1e5).toString(36)}`;
  const fileOf = (id) => join(media, `${id}.mp4`);

  // ---------- keys ----------
  const readKeys = () => { try { return existsSync(keyFile) ? JSON.parse(db.keys ? db.keys.readSecret(keyFile) : readFileSync(keyFile, 'utf8')) : {}; } catch { return {}; } };
  const writeKeys = (k) => { mkdirSync(keysDir(), { recursive: true }); const s = JSON.stringify(k); if (db.keys) db.keys.writeSecret(keyFile, s); else writeFileSync(keyFile, s, { mode: 0o600 }); };
  const web = webPoster({ dir: home, browserPath: cfg.publisher?.browser, log: (m) => log(`${stamp()} ${m}`), impl: impl.web ?? {} });
  const accounts = () => { const k = readKeys(), w = web.status(); return { youtube: { keys: !!(k.googleId && k.googleSecret), connected: !!k.googleRefresh }, instagram: { keys: !!(k.igUser && k.igToken) }, tiktok: { folder: true }, facebook: { folder: true }, web: { available: web.available(), ...w } }; };
  /** How a video goes to a platform now: 'api' (the platform's own keys), 'web' (a signed-in browser) or 'folder' (Ready to post) */
  const way = (platform, it) => {
    const a = accounts();
    if (platform === 'youtube') return a.youtube.connected ? 'api' : a.web.youtube.connected ? 'web' : 'folder';
    if (platform === 'instagram') return a.instagram.keys && it.format === 'vertical' ? 'api' : a.web.instagram.connected ? 'web' : 'folder';
    return a.web[platform]?.connected ? 'web' : 'folder';
  };
  let access = null; // { token, until }
  let device = null; // the sign-in in progress: { userCode, url, deviceCode, interval, until, error }

  // ---------- YouTube ----------
  async function accessToken() {
    if (access && access.until > Date.now() + 60_000) return access.token;
    const k = readKeys();
    if (!(k.googleId && k.googleSecret && k.googleRefresh)) throw new Error('YouTube is not connected yet (Publish > Accounts)');
    const r = await doFetch(GOOGLE.token, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: k.googleId, client_secret: k.googleSecret, refresh_token: k.googleRefresh, grant_type: 'refresh_token' }) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.access_token) throw new Error(`Google would not sign in: ${j.error_description ?? j.error ?? r.status}. Connect YouTube again`);
    access = { token: j.access_token, until: Date.now() + (Number(j.expires_in) || 3000) * 1000 };
    return access.token;
  }
  /** A Short: a vertical clip of up to 3 minutes that was not set to go as a normal video. (Wide clips are always normal videos. YouTube itself still shows any vertical clip of 3 minutes or less as a Short, whatever we say.) */
  const isShort = (it) => it.format === 'vertical' && (it.seconds ?? 0) <= 180 && !it.asVideo;
  async function toYouTube(it, path) {
    const token = await accessToken();
    const size = statSync(path).size;
    // YouTube treats a vertical video of up to 3 minutes with #Shorts in it as a Short
    const short = isShort(it);
    const cap = it.captions?.youtube ?? { title: it.title, description: it.description };
    const description = short && !/#shorts/i.test(cap.description + cap.title) ? `${cap.description}\n#Shorts`.trim() : cap.description;
    const meta = { snippet: { title: String(cap.title).slice(0, 100), description: String(description).slice(0, 5000), tags: (it.tags ?? []).slice(0, 20), categoryId: '20' }, status: { privacyStatus: YT_PRIVACY[visOf(it, 'youtube')], selfDeclaredMadeForKids: false } };
    const start = await doFetch(`${GOOGLE.upload}?uploadType=resumable&part=snippet,status`, { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json; charset=UTF-8', 'x-upload-content-type': 'video/mp4', 'x-upload-content-length': String(size) }, body: JSON.stringify(meta) });
    if (!start.ok) { const e = await start.json().catch(() => ({})); throw new Error(`YouTube said no: ${e.error?.message ?? start.status}`); }
    const session = start.headers.get('location');
    if (!session) throw new Error('YouTube gave no upload address');
    const fd = openSync(path, 'r');
    try {
      for (let off = 0; off < size; off += CHUNK) {
        const len = Math.min(CHUNK, size - off), buf = Buffer.alloc(len); readSync(fd, buf, 0, len, off);
        const r = await doFetch(session, { method: 'PUT', headers: { 'content-length': String(len), 'content-range': `bytes ${off}-${off + len - 1}/${size}` }, body: buf });
        if (r.status === 308) continue;
        if (r.ok) { const v = await r.json().catch(() => ({})); return { id: v.id, url: v.id ? `https://youtu.be/${v.id}` : '' }; }
        const e = await r.json().catch(() => ({})); throw new Error(`YouTube stopped the upload: ${e.error?.message ?? r.status}`);
      }
    } finally { closeSync(fd); }
    throw new Error('YouTube never confirmed the upload');
  }

  // ---------- Instagram Reels (same flow as Clipper's poster) ----------
  async function toInstagram(it, path) {
    const k = readKeys();
    const cap = it.captions?.instagram ?? { description: it.description };
    const j = async (r) => { const x = await r.json().catch(() => ({})); if (!r.ok || x.error) throw new Error(x.error?.message ?? `Instagram said ${r.status}`); return x; };
    const size = statSync(path).size;
    const c = await j(await doFetch(`${GRAPH}/${k.igUser}/media`, { method: 'POST', headers: { authorization: `Bearer ${k.igToken}`, 'content-type': 'application/json' }, body: JSON.stringify({ media_type: 'REELS', upload_type: 'resumable', caption: String(cap.description).slice(0, 2200) }) }));
    await j(await doFetch(c.uri ?? `https://rupload.facebook.com/ig-api-upload/v21.0/${c.id}`, { method: 'POST', headers: { authorization: `OAuth ${k.igToken}`, offset: '0', file_size: String(size) }, body: readFileSync(path) }));
    for (let i = 0; i < 60; i++) {
      const s = await j(await doFetch(`${GRAPH}/${c.id}?fields=status_code`, { headers: { authorization: `Bearer ${k.igToken}` } }));
      if (s.status_code === 'FINISHED') break;
      if (s.status_code === 'ERROR' || s.status_code === 'EXPIRED') throw new Error('Instagram could not process the video');
      await wait(5000);
    }
    const pub = await j(await doFetch(`${GRAPH}/${k.igUser}/media_publish`, { method: 'POST', headers: { authorization: `Bearer ${k.igToken}`, 'content-type': 'application/json' }, body: JSON.stringify({ creation_id: c.id }) }));
    return { id: pub.id, url: '' };
  }

  // ---------- a signed-in browser (see webposter.mjs) ----------
  async function toWeb(it, platform, path) {
    const cap = it.captions?.[platform] ?? { title: it.title, description: it.description };
    let description = String(cap.description ?? '');
    if (platform === 'youtube' && isShort(it) && !/#shorts/i.test(description + cap.title)) description = `${description}\n#Shorts`.trim();
    return web.post(platform, { path, caption: (description || cap.title || '').slice(0, 2200), title: String(cap.title ?? ''), description, format: it.format, visibility: visOf(it, platform), privacy: YT_PRIVACY[visOf(it, platform)] });
  }

  // ---------- the "Ready to post" folder: the video and its caption side by side ----------
  function toFolder(it, platform, path) {
    const dir = join(ready, platform); mkdirSync(dir, { recursive: true });
    const cap = it.captions?.[platform] ?? { title: it.title, description: it.description };
    const base = `${String(it.order ?? 0).padStart(2, '0')} ${it.label} ${it.version ?? ''} ${it.id}`.replace(/[^\w .-]/g, '').replace(/\s+/g, ' ').trim();
    copyFileSync(path, join(dir, `${base}.mp4`));
    writeFileSync(join(dir, `${base}.txt`), `${cap.title}\n\n${cap.description}\n`);
    return join(dir, `${base}.mp4`);
  }

  // ---------- who may go now ----------
  const done = (p) => p && ['sent', 'ready', 'skipped'].includes(p.state);
  const sentLastDay = (platform, now) => state.items.reduce((n, it) => n + (it.res?.[platform]?.state === 'sent' && now - (it.res[platform].done ?? 0) < 86_400_000 ? 1 : 0), 0);
  /** Items of the same tournament and shape that come before this one in the running order */
  const earlier = (it) => state.items.filter((x) => x.group === it.group && x.format === it.format && x.version === it.version && (x.order ?? 0) < (it.order ?? 0));
  function blocked(it, platform) { return earlier(it).some((x) => x.platforms.includes(platform) && !done(x.res?.[platform])); }

  let busy = false;
  async function tick(now = Date.now()) {
    if (busy) return; busy = true;
    try {
      const list = state.items.filter((it) => it.state === 'queued').sort((a, b) => (a.at - b.at) || ((a.order ?? 0) - (b.order ?? 0)));
      for (const it of list) {
        if (it.at > now) continue;
        const path = fileOf(it.id);
        for (const platform of it.platforms) {
          const r = (it.res[platform] ??= { state: 'queued' });
          if (r.state !== 'queued') continue;
          if (blocked(it, platform)) continue;
          const cap = state.settings.caps[platform] ?? DEFAULT_CAPS[platform];
          const how = way(platform, it), direct = how !== 'folder';
          if (direct && sentLastDay(platform, now) >= cap) { r.note = `Waiting: ${platform} allows ${cap} a day and that many went in the last 24 hours`; continue; }
          r.state = 'sending'; r.note = ''; save();
          try {
            if (!existsSync(path)) throw new Error('The video file is gone from the server');
            if (how === 'web') { Object.assign(r, await toWeb(it, platform, path)); r.state = 'sent'; r.note = `Posted to ${platform} through the browser`; }
            else if (platform === 'youtube' && direct) { Object.assign(r, await toYouTube(it, path)); r.state = 'sent'; r.note = 'Uploaded to YouTube'; }
            else if (platform === 'instagram' && direct) { Object.assign(r, await toInstagram(it, path)); r.state = 'sent'; r.note = 'Posted to Instagram'; }
            else { r.folder = toFolder(it, platform, path); r.state = 'ready'; r.note = platform === 'youtube' ? 'YouTube is not connected: saved in the Ready to post folder' : 'Saved in the Ready to post folder, with its caption'; }
            r.done = Date.now(); log(`${stamp()} Publisher: ${r.note.toLowerCase()} (${it.label}, ${platform})`);
          } catch (e) { r.state = 'error'; r.note = String(e.message ?? e).slice(0, 220); log(`${stamp()} Publisher: ${platform} failed (${r.note})`); }
          save();
        }
        // when every platform is finished with this video, the file is freed
        if (it.platforms.every((p) => done(it.res[p]))) { it.state = 'done'; try { rmSync(path, { force: true }); } catch { /* gone */ } save(); }
        else if (it.platforms.some((p) => it.res[p]?.state === 'error')) it.state = it.platforms.every((p) => ['error', ...['sent', 'ready', 'skipped']].includes(it.res[p]?.state)) ? 'error' : it.state;
      }
    } finally { busy = false; }
  }
  const timer = impl.noTimer ? null : setInterval(() => tick(), 30_000);
  timer?.unref?.();

  // ---------- Google sign-in with a code (no web address needed) ----------
  async function pollDevice() {
    const d = device; if (!d || d.polling) return; d.polling = true;
    try {
      while (device === d && Date.now() < d.until) {
        await wait((impl.pollMs ?? d.interval * 1000));
        if (device !== d) return;
        const k = readKeys();
        const r = await doFetch(GOOGLE.token, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: k.googleId, client_secret: k.googleSecret, device_code: d.deviceCode, grant_type: 'urn:ietf:params:oauth:grant-type:device_code' }) });
        const j = await r.json().catch(() => ({}));
        if (j.refresh_token) { writeKeys({ ...readKeys(), googleRefresh: j.refresh_token }); access = null; d.done = true; log(`${stamp()} Publisher: YouTube connected`); return; }
        if (j.error === 'authorization_pending' || j.error === 'slow_down') { if (j.error === 'slow_down') d.interval += 5; continue; }
        d.error = j.error_description ?? j.error ?? 'Google said no'; return;
      }
      d.error = 'The code ran out. Start again';
    } finally { d.polling = false; }
  }

  // ---------- what an app is allowed to see ----------
  const viewItem = (it) => ({ id: it.id, group: it.group, order: it.order, label: it.label, kind: it.kind, format: it.format, version: it.version, seconds: it.seconds, title: it.title, description: it.description, tags: it.tags, captions: it.captions, visibility: it.visibility, asVideo: it.asVideo, platforms: it.platforms, at: it.at, state: it.state, size: it.size, added: it.added, res: Object.fromEntries(Object.entries(it.res ?? {}).map(([k, v]) => [k, { state: v.state, note: v.note, url: v.url, done: v.done }])) });
  const info = () => ({ accounts: accounts(), settings: state.settings, items: state.items.slice(-400).map(viewItem), folder: ready, device: device ? { userCode: device.userCode, url: device.url, error: device.error ?? '', done: !!device.done } : null, now: Date.now() });
  const cleanList = (a, n, w) => (Array.isArray(a) ? a : []).slice(0, n).map((x) => String(x).slice(0, w));

  const routes = (_o) => ({
    'GET /api/admin/publish': owner(() => [200, info()]),
    'POST /api/admin/publish/settings': owner((b) => {
      const s = state.settings;
      if (b.caps && typeof b.caps === 'object') for (const p of PLATFORMS) if (Number.isFinite(Number(b.caps[p]))) s.caps[p] = Math.max(1, Math.min(500, Math.floor(Number(b.caps[p]))));
      if (b.templates && typeof b.templates === 'object') for (const p of PLATFORMS) { const t = b.templates[p]; if (t && typeof t.title === 'string' && typeof t.description === 'string') s.templates[p] = { title: t.title.slice(0, 300), description: t.description.slice(0, 5000) }; }
      if (b.visibility && typeof b.visibility === 'object') s.visibility = cleanVis(b.visibility, s.visibility);
      else if (['public', 'unlisted', 'private'].includes(b.privacy)) s.visibility.youtube = b.privacy === 'unlisted' ? 'followers' : b.privacy;
      s.privacy = YT_PRIVACY[s.visibility.youtube];
      if (typeof b.hashtags === 'string') s.hashtags = b.hashtags.slice(0, 300);
      save(); return [200, info()];
    }),
    // Presets: the whole way posts go out (who sees them, hashtags, caption templates, daily limits) saved under a name
    'POST /api/admin/publish/presets/save': owner((b) => {
      const name = String(b.name ?? '').trim().slice(0, 60); if (!name) return [400, { error: 'Give the preset a name', field: 'name' }];
      const s = state.settings, snap = { name, visibility: { ...s.visibility }, hashtags: s.hashtags, templates: structuredClone(s.templates), caps: { ...s.caps } };
      const same = s.presets.find((p) => p.name.toLowerCase() === name.toLowerCase());
      if (same) Object.assign(same, snap); else s.presets.push({ id: newId(), ...snap });
      s.preset = (same ?? s.presets[s.presets.length - 1]).id; if (s.presets.length > 40) s.presets.shift();
      save(); return [200, info()];
    }),
    'POST /api/admin/publish/presets/apply': owner((b) => {
      const s = state.settings, p = s.presets.find((x) => x.id === b.id); if (!p) return [404, { error: 'That preset is gone' }];
      s.visibility = cleanVis(p.visibility, s.visibility); s.privacy = YT_PRIVACY[s.visibility.youtube];
      if (typeof p.hashtags === 'string') s.hashtags = p.hashtags;
      if (p.templates) for (const k of PLATFORMS) if (p.templates[k]) s.templates[k] = { ...p.templates[k] };
      if (p.caps) for (const k of PLATFORMS) if (Number.isFinite(Number(p.caps[k]))) s.caps[k] = Number(p.caps[k]);
      s.preset = p.id; save(); return [200, info()];
    }),
    'POST /api/admin/publish/presets/delete': owner((b) => {
      const s = state.settings; s.presets = s.presets.filter((x) => x.id !== b.id); if (s.preset === b.id) s.preset = ''; save(); return [200, info()];
    }),
    // Keys: only from this PC, and the owner is asked to confirm it is them (RISKY in app.mjs)
    'POST /api/admin/publish/keys': owner((b, u, meta) => {
      if (meta?.public) return [403, { error: 'Do this at home: keys never travel over the internet', code: 'home' }];
      const k = readKeys(), next = { ...k };
      for (const f of ['googleId', 'googleSecret', 'igUser', 'igToken']) {
        if (typeof b[f] === 'string' && b[f].trim()) { if (!/^[\w.:@=~/+-]{4,500}$/.test(b[f].trim())) return [400, { error: 'That key has a character a key never has. Copy it again', field: f }]; next[f] = b[f].trim(); }
      }
      if ((next.googleId !== k.googleId || next.googleSecret !== k.googleSecret)) delete next.googleRefresh; // new Google keys: sign in again
      writeKeys(next); access = null;
      log(`${stamp()} Publisher: keys saved by ${u.name} (kept in the Keys folder)`);
      return [200, info()];
    }),
    'POST /api/admin/publish/keys/remove': owner((b, u, meta) => {
      if (meta?.public) return [403, { error: 'Do this at home', code: 'home' }];
      const k = readKeys();
      const groups = { youtube: ['googleId', 'googleSecret', 'googleRefresh'], instagram: ['igUser', 'igToken'] };
      if (b.which === 'all') writeKeys({}); else { for (const f of groups[String(b.which)] ?? []) delete k[f]; writeKeys(k); }
      access = null; device = null;
      return [200, info()];
    }),
    // Browser posting: sign in once in a normal window on this PC, then the server posts for you
    'POST /api/admin/publish/web/connect': owner(async (b, u, meta) => {
      if (meta?.public) return [403, { error: 'Do this at the home PC', code: 'home' }];
      const p = String(b.platform);
      if (!WEB_PLATFORMS.includes(p)) return [400, { error: 'Unknown platform' }];
      if (!web.available()) return [400, { error: 'Edge or Chrome was not found on this PC' }];
      try { await web.connect(p); } catch (e) { return [400, { error: String(e.message ?? e) }]; }
      log(`${stamp()} Publisher: ${p} sign-in window opened by ${u.name}`);
      return [200, info()];
    }),
    'POST /api/admin/publish/web/disconnect': owner(async (b, u, meta) => {
      if (meta?.public) return [403, { error: 'Do this at home', code: 'home' }];
      const p = String(b.platform); if (!WEB_PLATFORMS.includes(p)) return [400, { error: 'Unknown platform' }];
      await web.disconnect(p); return [200, info()];
    }),
    'POST /api/admin/publish/youtube/connect': owner(async (b, u, meta) => {
      if (meta?.public) return [403, { error: 'Do this at home', code: 'home' }];
      const k = readKeys();
      if (!(k.googleId && k.googleSecret)) return [400, { error: 'Put in the Google client ID and secret first' }];
      const r = await doFetch(GOOGLE.device, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: k.googleId, scope: 'https://www.googleapis.com/auth/youtube' }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.device_code) return [400, { error: `Google would not start the sign-in: ${j.error_description ?? j.error ?? r.status}` }];
      device = { userCode: j.user_code, url: j.verification_url ?? 'https://www.google.com/device', deviceCode: j.device_code, interval: Number(j.interval) || 5, until: Date.now() + (Number(j.expires_in) || 1800) * 1000 };
      void pollDevice();
      return [200, info()];
    }),
    // A video arrives: first its details, then its parts, then "finished"
    'POST /api/admin/publish/new': owner((b) => {
      const size = Number(b.size) || 0;
      if (size <= 0 || size > MAX_FILE) return [400, { error: 'That video is empty or too big' }];
      const platforms = cleanList(b.platforms, 4, 12).filter((p) => PLATFORMS.includes(p));
      if (!platforms.length) return [400, { error: 'Choose where it should go' }];
      const id = newId();
      const caps = {}; if (b.captions && typeof b.captions === 'object') for (const p of PLATFORMS) { const c = b.captions[p]; if (c && typeof c.title === 'string') caps[p] = { title: c.title.slice(0, 300), description: String(c.description ?? '').slice(0, 5000) }; }
      const it = { id, group: String(b.group ?? 'x').slice(0, 60), order: Math.max(0, Math.min(999, Math.floor(Number(b.order) || 0))), label: String(b.label ?? 'Video').slice(0, 120), kind: String(b.kind ?? 'fight').slice(0, 12), format: b.format === 'pc' ? 'pc' : 'vertical', version: b.version === 'short' ? 'short' : 'long', seconds: Math.max(0, Number(b.seconds) || 0), title: String(b.title ?? b.label ?? 'Video').slice(0, 300), description: String(b.description ?? '').slice(0, 5000), tags: cleanList(b.tags, 20, 40), captions: caps, platforms, asVideo: b.asVideo === true && b.format !== 'pc' ? true : undefined, at: 0, state: 'uploading', size, got: 0, parts: 0, res: {}, added: Date.now(), finished: false };
      try { mkdirSync(media, { recursive: true }); writeFileSync(fileOf(id), Buffer.alloc(0)); } catch (e) { return [500, { error: `The server could not make room for it: ${e.message}` }]; }
      state.items.push(it); save();
      return [200, { id, part: PART }];
    }),
    'POST /api/admin/publish/chunk': owner((b) => {
      const it = state.items.find((x) => x.id === String(b.id) && x.state === 'uploading');
      if (!it) return [404, { error: 'That upload is not open' }];
      const data = Buffer.from(String(b.data ?? ''), 'base64');
      if (!data.length || data.length > PART + 1024) return [400, { error: 'A part is empty or too big' }];
      if (Number(b.n) !== it.parts) return [409, { error: 'A part is missing or came twice', expect: it.parts }];
      appendFileSync(fileOf(it.id), data); it.got += data.length; it.parts++;
      if (it.got > it.size) { rmSync(fileOf(it.id), { force: true }); state.items = state.items.filter((x) => x !== it); save(); return [400, { error: 'More data came than it said' }]; }
      return [200, { got: it.got }];
    }),
    'POST /api/admin/publish/finish': owner((b) => {
      const it = state.items.find((x) => x.id === String(b.id) && x.state === 'uploading');
      if (!it) return [404, { error: 'That upload is not open' }];
      if (it.got !== it.size) return [400, { error: `Only ${it.got} of ${it.size} bytes arrived. Send it again`, got: it.got }];
      it.state = 'queued'; it.finished = true; it.at = Number(b.at) || Date.now() + 365 * 86_400_000; // no time yet: it waits for a schedule
      it.unscheduled = !Number(b.at);
      for (const p of it.platforms) it.res[p] = { state: 'queued' };
      save(); return [200, info()];
    }),
    'POST /api/admin/publish/update': owner((b) => {
      const it = state.items.find((x) => x.id === String(b.id));
      if (!it) return [404, { error: 'That video is not in the queue' }];
      if (typeof b.title === 'string') it.title = b.title.slice(0, 300);
      if (typeof b.description === 'string') it.description = b.description.slice(0, 5000);
      if (Array.isArray(b.tags)) it.tags = cleanList(b.tags, 20, 40);
      if (b.captions && typeof b.captions === 'object') for (const p of PLATFORMS) { const c = b.captions[p]; if (c && typeof c.title === 'string') (it.captions ??= {})[p] = { title: c.title.slice(0, 300), description: String(c.description ?? '').slice(0, 5000) }; }
      if (b.visibility && typeof b.visibility === 'object') { // this video only; '' goes back to the setting
        const v = { ...(it.visibility ?? {}) };
        for (const p of VISIBILITY_PLATFORMS) if (p in b.visibility) { if (VISIBILITIES.includes(b.visibility[p])) v[p] = b.visibility[p]; else delete v[p]; }
        it.visibility = Object.keys(v).length ? v : undefined;
      }
      if (typeof b.asVideo === 'boolean') it.asVideo = b.asVideo && it.format === 'vertical' ? true : undefined; // only a vertical clip has the choice
      if (Number(b.at) > 0 && it.state === 'queued') { it.at = Number(b.at); it.unscheduled = false; }
      save(); return [200, info()];
    }),
    // Times for a set of videos, in the order given: right now (5 minutes apart), a gap in minutes, your own gaps, or the daily limit
    'POST /api/admin/publish/schedule': owner((b) => {
      const ids = cleanList(b.ids, 400, 40);
      const items = ids.map((id) => state.items.find((x) => x.id === id && x.state === 'queued')).filter(Boolean);
      if (!items.length) return [400, { error: 'Nothing to schedule' }];
      const mode = ['now', 'gap', 'daily', 'same'].includes(b.mode) ? b.mode : 'gap';
      const times = planTimes(items, { mode, startAt: Number(b.startAt) || 0, gapMin: Number(b.gapMin) > 0 ? Number(b.gapMin) : undefined, gaps: b.gaps, caps: state.settings.caps });
      items.forEach((it, i) => { it.at = times[i]; it.unscheduled = false; });
      save(); setImmediate(() => tick()); // anything already due goes now, not at the next half minute
      return [200, info()];
    }),
    'POST /api/admin/publish/cancel': owner((b) => {
      const it = state.items.find((x) => x.id === String(b.id));
      if (!it) return [404, { error: 'That video is not in the queue' }];
      if (Object.values(it.res ?? {}).some((p) => p.state === 'sending')) return [409, { error: 'It is uploading right now' }];
      try { rmSync(fileOf(it.id), { force: true }); } catch { /* gone */ }
      state.items = state.items.filter((x) => x !== it); save(); return [200, info()];
    }),
    'POST /api/admin/publish/retry': owner((b) => {
      const it = state.items.find((x) => x.id === String(b.id));
      if (!it) return [404, { error: 'That video is not in the queue' }];
      for (const p of it.platforms) if (it.res[p]?.state === 'error') it.res[p] = { state: 'queued' };
      if (it.state === 'error') it.state = 'queued';
      save(); setImmediate(() => tick()); return [200, info()];
    }),
    // Let the ones after it go (it is not posted)
    'POST /api/admin/publish/skip': owner((b) => {
      const it = state.items.find((x) => x.id === String(b.id));
      if (!it) return [404, { error: 'That video is not in the queue' }];
      for (const p of it.platforms) if (!done(it.res[p])) it.res[p] = { state: 'skipped', note: 'Skipped by you' };
      it.state = 'done'; try { rmSync(fileOf(it.id), { force: true }); } catch { /* gone */ }
      save(); setImmediate(() => tick()); return [200, info()];
    })
  });
  return { routes, tick, info, state: () => state, caps: () => state.settings.caps, stop() { clearInterval(timer); clearTimeout(saveT); saveNow(); device = null; web.stop(); }, web };
}
