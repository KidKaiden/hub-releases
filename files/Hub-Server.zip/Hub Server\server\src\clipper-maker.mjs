// Clipper's video maker (plans/clipper/PLAN.md, phase 5). An idea in, a finished vertical short out, all free, on this PC:
//   the Hub's AI writes the script and DRAWS each scene as 8-bit pixel art (a 32 x 32 grid of palette colours),
//   Windows' own voice reads it (a robot voice suits 8-bit), FFmpeg makes the pictures big and sharp, adds captions and a
//   chiptune, joins the scenes, and a quality gate checks the result isn't black, silent, too short or too long.
// A meme remix is the same with the meme (a picture) shown to the AI first: same joke shape, a fresh angle.
import { execFile } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { BGS, COLORS, FX, G, KINDS, POSES, PROPS, SPOTS, renderScene } from './clipper-art.mjs';

const run = (cmd, args, timeout = 10 * 60_000) => new Promise((ok) => execFile(cmd, args, { timeout, windowsHide: true, maxBuffer: 64 << 20 }, (e, out, err) => ok({ ok: !e, out: String(out ?? ''), err: String(err ?? e?.message ?? '') })));

const enumOf = (a) => ({ type: 'string', enum: a });
const HAIRS = ['black', 'brown', 'yellow', 'orange', 'red', 'white', 'purple', 'pink', 'blue', 'green', 'grey'];
const CAST = { type: 'object', additionalProperties: false, required: ['name', 'kind', 'shirt', 'hair'], properties: { name: { type: 'string' }, kind: enumOf(KINDS), shirt: enumOf(Object.keys(COLORS)), hair: enumOf(HAIRS) } };
const ACTOR = { type: 'object', additionalProperties: false, required: ['who', 'pose', 'at'], properties: { who: { type: 'string' }, pose: enumOf(POSES), at: enumOf(SPOTS) } };
const PROP = { type: 'object', additionalProperties: false, required: ['kind', 'at', 'color'], properties: { kind: enumOf(PROPS), at: enumOf(SPOTS), color: enumOf(Object.keys(COLORS)) } };
/** The shape the model must answer in: the server forces it, so the answer is always usable */
export const SCHEMA = {
  type: 'object', additionalProperties: false, required: ['title', 'caption', 'cast', 'scenes'],
  properties: {
    title: { type: 'string' }, caption: { type: 'string' },
    cast: { type: 'array', minItems: 1, maxItems: 3, items: CAST },
    scenes: { type: 'array', minItems: 5, maxItems: 8, items: { type: 'object', additionalProperties: false, required: ['say', 'caption', 'bg', 'actors', 'props', 'fx'], properties: { say: { type: 'string' }, caption: { type: 'string' }, bg: enumOf(BGS), actors: { type: 'array', minItems: 1, maxItems: 2, items: ACTOR }, props: { type: 'array', maxItems: 2, items: PROP }, fx: enumOf(FX) } } }
  }
};

export const SYSTEM = `You turn a beat sheet into a short vertical video told in 8-bit pixel pictures, like the "Science in 8bit" channel. A narrator reads each scene over a simple picture.
Give a cast (1 to 3 characters: name, kind, shirt colour, hair colour) that stays the same in every scene, then 6 or 7 scenes that follow the beats in order, ending on the twist.
For each scene:
- say: what the narrator says, one or two short sentences, at most 18 words, plain spoken English, funny through specific details.
- caption: 2 to 4 words in CAPITALS shown on screen, the loudest word in {braces}.
- the picture, chosen from the kit: bg (where), actors (who = a cast name, pose that shows how they feel, where they stand: when there are two they stand left and right), up to two props that the narrator mentions, and fx.
Make the pictures DIFFER from scene to scene: change the background when the place changes, change who is in the picture, change the poses, and always show the objects the narrator talks about as props.
title: names a person or thing and what happens (at most 10 words). caption: one line for the post plus 3 hashtags.
The whole video is spoken in about {SECONDS} seconds (roughly {WORDS} words in all).`;

// Words in the narration that tell us what the picture should show (so the picture always matches what is said)
const POSE_WORDS = [['shout', /\b(shout|scream|yell|roar|bellow|cries? out)/i], ['scared', /\b(scared|afraid|terrif|panic|fear|horror|gasp|trembl|nervous)/i], ['angry', /\b(angry|furious|rage|fume|argue|slam|storm)/i], ['laugh', /\b(laugh|giggl|chuckl|joke|haha|snicker)/i], ['run', /\b(run|runs|ran|running|chase|chased|flee|fled|escape|rush|sprint|bolt)/i], ['sleep', /\b(sleep|asleep|nap|snor|dream|doze)/i], ['point', /\b(point|show|shows|look at|stare)/i]];
const PROP_WORDS = [['car', /\b(car|truck|vehicle|drive|driving|taxi|van)\b/i], ['house', /\b(house|home|apartment|flat|castle)\b/i], ['tree', /\b(tree|garden|wood|park)\b/i], ['money', /\b(money|cash|dollar|pound|coins?|pay|paid|rich|bank|price|sell|sold|buy|bought|fee|ticket)\b/i], ['fire', /\b(fire|burn|flame|explo|smoke)/i], ['star', /\b(star|famous|win|won|prize|trophy)\b/i], ['heart', /\b(love|heart|kiss|date|wedding)/i], ['cake', /\b(cake|birthday|party|dinner|pizza|food|eat|ate)/i], ['rocket', /\b(rocket|space|launch|moon)\b/i], ['computer', /\b(computer|laptop|screen|internet|online|video game|app|website|stream)/i], ['phone', /\b(phone|call|text|message)/i], ['box', /\b(box|package|parcel|gift|present|crate)/i], ['sign', /\b(sign|shop|store|dealership|notice|rule|form|paperwork)/i], ['bed', /\b(bed|pillow)\b/i], ['table', /\b(table|desk|counter)\b/i], ['chair', /\b(chair|sit|sat|seat|throne)\b/i]];
const BG_WORDS = [['space', /\b(space|planet|alien|rocket|moon|galaxy)/i], ['beach', /\b(beach|sea|ocean|sand|swim|island)/i], ['forest', /\b(forest|woods|camp|jungle)/i], ['office', /\b(office|boss|job|meeting|interview|manager|work)/i], ['shop', /\b(shop|store|dealership|market|bank|counter|customer|salesperson|salesman)/i], ['street', /\b(street|road|city|drive|driving|traffic|town)/i], ['room', /\b(bedroom|kitchen|living room|inside|at home|sofa)/i], ['night', /\b(night|dark|midnight|moonlight)/i]];
const first = (list, text) => list.map(([k, re]) => [k, text.search(re)]).filter(([, i]) => i >= 0).sort((a, b) => a[1] - b[1]).map(([k]) => k);

/**
 * Draw one scene: look up who is in it, make it match the narration, and keep it different from the one before.
 * prev: the previous scene's spec (or null).
 */
export function sceneSpec(s, cast, prev) {
  const text = `${s.say ?? ''} ${s.caption ?? ''}`;
  const byName = (n) => cast.find((c) => String(c.name).toLowerCase() === String(n).toLowerCase()) ?? cast.find((c) => String(n).toLowerCase().includes(String(c.name).toLowerCase())) ?? null;
  const used = new Set();
  const actors = (Array.isArray(s.actors) ? s.actors : []).slice(0, 2).map((a, i) => {
    let c = byName(a.who) ?? cast[i % cast.length];
    if (used.has(c)) c = cast.find((x) => !used.has(x)) ?? c;
    used.add(c);
    return { kind: c.kind, shirt: c.shirt, hair: c.hair, pose: a.pose, at: a.at };
  });
  if (!actors.length) actors.push({ ...cast[0], pose: 'stand', at: 'center' });
  // Two characters made to look the same would be one character twice: change the second's shirt
  if (actors.length === 2 && actors[0].kind === actors[1].kind && actors[0].shirt === actors[1].shirt) actors[1].shirt = actors[0].shirt === 'red' ? 'blue' : 'red';
  // The pose follows the words when the model gave a flat or repeated one
  const poseWord = first(POSE_WORDS, text)[0];
  actors.forEach((a, i) => { const was = prev?.actors?.[i]?.pose; if (poseWord && (a.pose === 'stand' || a.pose === was)) a.pose = poseWord; });
  // Props: what the narrator mentions first, then what the model chose
  const named = first(PROP_WORDS, text);
  const props = [];
  for (const k of named) if (props.length < 2 && !props.some((p) => p.kind === k)) props.push((s.props ?? []).find((p) => p.kind === k) ?? { kind: k, at: 'center', color: 'red' });
  for (const p of s.props ?? []) if (props.length < 2 && PROPS.includes(p.kind) && !props.some((q) => q.kind === p.kind)) props.push(p);
  // The place: the model's choice, unless it is the same as last time and the words say somewhere else
  let bg = BGS.includes(s.bg) ? s.bg : 'sky';
  const place = first(BG_WORDS, text)[0];
  if (place && bg === prev?.bg && place !== bg) bg = place;
  return { bg, actors, props, fx: FX.includes(s.fx) ? s.fx : 'none' };
}

/** Check what the model sent and draw each scene from the kit, or say what's wrong */
export function parseScript(text) {
  let j;
  try { const m = /\{[\s\S]*\}/.exec(String(text)); j = JSON.parse(m ? m[0] : ''); } catch { return { error: "The AI's script wasn't in the shape the video maker needs. Try again" }; }
  const cast = (Array.isArray(j.cast) ? j.cast : []).slice(0, 3).filter((c) => c && KINDS.includes(c.kind)).map((c) => ({ name: String(c.name ?? 'Hero').slice(0, 30), kind: c.kind, shirt: COLORS[c.shirt] ? c.shirt : 'blue', hair: HAIRS.includes(c.hair) ? c.hair : 'brown' }));
  if (!cast.length) cast.push({ name: 'Hero', kind: 'man', shirt: 'blue', hair: 'brown' });
  const scenes = []; let prev = null;
  for (const s of (Array.isArray(j.scenes) ? j.scenes : []).slice(0, 10)) {
    const say = String(s.say ?? '').replace(/[\r\n]+/g, ' ').trim().slice(0, 240);
    if (!say) continue;
    const spec = sceneSpec({ ...s, say }, cast, prev);
    scenes.push({ say, caption: String(s.caption ?? '').trim().slice(0, 60), art: renderScene(spec), art2: renderScene(spec, { lift: 1 }) });
    prev = spec;
  }
  if (scenes.length < 2) return { error: 'The script had too few scenes. Try again' };
  return { title: String(j.title ?? 'Untitled').slice(0, 120), caption: String(j.caption ?? j.title ?? '').slice(0, 600), scenes };
}/** A P6 picture file of the grid (one pixel per grid cell; each character is a palette number in base 16) */
export function ppm(art) {
  const rgb = art.palette.map((h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)));
  const buf = Buffer.alloc(G * G * 3);
  art.rows.forEach((row, y) => { for (let x = 0; x < G; x++) { const c = rgb[Math.min(rgb.length - 1, parseInt(row[x], 16) || 0)] ?? rgb[0]; buf[(y * G + x) * 3] = c[0]; buf[(y * G + x) * 3 + 1] = c[1]; buf[(y * G + x) * 3 + 2] = c[2]; } });
  return Buffer.concat([Buffer.from(`P6\n${G} ${G}\n255\n`), buf]);
}
/** A looping chiptune: a square-wave arpeggio, generated by FFmpeg itself (no music files, nothing to license) */
export const chipExpr = (notes = [0, 4, 7, 12, 7, 4, 0, -5], root = 196, perSec = 6) => {
  const n = notes.length;
  let pick = String(notes[n - 1]);
  for (let i = n - 2; i >= 0; i--) pick = `if(lt(mod(floor(t*${perSec}),${n}),${i + 1}),${notes[i]},${pick})`;
  return `0.12*sgn(sin(2*PI*${root}*pow(2,(${pick})/12)*t))`;
};

const FONTS = ['C:/Windows/Fonts/consolab.ttf', 'C:/Windows/Fonts/arialbd.ttf'];
const esc = (p) => p.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "\\'");

/** Windows' own voice reads the text into a wav (free, offline). */
export async function speak(text, wav, tmp) {
  const txt = join(tmp, `say-${Date.now()}-${Math.round(Math.random() * 1e5)}.txt`);
  writeFileSync(txt, text, 'utf8');
  const ps = `Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Rate = 1; $s.SetOutputToWaveFile('${wav.replace(/'/g, "''")}'); $s.Speak([IO.File]::ReadAllText('${txt.replace(/'/g, "''")}', [Text.Encoding]::UTF8)); $s.Dispose()`;
  const r = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], 120_000);
  return r.ok && existsSync(wav);
}

export async function probeDuration(t, file) {
  const r = await run(t.ffprobe, ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', file], 60_000);
  return Number(r.out.trim()) || 0;
}

/** After it's made: not black, not silent, a sensible length. Returns the problems (empty = good). */
export async function gate(t, file) {
  const problems = [];
  const d = await probeDuration(t, file);
  if (d < 8) problems.push(`Only ${d.toFixed(1)} seconds long`);
  if (d > 120) problems.push(`${Math.round(d)} seconds is too long for a short`);
  const v = await run(t.ffmpeg, ['-nostdin', '-v', 'info', '-i', file, '-vn', '-af', 'volumedetect', '-f', 'null', '-'], 120_000);
  const mean = /mean_volume:\s*(-?[\d.]+) dB/.exec(v.err);
  if (!mean || Number(mean[1]) < -50) problems.push('The sound is nearly silent');
  const b = await run(t.ffmpeg, ['-nostdin', '-v', 'info', '-i', file, '-an', '-vf', 'fps=2,signalstats,metadata=print:key=lavfi.signalstats.YAVG:file=-', '-f', 'null', '-'], 120_000);
  const ys = [...(b.out + b.err).matchAll(/YAVG=([\d.]+)/g)].map((m) => Number(m[1]));
  if (ys.length && ys.reduce((a, c) => a + c, 0) / ys.length < 20) problems.push('The picture is almost all black');
  return { ok: problems.length === 0, problems, seconds: d };
}

/** Make the whole video from a checked script. */
export async function makeVideo(t, script, outDir, { on = () => {}, voice = speak } = {}) {
  mkdirSync(outDir, { recursive: true });
  const work = join(outDir, `work-${Date.now()}`);
  mkdirSync(work, { recursive: true });
  const font = FONTS.find((f) => existsSync(f));
  const parts = [];
  for (let i = 0; i < script.scenes.length; i++) {
    const s = script.scenes[i], p = (n) => join(work, `${i}-${n}`);
    on({ step: 'scene', text: `Scene ${i + 1} of ${script.scenes.length}: drawing and recording` });
    writeFileSync(p('art.ppm'), ppm(s.art));
    const bg = s.art.palette[0].replace('#', '0x');
    const cap = s.caption.replace(/[{}]/g, '').toUpperCase();
    writeFileSync(p('cap.txt'), cap);
    // The 32 x 32 picture, made 30 times bigger with hard edges, centred on its background colour, caption under it
    let vf = `scale=1080:1080:flags=neighbor,pad=1080:1920:0:230:color=${bg}`;
    if (font && cap) vf += `,drawtext=fontfile='${esc(font)}':textfile='${esc(p('cap.txt'))}':fontsize=96:fontcolor=white:borderw=9:bordercolor=black:x=(w-text_w)/2:y=1390`;
    let r = await run(t.ffmpeg, ['-nostdin', '-y', '-v', 'error', '-i', p('art.ppm'), '-vf', vf, '-frames:v', '1', p('scene.png')], 60_000);
    if (!r.ok) return { ok: false, error: `Scene ${i + 1}: ${r.err.slice(-200)}` };
    if (!(await voice(s.say, p('voice.wav'), work))) return { ok: false, error: `Scene ${i + 1}: the voice could not record. Is Windows' speech installed?` };
    const dur = (await probeDuration(t, p('voice.wav'))) + 0.6;
    // A slow push-in keeps the still picture alive; each scene is its own small video
    r = await run(t.ffmpeg, ['-nostdin', '-y', '-v', 'error', '-loop', '1', '-framerate', '25', '-i', p('scene.png'), '-i', p('voice.wav'),
      '-filter_complex', `[0:v]zoompan=z='min(zoom+0.0006,1.06)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=${Math.ceil(dur * 25)}:s=1080x1920:fps=25,format=yuv420p[v];[1:a]apad=pad_dur=1,aresample=44100,aformat=channel_layouts=stereo[a]`,
      '-map', '[v]', '-map', '[a]', '-t', String(dur), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '21', '-c:a', 'aac', '-b:a', '160k', p('scene.mp4')], 180_000);
    if (!r.ok) return { ok: false, error: `Scene ${i + 1}: ${r.err.slice(-200)}` };
    parts.push(p('scene.mp4'));
  }
  on({ step: 'join', text: 'Joining the scenes and adding the music' });
  writeFileSync(join(work, 'list.txt'), parts.map((f) => `file '${f.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`).join('\n'));
  const out = join(outDir, `m${Date.now().toString(36)}.mp4`);
  const joined = join(work, 'joined.mp4');
  let r = await run(t.ffmpeg, ['-nostdin', '-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', join(work, 'list.txt'), '-c', 'copy', joined], 180_000);
  if (!r.ok) return { ok: false, error: `Joining: ${r.err.slice(-200)}` };
  r = await run(t.ffmpeg, ['-nostdin', '-y', '-v', 'error', '-i', joined, '-f', 'lavfi', '-i', `aevalsrc='${chipExpr()}':s=44100:c=stereo`, '-filter_complex', '[0:a][1:a]amix=inputs=2:duration=first:weights=1 0.45:normalize=0[a]', '-map', '0:v', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '160k', '-shortest', '-movflags', '+faststart', out], 180_000);
  if (!r.ok || !existsSync(out)) return { ok: false, error: `Music: ${r.err.slice(-200)}` };
  const th = out.replace(/\.mp4$/, '.jpg');
  await run(t.ffmpeg, ['-nostdin', '-y', '-v', 'error', '-ss', '1', '-i', out, '-frames:v', '1', '-vf', 'scale=360:-2', th], 60_000);
  const q = await gate(t, out);
  return { ok: true, file: out, thumb: existsSync(th) ? th : '', seconds: Math.round(q.seconds), gate: q };
}

/** Ask the AI for the script. `ask` is the free local model's door (clipper-llm.mjs). */
export async function writeScript(ask, { idea, kind, seconds, image }) {
  const what = kind === 'remix'
    ? `Remix this meme: keep what makes the joke work, but tell a NEW joke with a fresh angle (do not copy its words). ${image ? 'The meme is the picture. ' : ''}Notes from the owner: ${idea}`
    : `${kind === 'story' ? 'Tell this story' : 'Make this comedy'}: ${idea}`;
  const content = image ? [{ image }, { text: what }] : what;
  const system = SYSTEM.replace('{SECONDS}', String(seconds)).replace('{WORDS}', String(Math.round(seconds * 2.3)));
  let last = '';
  for (let i = 0; i < 2; i++) { // a second try if the first comes back unusable
    const r = await ask({ system, content, max: 3500, schema: SCHEMA, temperature: i ? 0.5 : 0.8 });
    if (r.error) return { error: r.error };
    const p = parseScript(r.text);
    if (!p.error) return p;
    last = p.error;
  }
  return { error: last };
}