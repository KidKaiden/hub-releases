// Universal Cable on the server: reads the websites you add (cable-reader.mjs, on this PC, in Edge) and hands the app
// their banner and rows. What it read is kept (so Home opens at once) and refreshed in the background. Any signed-in
// account can use it (the family shares the PC); each account has a small hourly allowance so nobody floods it.
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkUrl, reader as makeReader } from './cable-reader.mjs';

const FRESH = 45 * 60_000;        // a read this young needs no refresh
const SEARCH_KEEP = 10 * 60_000;
const READS_PER_HOUR = 40, SEARCHES_PER_HOUR = 90;

export function cable(ctx, impl = {}) {
  const { cfg, log, stamp } = ctx;
  const file = join(cfg.dataDir, 'cable-cache.json');
  const rd = impl.reader ?? makeReader({ lookup: impl.lookup, log: (m) => log(`${stamp()} ${m}`) });
  const lookup = impl.lookup;
  let cache = {};
  try { cache = JSON.parse(readFileSync(file, 'utf8')); } catch { /* first time */ }
  let saveT = null;
  const save = () => { clearTimeout(saveT); saveT = setTimeout(() => { try { mkdirSync(cfg.dataDir, { recursive: true }); writeFileSync(file, JSON.stringify(cache)); } catch (e) { log(`${stamp()} Cable: could not save its cache (${e.message})`); } }, 500); saveT.unref?.(); };
  const reading = new Map();   // url -> promise
  const searches = new Map();  // `${url}\n${q}` -> { at, value }
  const uses = new Map();      // `${kind}:${user}` -> times
  const tooMany = (kind, user, max) => { const k = `${kind}:${user}`, now = Date.now(); const t = (uses.get(k) ?? []).filter((x) => now - x < 3600_000); t.push(now); uses.set(k, t); return t.length > max; };

  /** Start (or join) a read of one site; the answer lands in the cache */
  function startRead(url) {
    if (reading.has(url)) return reading.get(url);
    const p = (async () => {
      const r = await rd.read(url);
      const old = cache[url];
      cache[url] = r.error
        ? { ...(old ?? {}), error: r.error, failedAt: Date.now() }          // keep the last good rows, say why this try failed
        : { data: r, readAt: Date.now() };
      save();
    })().catch((e) => { cache[url] = { ...(cache[url] ?? {}), error: String(e.message ?? e).slice(0, 160), failedAt: Date.now() }; save(); }).finally(() => reading.delete(url));
    reading.set(url, p);
    return p;
  }
  const view = (url) => {
    const c = cache[url];
    const busy = reading.has(url);
    return { state: busy ? 'reading' : c?.data && !c.error ? 'ready' : c?.error ? 'error' : 'none', readAt: c?.readAt ?? 0, data: c?.data ?? null, error: busy ? '' : c?.error ?? '', stale: !!c?.data && Date.now() - (c.readAt ?? 0) > FRESH };
  };

  const routes = {
    'GET /api/cable/status': () => [200, { ready: rd.ready(), reading: [...reading.keys()] }],
    // Is this a site Cable may open? (adds nothing; the app keeps the list)
    'POST /api/cable/check': async (b) => {
      const c = await checkUrl(b.url, lookup);
      if (!c.ok) return [400, { error: c.error, field: 'url' }];
      return [200, { url: c.url, host: new URL(c.url).hostname.replace(/^www\./, '') }];
    },
    // The site's banner and rows: what is saved now, and a fresh read started when it is old (or when asked)
    'GET /api/cable/site': async (_b, u, meta) => {
      const c = await checkUrl(meta.q.get('url'), lookup);
      if (!c.ok) return [400, { error: c.error, field: 'url' }];
      const force = meta.q.get('force') === '1';
      const v = view(c.url);
      if (!rd.ready()) return [503, { error: 'Cable needs Microsoft Edge or Chrome on the PC that runs the Hub server', code: 'nobrowser' }];
      // A failed read is not retried at once (the app polls this route): only on request, or after 5 minutes
      const failedRecently = Date.now() - (cache[c.url]?.failedAt ?? 0) < 5 * 60_000;
      if ((force || v.state === 'none' || ((v.state === 'error' || v.stale) && !failedRecently)) && !reading.has(c.url)) {
        if (tooMany('read', u.id, READS_PER_HOUR)) return [429, { error: 'That is a lot of refreshes for one hour. Try again later', code: 'slow' }];
        startRead(c.url);
      }
      return [200, { url: c.url, ...view(c.url) }];
    },
    // Type a search into the site's own search box and read what it shows
    'GET /api/cable/search': async (_b, u, meta) => {
      const c = await checkUrl(meta.q.get('url'), lookup);
      if (!c.ok) return [400, { error: c.error, field: 'url' }];
      const q = String(meta.q.get('q') ?? '').trim().slice(0, 80);
      if (q.length < 2) return [400, { error: 'Type at least two letters', field: 'q' }];
      if (!rd.ready()) return [503, { error: 'Cable needs Microsoft Edge or Chrome on the PC that runs the Hub server', code: 'nobrowser' }];
      const key = `${c.url}\n${q.toLowerCase()}`;
      const hit = searches.get(key);
      if (hit && Date.now() - hit.at < SEARCH_KEEP) return [200, hit.value];
      if (tooMany('search', u.id, SEARCHES_PER_HOUR)) return [429, { error: 'That is a lot of searches for one hour. Try again later', code: 'slow' }];
      const r = await rd.search(c.url, q);
      const value = r.error ? { url: c.url, error: r.error, results: [] } : { url: c.url, results: r.results };
      if (!r.error) { searches.set(key, { at: Date.now(), value }); if (searches.size > 200) searches.delete(searches.keys().next().value); }
      return [200, value];
    }
  };
  return { routes, view, startRead, stop() { clearTimeout(saveT); rd.stop?.(); if (Object.keys(cache).length) try { mkdirSync(cfg.dataDir, { recursive: true }); writeFileSync(file, JSON.stringify(cache)); } catch { /* disk gone */ } } };
}
