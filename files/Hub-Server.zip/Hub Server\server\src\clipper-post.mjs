﻿// Clipper's poster. A clip is only ever handed here by the owner approving it in the app. At the chosen time:
//   Instagram Reels: sent through Instagram's own API (resumable upload) when the owner has put in their token.
//   TikTok (and Instagram without a token): put in the "Ready to post" folder with the caption beside it, because
//   TikTok only lets an unapproved app post privately, so the owner posts from the phone. Never any other way.
// *[To test]* the Instagram calls follow Meta's published Reels flow; they need a real Business or Creator account.
import { copyFileSync, existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const GRAPH = 'https://graph.instagram.com/v21.0';

export function poster(ctx, impl = {}) {
  const { home, log, stamp } = ctx;
  const doFetch = impl.fetch ?? fetch;
  const file = join(home, 'posts.json');
  const ready = join(home, 'Ready to post');
  let list = [];
  try { list = JSON.parse(readFileSync(file, 'utf8')); } catch { /* none yet */ }
  const save = () => { try { mkdirSync(home, { recursive: true }); writeFileSync(file, JSON.stringify(list.slice(-300))); } catch { /* disk */ } };
  const status = () => ({ queued: list.filter((p) => p.state === 'queued').length, sent: list.filter((p) => p.state === 'sent').length, ready: list.filter((p) => p.state === 'ready').length });

  /** The next time the clock says HH:MM (24 h, this PC's time) */
  const nextAt = (hhmm, now = Date.now()) => {
    const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm)); const d = new Date(now);
    d.setHours(m ? Math.min(23, Number(m[1])) : 18, m ? Math.min(59, Number(m[2])) : 30, 0, 0);
    return d.getTime() <= now ? d.getTime() + 86400_000 : d.getTime();
  };

  async function toInstagram(p, k, path) {
    const j = async (r) => { const x = await r.json().catch(() => ({})); if (!r.ok || x.error) throw new Error(x.error?.message ?? `Instagram said ${r.status}`); return x; };
    const size = statSync(path).size;
    const c = await j(await doFetch(`${GRAPH}/${k.igUser}/media`, { method: 'POST', headers: { authorization: `Bearer ${k.igToken}`, 'content-type': 'application/json' }, body: JSON.stringify({ media_type: 'REELS', upload_type: 'resumable', caption: p.caption }) }));
    const up = await doFetch(c.uri ?? `https://rupload.facebook.com/ig-api-upload/v21.0/${c.id}`, { method: 'POST', headers: { authorization: `OAuth ${k.igToken}`, offset: '0', file_size: String(size) }, body: readFileSync(path) });
    await j(up);
    // Instagram needs a moment to process the video before it can be published
    for (let i = 0; i < 30; i++) {
      const s = await j(await doFetch(`${GRAPH}/${c.id}?fields=status_code`, { headers: { authorization: `Bearer ${k.igToken}` } }));
      if (s.status_code === 'FINISHED') break;
      if (s.status_code === 'ERROR' || s.status_code === 'EXPIRED') throw new Error('Instagram could not process the video');
      await new Promise((r) => setTimeout(r, impl.wait ?? 5000));
    }
    const pub = await j(await doFetch(`${GRAPH}/${k.igUser}/media_publish`, { method: 'POST', headers: { authorization: `Bearer ${k.igToken}`, 'content-type': 'application/json' }, body: JSON.stringify({ creation_id: c.id }) }));
    return pub.id;
  }
  function toFolder(p, path) {
    mkdirSync(ready, { recursive: true });
    // The account it's meant for leads the name, so a one-account-per-streamer test knows where each file goes
    const base = `${p.account ? `${p.account} ` : ''}${new Date().toISOString().slice(0, 10)} ${p.streamer || 'clip'} ${p.id}`.replace(/[^\w .-]/g, '');
    copyFileSync(path, join(ready, `${base}.mp4`));
    writeFileSync(join(ready, `${base}.txt`), p.caption);
    return join(ready, `${base}.mp4`);
  }

  let busy = false;
  async function tick(now = Date.now()) {
    if (busy) return; busy = true;
    try {
      for (const p of list.filter((x) => x.state === 'queued' && x.at <= now)) {
        const path = ctx.clipPath?.(p.id);
        try {
          if (!path || !existsSync(path)) throw new Error('The clip file is gone');
          const k = ctx.keys();
          // The one Instagram key is your main account's: a clip meant for another (test) account is never sent with it
          const ig = !!(k.igToken && k.igUser) && !p.account;
          if (p.to.includes('instagram') && ig) { p.igId = await toInstagram(p, k, path); p.note = 'Posted to Instagram'; }
          else p.note = 'Saved in the Ready to post folder, with its caption';
          if (p.to.includes('tiktok') || !ig) { p.folder = toFolder(p, path); p.note = p.igId ? 'Posted to Instagram. A copy for TikTok is in the Ready to post folder' : `Saved in the Ready to post folder, with its caption${p.account ? `, for @${p.account}` : ''}`; }
          p.state = p.igId ? 'sent' : 'ready'; p.done = Date.now();
          log(`${stamp()} Clipper: ${p.note.toLowerCase()} (${p.id})`);
        } catch (e) { p.state = 'error'; p.note = String(e.message ?? e).slice(0, 200); log(`${stamp()} Clipper: posting failed (${p.note})`); }
        save();
      }
    } finally { busy = false; }
  }
  const timer = impl.noTimer ? null : setInterval(() => tick(), 30_000);
  timer?.unref?.();

  const routes = (owner) => ({
    // The app sends a clip here when you approve it (and only then)
    'POST /api/admin/clipper/post': owner((b) => {
      const id = String(b.id ?? '');
      if (!ctx.clipPath?.(id)) return [404, { error: 'That clip is not on the server' }];
      if (!String(b.caption ?? '').trim()) return [400, { error: 'A caption is needed' }];
      list = list.filter((p) => !(p.id === id && p.state === 'queued'));
      list.push({ id, streamer: String(b.streamer ?? '').slice(0, 40), account: String(b.account ?? '').replace(/[^\w.-]/g, '').slice(0, 40), caption: String(b.caption).slice(0, 2200), to: ['instagram', 'tiktok'].filter((x) => (Array.isArray(b.to) ? b.to : ['instagram', 'tiktok']).includes(x)), at: b.now ? Date.now() : nextAt(b.postAt), state: 'queued', added: Date.now(), note: '' });
      save(); if (b.now) setImmediate(() => tick());
      return [200, { posts: list.filter((p) => p.id === id), counts: status() }];
    }),
    'POST /api/admin/clipper/post/cancel': owner((b) => {
      const p = list.find((x) => x.id === String(b.id) && x.state === 'queued');
      if (!p) return [404, { error: 'It already went, or was never queued' }];
      list = list.filter((x) => x !== p); save(); return [200, { counts: status() }];
    }),
    'GET /api/admin/clipper/posts': owner(() => [200, { posts: list.slice(-60).reverse(), counts: status(), folder: ready }])
  });
  return { routes, tick, status, nextAt, list: () => list, stop() { clearInterval(timer); if (list.length) save(); } };
}

