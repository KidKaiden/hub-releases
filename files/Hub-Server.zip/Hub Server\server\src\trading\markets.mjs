// Trading > Markets (Trading UI prompt v6, slice 4): only where a free source really exists (researched 2026-11-23).
//   screener   the allowed symbols and the lab's 14 funds, from the broker's daily prices (Alpaca, already connected)
//   economy    FRED (free key, per account, kept like every key) and the World Bank (no key, CC BY 4.0)
//   calendar   FRED's release dates (the same free key)
//   news       Alpaca's news feed (Benzinga), with the account's own paper keys (TO TEST on a real account)
//   odds       Polymarket (Gamma API) and Kalshi (public market data), read only, no key: a benchmark to look at beside
//              the council's predictions. Nothing here reaches the council's scoring or any order code.
//   replay     bar by bar through old prices with the SAME signal (strategy.latest) and the SAME risk sizing
//              (risk.checkOrder) the paper bot uses: one engine for replay and paper. Never places anything.
// Not built (no free source, or terms that need Kaiden first): social sentiment (StockTwits closed to new developers,
// Reddit's self-service sign-up closed late 2025), spreads and swaps (no free source; a stock account has no swaps),
// the filings relationship map (the SEC asks every request to carry a contact; needs Kaiden's say on what to send), IMF (TO TEST).
import { existsSync, mkdirSync, readFileSync, writeFileSync, unlinkSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { latest } from './strategy.mjs';
import { checkOrder } from './risk.mjs';

export const BASES = { fred: 'https://api.stlouisfed.org/fred', worldbank: 'https://api.worldbank.org/v2', polymarket: 'https://gamma-api.polymarket.com', kalshi: 'https://api.elections.kalshi.com/trade-api/v2' };
export const SCREEN = ['SPY', 'QQQ', 'IWM', 'DIA', 'XLK', 'XLF', 'XLE', 'XLV', 'XLY', 'XLP', 'XLI', 'XLU', 'XLB', 'TLT'];
const FRED_SERIES = [
  { id: 'CPIAUCSL', name: 'US inflation (prices a year on)', yoy: true, unit: '%' }, { id: 'UNRATE', name: 'US unemployment', unit: '%' },
  { id: 'FEDFUNDS', name: 'US interest rate (Fed funds)', unit: '%' }, { id: 'DGS10', name: 'US 10-year bond yield', unit: '%' }, { id: 'T10Y2Y', name: '10-year minus 2-year (below 0: inverted)', unit: '%' }
];
const WB = [{ id: 'NY.GDP.MKTP.KD.ZG', name: 'Growth (GDP)' }, { id: 'FP.CPI.TOTL.ZG', name: 'Inflation' }];
const r2 = (v) => Math.round(v * 100) / 100;
/** Kalshi's chance of "Yes" in per cent: the newer dollar fields ("0.0300" = 3%), or the older whole cents. null when nobody has priced it. */
export function kalshiYes(m) {
  const d = Number(m.last_price_dollars) > 0 ? Number(m.last_price_dollars) * 100 : Number(m.yes_bid_dollars) > 0 ? Number(m.yes_bid_dollars) * 100 : m.last_price > 0 ? Number(m.last_price) : m.yes_bid > 0 ? Number(m.yes_bid) : null;
  return d == null || !Number.isFinite(d) ? null : r2(d);
}

/** Pure: a symbol's screen from daily bars (oldest first). */
export function screen(symbol, bars) {
  if (bars.length < 60) return { symbol, enough: false };
  const c = bars.map((b) => b.c), last = c.at(-1);
  const avg = (n) => (c.length >= n ? c.slice(-n).reduce((a, b) => a + b, 0) / n : null);
  const a200 = avg(200), a50 = avg(50);
  const ret = (n) => (c.length > n ? last / c[c.length - 1 - n] - 1 : null);
  const hi = Math.max(...c.slice(-252));
  const d = c.slice(-21).map((x, i, a) => (i ? Math.log(x / a[i - 1]) : 0)).slice(1);
  const vol = Math.sqrt(d.reduce((s, x) => s + x * x, 0) / Math.max(1, d.length - 1)) * Math.sqrt(252);
  return { symbol, enough: true, last: r2(last), trend: a200 == null ? null : last > a200 ? 'up' : 'down', above50: a50 == null ? null : last > a50,
    m1: ret(21) == null ? null : r2(ret(21) * 100), m3: ret(63) == null ? null : r2(ret(63) * 100), fromHigh: r2((last / hi - 1) * 100), vol: r2(vol * 100) };
}

/**
 * Pure: replay a symbol day by day. Each day, the strategy sees only the days so far (latest), and a buy is sized by
 * the same risk check the paper bot uses, on a pretend account. Returns each day's decision with its reason.
 */
export function replay(bars, { symbol, strategy, limits, start = 1000, from = 0 }) {
  const L = { ...limits, floor: limits.floor ?? start * 0.7, symbols: [...new Set([...(limits.symbols ?? []), symbol])] };
  let cash = start, qty = 0, stopPrice = null;
  const out = [];
  for (let i = Math.max(from, strategy.slow + 1); i < bars.length; i++) {
    const seen = bars.slice(0, i + 1), b = bars[i];
    const sig = latest(seen, strategy);
    const equity = cash + qty * b.c;
    let did = null, why = sig.why;
    if (qty > 0 && stopPrice != null && b.l <= stopPrice) { cash += qty * Math.min(b.o, stopPrice); did = 'sold at the stop'; why = `The low (${r2(b.l)}) reached the stop at ${r2(stopPrice)}`; qty = 0; stopPrice = null; }
    else if (sig.signal === 'sell' && qty > 0) { cash += qty * b.c; did = 'sold'; qty = 0; stopPrice = null; }
    else if (sig.signal === 'buy' && qty === 0) {
      const c = checkOrder({ symbol, side: 'buy' }, { equity, cash, positions: [], dayStart: equity, ordersToday: 0, killed: false, locked: false, account: { multiplier: 1, shorting: false } }, L, { human: false });
      if (c.ok) { qty = c.order.notional / b.c; cash -= c.order.notional; stopPrice = b.c * (1 - c.order.stopPct / 100); did = `bought $${c.order.notional.toFixed(2)}`; }
      else { did = 'wanted to buy, the risk check said no'; why = c.reasons.join('; '); }
    }
    out.push({ t: b.t, o: b.o, h: b.h, l: b.l, c: b.c, signal: sig.signal, trend: sig.trend, did, why, equity: r2(cash + qty * b.c) });
  }
  return { days: out, start, end: out.at(-1)?.equity ?? start };
}

export function markets(ctx, impl = {}) {
  const { db, cfg } = ctx;
  const doFetch = impl.fetch ?? fetch;
  const B = { ...BASES, ...(cfg.markets ?? {}) };
  const keysDir = () => cfg.keysDir || resolve(cfg.dataDir, '..', 'Keys');
  const keyFile = (uid) => join(keysDir(), `fred-${String(uid).replace(/[^\w-]/g, '')}.json`);
  const readKey = (uid) => { try { return existsSync(keyFile(uid)) ? JSON.parse(db.keys ? db.keys.readSecret(keyFile(uid)) : readFileSync(keyFile(uid), 'utf8')).key : null; } catch { return null; } };
  const cache = new Map();
  // answers kept for a while so the free services are not asked twice; capped, because a search box can make endless distinct keys
  const cached = async (k, ms, fn) => { const c = cache.get(k); if (c && Date.now() - c.at < ms) return c.v; const v = await fn(); if (cache.size >= 200) cache.delete(cache.keys().next().value); cache.set(k, { at: Date.now(), v }); return v; };
  const get = async (url, init) => { const r = await doFetch(url, { ...init, signal: AbortSignal.timeout(15_000) }); if (!r.ok) throw Object.assign(new Error(`${new URL(url).host} said ${r.status}`), { status: r.status }); return r.json(); };

  async function economy(uid) {
    const key = readKey(uid);
    const fred = key ? await Promise.all(FRED_SERIES.map(async (s) => {
      try {
        const j = await get(`${B.fred}/series/observations?series_id=${s.id}&api_key=${encodeURIComponent(key)}&file_type=json&sort_order=desc&limit=${s.yoy ? 14 : 2}`);
        const obs = (j.observations ?? []).filter((o) => o.value !== '.').map((o) => ({ date: o.date, v: Number(o.value) }));
        if (!obs.length) return { ...s, value: null };
        const value = s.yoy ? (obs.length >= 13 ? r2((obs[0].v / obs[12].v - 1) * 100) : null) : obs[0].v;
        const prev = s.yoy ? (obs.length >= 14 ? r2((obs[1].v / obs[13].v - 1) * 100) : null) : obs[1]?.v ?? null;
        return { ...s, value, prev, date: obs[0].date };
      } catch (e) { return { ...s, value: null, error: e.status === 400 || e.status === 403 ? 'FRED turned the key down' : "Couldn't reach FRED" }; }
    })) : null;
    const wb = await Promise.all(['USA', 'GBR'].flatMap((country) => WB.map(async (w) => {
      try {
        const j = await get(`${B.worldbank}/country/${country}/indicator/${w.id}?format=json&per_page=5&mrnev=1`);
        const o = (j?.[1] ?? []).find((x) => x.value != null);
        return { country: country === 'USA' ? 'United States' : 'United Kingdom', name: w.name, value: o ? r2(o.value) : null, year: o?.date ?? null };
      } catch { return { country, name: w.name, value: null, year: null, error: "Couldn't reach the World Bank" }; }
    })));
    return { fred, fredKey: !!key, worldbank: wb, sources: 'FRED (St. Louis Fed) and the World Bank (CC BY 4.0)' };
  }
  async function calendar(uid) {
    const key = readKey(uid);
    if (!key) return { key: false, dates: [] };
    const today = new Date().toISOString().slice(0, 10), end = new Date(Date.now() + 14 * 86_400_000).toISOString().slice(0, 10);
    const j = await get(`${B.fred}/releases/dates?api_key=${encodeURIComponent(key)}&file_type=json&realtime_start=${today}&realtime_end=${end}&include_release_dates_with_no_data=true&sort_order=asc&limit=200`);
    const big = /consumer price|employment situation|gross domestic|personal income|retail|producer price|fomc|jolts|housing starts|industrial production|interest rate|treasury/i;
    return { key: true, dates: (j.release_dates ?? []).filter((d) => d.date >= today).map((d) => ({ date: d.date, name: d.release_name, big: big.test(d.release_name) })).slice(0, 80) };
  }
  async function odds(q) {
    const term = String(q ?? '').trim().slice(0, 60);
    const poly = await get(`${B.polymarket}/markets?closed=false&limit=200&order=volume24hr&ascending=false`).catch(() => null);
    const pm = (Array.isArray(poly) ? poly : []).filter((m) => !term || new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(m.question ?? ''))
      .slice(0, 8).map((m) => { let p = null; try { p = Number(JSON.parse(m.outcomePrices ?? '[]')[0]); } catch { /* none */ } return { source: 'Polymarket', question: m.question, yes: Number.isFinite(p) ? r2(p * 100) : null, volume: Number(m.volume24hr ?? 0), ends: m.endDate ?? null, url: m.slug ? `https://polymarket.com/event/${m.slug}` : null }; });
    // Kalshi's plain market list is mostly unpriced sports props; its events carry the real questions with their markets nested inside
    const kal = await get(`${B.kalshi}/events?status=open&limit=200&with_nested_markets=true`).catch(() => null);
    const re = term ? new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') : null;
    const km = (kal?.events ?? []).flatMap((e) => (e.markets ?? []).map((m) => ({
      source: 'Kalshi', question: `${e.title ?? m.title}${(e.markets?.length ?? 0) > 1 && (m.yes_sub_title || m.subtitle) ? ` (${m.yes_sub_title || m.subtitle})` : ''}`,
      yes: kalshiYes(m), volume: Number(m.volume_24h_fp) || Number(m.volume_24h) || Number(m.volume_fp) || Number(m.volume) || 0, ends: m.close_time ?? null, url: null })))
      .filter((m) => m.yes != null && (!re || re.test(m.question))).sort((a, b) => b.volume - a.volume).slice(0, 8); // only questions that have a price, the busiest first
    return { list: [...pm, ...km], polymarket: !!poly, kalshi: !!kal, note: 'Read only, for comparing with the council. It never feeds the council\'s scores or any trade.' };
  }

  const routes = (own, broker, limits, strategy) => ({
    'GET /api/trading/markets/screener': async (_b, u) => {
      const no = own(u); if (no) return no;
      const b = broker(); if (!b) return [400, { error: 'Connect a broker account first (Trading > Connect): the screener uses its free daily prices' }];
      const syms = [...new Set([...limits().symbols, ...SCREEN])].slice(0, 24);
      const rows = await cached(`screen:${syms.join()}`, 30 * 60_000, () => Promise.all(syms.map(async (s) => { try { return screen(s, await b.bars(s, 300)); } catch { return { symbol: s, enough: false }; } })));
      return [200, { rows, at: Date.now(), source: 'Alpaca daily prices (IEX feed)' }];
    },
    // whether this account has put in its free FRED key (the Hub > Setup guide asks this; the key itself is never sent back)
    'GET /api/trading/markets/status': (_b, u) => { const no = own(u); if (no) return no; return [200, { fredKey: !!readKey(u.id) }]; },
    'GET /api/trading/markets/economy': async (_b, u) => { const no = own(u); if (no) return no; return [200, await cached(`eco:${u.id}:${!!readKey(u.id)}`, 6 * 3600_000, () => economy(u.id))]; },
    'GET /api/trading/markets/calendar': async (_b, u) => { const no = own(u); if (no) return no; try { return [200, await cached(`cal:${u.id}:${!!readKey(u.id)}`, 3600_000, () => calendar(u.id))]; } catch (e) { return [502, { error: `Couldn't get the calendar from FRED (${e.message})` }]; } },
    'GET /api/trading/markets/news': async (_b, u, { q }) => {
      const no = own(u); if (no) return no;
      const b = broker(); if (!b) return [400, { error: 'Connect a broker account first (Trading > Connect): the news comes through it' }];
      const sym = String(q?.get('symbol') ?? '').toUpperCase().replace(/[^A-Z.]/g, '').slice(0, 8);
      try { return [200, { list: await cached(`news:${sym}`, 10 * 60_000, () => b.news(sym ? [sym] : [], 15)), source: 'Benzinga, through Alpaca' }]; }
      catch (e) { return [502, { error: e.status === 403 ? 'Your broker plan doesn\'t include news' : "Couldn't get the news. Try again" }]; }
    },
    'GET /api/trading/markets/odds': async (_b, u, { q }) => { const no = own(u); if (no) return no; return [200, await cached(`odds:${q?.get('q') ?? ''}`, 10 * 60_000, () => odds(q?.get('q')))]; },
    'GET /api/trading/replay': async (_b, u, { q }) => {
      const no = own(u); if (no) return no;
      const b = broker(); if (!b) return [400, { error: 'Connect a broker account first (Trading > Connect): replay uses its free daily prices' }];
      const sym = String(q?.get('symbol') ?? 'SPY').toUpperCase().replace(/[^A-Z.]/g, '').slice(0, 8);
      const days = Math.max(120, Math.min(500, Number(q?.get('days')) || 250));
      const bars = await b.bars(sym, days + strategy().slow + 5).catch(() => []);
      if (bars.length < strategy().slow + 20) return [400, { error: 'Not enough prices for that symbol' }];
      return [200, { symbol: sym, ...replay(bars, { symbol: sym, strategy: strategy(), limits: limits(), start: Math.max(100, Math.min(1e6, Number(q?.get('start')) || 1000)), from: Math.max(0, bars.length - days) }), strategy: strategy() }];
    },
    // the account's own free FRED key: checked with FRED, kept in the Keys folder, never sent back (RISKY in app.mjs)
    'POST /api/trading/markets/fred-key': async (b, u, meta) => {
      const no = own(u); if (no) return no;
      if (meta?.public) return [403, { error: 'Do this at home: keys never travel over the internet', code: 'home' }];
      const key = String(b.key ?? '').trim();
      if (!/^[a-f0-9]{32}$/i.test(key)) return [400, { error: 'A FRED key is 32 letters and numbers (fred.stlouisfed.org > My Account > API Keys)', field: 'key' }];
      try { await get(`${B.fred}/series?series_id=GDP&api_key=${key}&file_type=json`); } catch (e) { return [400, { error: e.status === 400 || e.status === 403 ? 'FRED did not accept that key. Copy it again' : "Couldn't reach FRED: is the PC online?", field: 'key' }]; }
      mkdirSync(keysDir(), { recursive: true });
      if (db.keys) db.keys.writeSecret(keyFile(u.id), JSON.stringify({ key })); else writeFileSync(keyFile(u.id), JSON.stringify({ key }), { mode: 0o600 });
      for (const k of [...cache.keys()]) if (k.includes(u.id)) cache.delete(k);
      return [200, { fredKey: true }];
    },
    'POST /api/trading/markets/fred-key/remove': (_b, u, meta) => {
      const no = own(u); if (no) return no;
      if (meta?.public) return [403, { error: 'Do this at home', code: 'home' }];
      try { if (existsSync(keyFile(u.id))) unlinkSync(keyFile(u.id)); } catch { /* gone */ }
      for (const k of [...cache.keys()]) if (k.includes(u.id)) cache.delete(k);
      return [200, { fredKey: false }];
    }
  });
  return { routes, hasKey: readKey };
}
