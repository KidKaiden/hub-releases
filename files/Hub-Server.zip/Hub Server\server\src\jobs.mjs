// The PC server's job queue: long jobs (fetching prices, a trading-lab run, later the delegation router's jobs) wait here
// and run one at a time. The queue is a file, so jobs survive the PC being off or the server restarting: a job that was
// running starts again, a job waiting for a time (a rate limit) waits, and everything catches up when the PC is back.
// A kind's handler: async (job, ctl) => { done: true, note } | { wait: ms, note } (try again later); throwing fails it.
// ctl.progress({ stage, done, total, note }) saves progress as it goes. Each job belongs to one account (job.account).
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';

export function jobQueue({ file, log = () => {}, now = () => Date.now(), keep = 200 }) {
  let jobs = [];
  try { if (existsSync(file)) jobs = JSON.parse(readFileSync(file, 'utf8')); } catch { jobs = []; }
  for (const j of jobs) if (j.state === 'running') { j.state = 'queued'; j.note = 'Started again after the PC or the server restarted'; j.restarts = (j.restarts ?? 0) + 1; }
  const kinds = {};
  let busy = null, timer = null;
  const save = () => { try { mkdirSync(dirname(file), { recursive: true }); writeFileSync(`${file}.tmp`, JSON.stringify(jobs)); renameSync(`${file}.tmp`, file); } catch (e) { log(`Jobs: could not save (${e.message})`); } };
  const newId = () => `j${now().toString(36)}${Math.floor(Math.random() * 1e6).toString(36)}`;

  function add(kind, account, args = {}, o = {}) {
    if (!kinds[kind]) throw new Error(`unknown job kind ${kind}`);
    if (o.once) { const same = jobs.find((j) => j.kind === kind && j.account === account && ['queued', 'running', 'waiting'].includes(j.state)); if (same) return same; }
    const j = { id: newId(), kind, account, args, state: 'queued', at: now(), after: o.after ?? null, progress: null, note: '', tries: 0, label: o.label ?? kind };
    jobs.push(j); trim(); save(); return j;
  }
  const trim = () => { const old = jobs.filter((j) => ['done', 'failed', 'cancelled'].includes(j.state)); if (old.length > keep) { const drop = new Set(old.slice(0, old.length - keep).map((j) => j.id)); jobs = jobs.filter((j) => !drop.has(j.id)); } };
  /** The next job that may run: queued (or waiting whose time has come), and whatever it follows has finished well */
  function next() {
    const t = now();
    return jobs.find((j) => (j.state === 'queued' || (j.state === 'waiting' && (j.until ?? 0) <= t)) && (!j.after || jobs.find((x) => x.id === j.after)?.state === 'done'));
  }
  async function tick() {
    if (busy) return false;
    // a job whose earlier step failed or was cancelled cannot run: it is cancelled too, with the reason
    for (const j of jobs) if (['queued', 'waiting'].includes(j.state) && j.after) { const a = jobs.find((x) => x.id === j.after); if (!a || ['failed', 'cancelled'].includes(a.state)) { j.state = 'cancelled'; j.note = 'The step before it did not finish'; j.end = now(); save(); } }
    const j = next(); if (!j) return false;
    busy = j; j.state = 'running'; j.started ??= now(); j.tries++; save();
    const ctl = { progress: (p) => { j.progress = { ...(j.progress ?? {}), ...p }; save(); }, cancelled: () => j.state === 'cancelled' };
    try {
      const r = await kinds[j.kind](j, ctl);
      if (j.state === 'cancelled') { /* cancelled while it ran */ }
      else if (r?.wait) { j.state = 'waiting'; j.until = now() + r.wait; j.note = r.note ?? 'Waiting'; }
      else { j.state = 'done'; j.end = now(); j.note = r?.note ?? 'Done'; j.result = r?.result; }
    } catch (e) { if (j.state === 'cancelled') { busy = null; save(); return true; } /* stopped by Cancel: not a failure */ j.state = 'failed'; j.end = now(); j.note = String(e?.message ?? e).slice(0, 500); log(`Job ${j.label} failed: ${j.note}`); }
    finally { busy = null; save(); }
    return true;
  }
  return {
    on(kind, fn) { kinds[kind] = fn; },
    add, tick, save,
    list: (account) => jobs.filter((j) => account == null || j.account === account),
    get: (id) => jobs.find((j) => j.id === id),
    cancel(id, account) { const j = jobs.find((x) => x.id === id && (account == null || x.account === account)); if (!j || ['done', 'failed', 'cancelled'].includes(j.state)) return false; j.state = 'cancelled'; j.end = now(); j.note = 'Cancelled'; for (const k of jobs) if (k.after === j.id && ['queued', 'waiting'].includes(k.state)) { k.state = 'cancelled'; k.note = 'The step before it was cancelled'; } save(); return true; },
    busy: () => busy,
    start(ms = 10_000) { if (timer) return; timer = setInterval(() => { void tick().then((ran) => ran && setImmediate(() => void tick())); }, ms); timer.unref?.(); setTimeout(() => void tick(), 1500).unref?.(); },
    stop() { clearInterval(timer); timer = null; save(); }
  };
}
