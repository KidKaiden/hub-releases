import{l as t,w as e}from"./index-vkHdGtLG.js";function w(i,o){t(window,["resize"],()=>e(()=>o(window[i])))}export{w as b};
