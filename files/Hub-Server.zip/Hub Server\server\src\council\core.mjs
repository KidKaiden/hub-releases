// The prediction council's core (plans/trading-lab/COUNCIL.md). Pure functions, no files, no network, and no way to
// trade: this folder imports nothing outside itself (a test checks it). Every number here is computed by code; a skill
// (a person, a local model or code) only hands in a record in the shared format below.
//
// Shared record (every skill hands in one, every team lead and the chair read them):
//   { skill, team, at, question, horizonDays,
//     prediction: { target, direction: 'up' | 'down' | 'yes' | 'no', probability: 0..1 },
//     reasoning: ['...'],                      plain sentences
//     claims: [{ id, text, value?, unit?, source?, ref? }],   what it rests on; value/source: a number from a hard source
//     chain: [{ step: 'choice' | 'consequence' | 'market', text }],   the effect chain, in that order
//     matches: [{ event, when, followed }],     similar past events (past matches)
//     challenge: { by, against: ['...'], answer: '...' } }   the challenger's case, and the reply
// Checks (shared working skills): evidence, past matches, effect chain, challenger, truth. Each returns { ok, notes }.

export const DIRECTIONS = ['up', 'down', 'yes', 'no'];
const isStr = (s, max = 2000) => typeof s === 'string' && s.trim().length > 0 && s.length <= max;

// ---------- the config: teams, skills, sources and the chair's numbers, all from a file ----------
export function checkConfig(c) {
  const errors = [];
  if (!c || typeof c !== 'object') return ['The council file is not an object'];
  if (c.version !== 1) errors.push('version must be 1');
  const ids = (list, what) => { const s = new Set(); for (const x of list ?? []) { if (!x || !isStr(x.id, 80) || !/^[\w.-]+$/.test(x.id)) errors.push(`${what}: an id is missing or has odd characters`); else if (s.has(x.id)) errors.push(`${what}: ${x.id} appears twice`); else s.add(x.id); } return s; };
  if (!Array.isArray(c.teams) || !c.teams.length) errors.push('teams must be a list with at least one team');
  if (!Array.isArray(c.skills)) errors.push('skills must be a list');
  const teams = ids(c.teams, 'teams'), skills = ids(c.skills, 'skills'), sources = ids(c.sources ?? [], 'sources');
  for (const t of c.teams ?? []) {
    if (!isStr(t?.name, 120)) errors.push(`team ${t?.id}: needs a name`);
    for (const s of t?.skills ?? []) if (!skills.has(s)) errors.push(`team ${t.id}: skill ${s} is not in the skills list`);
    if (t?.weight != null && !(Number(t.weight) > 0)) errors.push(`team ${t.id}: weight must be over 0`);
  }
  for (const s of c.skills ?? []) {
    if (!teams.has(s?.team)) errors.push(`skill ${s?.id}: team ${s?.team} is not in the teams list`);
    if (!isStr(s?.name, 120)) errors.push(`skill ${s?.id}: needs a name`);
    for (const src of s?.sources ?? []) if (!sources.has(src)) errors.push(`skill ${s.id}: source ${src} is not in the sources list`);
    if (s?.runner && !['manual', 'local-model', 'code'].includes(s.runner)) errors.push(`skill ${s.id}: runner must be manual, local-model or code`);
  }
  const ch = c.chair ?? {};
  for (const k of ['startWeight', 'learningRate', 'minWeight', 'maxWeight', 'baseline']) if (!(Number(ch[k]) >= 0)) errors.push(`chair.${k} must be a number`);
  if (Number(ch.minWeight) > Number(ch.maxWeight)) errors.push('chair.minWeight is over chair.maxWeight');
  return errors;
}

// ---------- the shared record ----------
export function checkRecord(r, config) {
  const e = [];
  if (!r || typeof r !== 'object') return ['not a record'];
  const skill = config?.skills?.find((s) => s.id === r.skill);
  if (!skill) e.push(`unknown skill ${r.skill}`);
  else if (skill.team !== r.team) e.push(`skill ${r.skill} belongs to team ${skill.team}, not ${r.team}`);
  if (!isStr(r.question, 500)) e.push('needs a question');
  if (!(Number(r.horizonDays) >= 1 && Number(r.horizonDays) <= 3650)) e.push('horizonDays must be 1 to 3650');
  const p = r.prediction;
  if (!p || !isStr(p.target, 120) || !DIRECTIONS.includes(p.direction) || !(p.probability >= 0 && p.probability <= 1)) e.push('prediction needs a target, a direction (up, down, yes, no) and a probability from 0 to 1');
  if (!Array.isArray(r.reasoning) || !r.reasoning.length || !r.reasoning.every((x) => isStr(x))) e.push('reasoning must be one or more sentences');
  if (!Array.isArray(r.claims)) e.push('claims must be a list');
  return e;
}

// ---------- the shared working skills (interfaces; plug-ins fill them in later) ----------
/** Evidence check: every claim that gives a number must name a registered source and a reference; a number with no source is unsupported. */
export function evidenceCheck(r, config) {
  const known = new Set((config.sources ?? []).map((s) => s.id)), notes = [];
  for (const c of r.claims ?? []) {
    if (c.value != null && !(c.source && known.has(c.source) && c.ref)) notes.push(`"${c.text}": a number with no hard source behind it`);
    if (c.value == null && !c.source) notes.push(`"${c.text}": no evidence given`);
  }
  return { ok: notes.length === 0, notes };
}
/** Past matches: similar past events and what followed. A plug-in finds them; with none, the record's own list is checked for shape. */
export function pastMatches(r, finder) {
  const list = finder ? finder(r) : r.matches ?? [];
  const bad = list.filter((m) => !isStr(m?.event) || !isStr(m?.followed));
  return { ok: list.length > 0 && !bad.length, matches: list, notes: list.length ? bad.map((m) => `a past match is missing what happened or what followed`) : ['no past matches given'] };
}
/** Effect chain: a choice, then its consequence, then the effect on the market, in that order. */
export function effectChain(r) {
  const steps = (r.chain ?? []).map((s) => s?.step), order = ['choice', 'consequence', 'market'];
  const ok = order.every((s) => steps.includes(s)) && order.every((s, i) => i === 0 || steps.lastIndexOf(order[i - 1]) < steps.indexOf(s));
  return { ok, notes: ok ? [] : ['the chain needs a choice, then a consequence, then the market effect, in that order'] };
}
/** Challenger: someone argued against it, and the record answers them. A prediction is not accepted without this. */
export function challenger(r) {
  const c = r.challenge;
  const ok = !!c && Array.isArray(c.against) && c.against.length > 0 && c.against.every((x) => isStr(x)) && isStr(c.answer);
  return { ok, notes: ok ? [] : ['nobody has argued against it yet (or the record does not answer them)'] };
}
/**
 * Truth check: a claim against hard data. sources: { [id]: { fetch(claim) -> { value, ref } } } (plugged in later).
 * Matches when the hard value is within the tolerance of the claim's. Claims with no plugged source say so, honestly.
 */
export async function truthCheck(claim, sources = {}, tol = 0.02) {
  const src = claim?.source && sources[claim.source];
  if (!src) return { status: 'no source yet', claim: claim?.text };
  const hard = await src.fetch(claim);
  if (hard?.value == null || claim.value == null) return { status: 'cannot compare', claim: claim.text, ref: hard?.ref ?? null };
  const off = Math.abs(hard.value - claim.value) / Math.max(1e-9, Math.abs(hard.value));
  return { status: off <= tol ? 'matches' : 'does not match', claim: claim.text, claimed: claim.value, hard: hard.value, ref: hard.ref ?? null };
}
export function runChecks(r, config) {
  return { evidence: evidenceCheck(r, config), pastMatches: pastMatches(r), effectChain: effectChain(r), challenger: challenger(r) };
}
/** Accepted for the locker only with every shared check passed */
export const accepted = (checks) => Object.values(checks).every((c) => c.ok);

// ---------- the team lead and the chair ----------
/** A team lead merges its skills' accepted records on one question into one probability (weighted by each skill's weight). */
export function teamLead(records, skillWeights = {}) {
  if (!records.length) return null;
  const toYes = (r) => (['up', 'yes'].includes(r.prediction.direction) ? r.prediction.probability : 1 - r.prediction.probability);
  let w = 0, p = 0;
  for (const r of records) { const k = skillWeights[r.skill] ?? 1; w += k; p += k * toYes(r); }
  return { probability: p / w, from: records.map((r) => r.skill) };
}
/** The chair weighs each team by its track record and gives the council's probability (that the target goes up / happens). */
export function chair(teamViews, weights, cfg) {
  const list = Object.entries(teamViews).filter(([, v]) => v);
  if (!list.length) return null;
  let w = 0, p = 0;
  for (const [team, v] of list) { const k = weights[team] ?? cfg.startWeight; w += k; p += k * v.probability; }
  return { probability: p / w, teams: list.map(([t, v]) => ({ team: t, probability: v.probability, weight: weights[t] ?? cfg.startWeight })) };
}

// ---------- the scorer ----------
/**
 * Scores a locked prediction against what happened. outcome: { happened: boolean, checkedClaims: [{ id, status }] }.
 * calibration: 1 - Brier score (1 is perfect, 0.75 is a coin flip); reasoning: the share of its claims the truth check
 * later confirmed; total: the two averaged. Being right for the wrong reasons scores less than being right for the right ones.
 */
export function score(pred, outcome) {
  const p = ['up', 'yes'].includes(pred.prediction.direction) ? pred.prediction.probability : 1 - pred.prediction.probability;
  const y = outcome.happened ? 1 : 0;
  const calibration = 1 - (p - y) ** 2;
  const checked = (outcome.checkedClaims ?? []).filter((c) => ['matches', 'does not match'].includes(c.status));
  const reasoning = checked.length ? checked.filter((c) => c.status === 'matches').length / checked.length : null;
  const total = reasoning == null ? calibration : (calibration + reasoning) / 2;
  return { right: (p >= 0.5) === (y === 1), calibration, reasoning, total };
}
/** A team's weight after a score: up when it beats the baseline (0.75 is what always saying 50% would score), down when it does not, kept inside the chair's limits */
export function newWeight(w, total, cfg) {
  return Math.min(cfg.maxWeight, Math.max(cfg.minWeight, w * Math.exp(cfg.learningRate * (total - cfg.baseline) * 2)));
}
