// Trading > Bots (Trading UI prompt v6, slice 1), the server's part: which bots there are, the filled orders the app
// makes trades from, the live status line, and what the control panel may change. Pure functions: no broker, no orders.
// Tested in server/test/trading-bots.test.mjs.
//
// A "bot" is what the code already treats as a running paper strategy: the code's own strategy (the moving-average
// crossover), and the Claude bot when it passes those signals on. Orders you place yourself are "By hand". Stop-loss
// and over-budget sells belong to whichever bot opened the shares they sell.

const r2 = (v) => Math.round(v * 100) / 100;

/** The bot an order belongs to (null for sells that inherit the bot of the shares they close) */
export const botOfSource = (source) => (source === 'code' ? 'code' : source === 'claude' ? 'claude' : source === 'you' || source === 'ai' ? 'you' : null);
export function botsFor(settings) {
  return [
    { id: 'code', name: `Crossover ${settings.strategy?.fast ?? 20}/${settings.strategy?.slow ?? 50}`, colour: 'var(--sec-gold)', running: settings.pipeline === 'code', kind: 'The code\'s own strategy, on daily prices' },
    { id: 'claude', name: 'Claude bot', colour: 'var(--sec-sky)', running: settings.pipeline === 'claude', kind: 'Passes on the code\'s signals, with reasons' },
    { id: 'you', name: 'By hand', colour: 'var(--sec-violet)', running: false, kind: 'Trades you proposed yourself' }
  ];
}

/** Queue items that have filled, as fills (oldest first) */
export function fillsOf(queue) {
  return queue.filter((q) => q.status === 'placed' && q.fill && q.fill.qty > 0 && q.fill.price > 0)
    .map((q) => ({ id: q.id, symbol: q.symbol, side: q.side, qty: q.fill.qty, price: q.fill.price, at: q.fill.at ?? q.placedAt ?? q.at, bot: botOfSource(q.source), source: q.source, why: q.why || '' }))
    .sort((a, b) => a.at - b.at);
}

// The trade maths (pairing, stats, days, the calendar) lives in the app (apps/trading/src/lib/bots.ts), so the demo's
// made-up sample goes through the same code as real fills.

// ---------------- The control panel: only these settings, and only through the existing rules ----------------
/** Risk levels are presets of limits that already exist (risk per trade and the most in one stock) */
export const RISK_LEVELS = { low: { riskPerTradePct: 0.5, maxPositionPct: 10 }, medium: { riskPerTradePct: 1, maxPositionPct: 20 }, high: { riskPerTradePct: 2, maxPositionPct: 30 } };
export const riskLevelOf = (L) => Object.entries(RISK_LEVELS).find(([, v]) => v.riskPerTradePct === L.riskPerTradePct && v.maxPositionPct === L.maxPositionPct)?.[0] ?? 'custom';
/** What the panel may change. Nothing else is ever read from a control request: not the floor, the kill switch, cash-only, the mode or the symbols. */
export const CONTROL_KEYS = ['auto', 'stopPct', 'dailyLossPct', 'riskLevel'];

/**
 * One control change -> the settings body for the existing settings route (which keeps all its own checks), what it
 * will do in words, and the body that undoes it. Returns { error } for anything not allowed.
 */
export function controlChange(settings, change) {
  const keys = Object.keys(change ?? {});
  if (keys.length !== 1 || !CONTROL_KEYS.includes(keys[0])) return { error: 'The control panel can only change automatic trading, the stop loss, the daily loss limit or the risk level' };
  const [k] = keys, v = change[k], L = settings.limits;
  if (k === 'auto') {
    if (typeof v !== 'boolean') return { error: 'Automatic is on or off' };
    return { body: { auto: v }, undo: { auto: settings.auto }, says: v ? 'Trades the bot suggests go straight to the broker, still checked by every limit (paper only)' : 'Every trade waits for your approval again' };
  }
  if (k === 'riskLevel') {
    const p = RISK_LEVELS[v];
    if (!p) return { error: 'Choose Low, Medium or High' };
    return { body: { limits: { ...p } }, undo: { limits: { riskPerTradePct: L.riskPerTradePct, maxPositionPct: L.maxPositionPct } },
      says: `Each trade may lose at most ${p.riskPerTradePct}% of the account at its stop (now ${L.riskPerTradePct}%), and one stock at most ${p.maxPositionPct}% of it (now ${L.maxPositionPct}%)` };
  }
  const n = Number(v);
  if (k === 'stopPct') {
    if (!(n >= 0.5 && n <= 25)) return { error: 'The stop loss is between 0.5% and 25% (it can never be switched off)' };
    return { body: { limits: { stopPct: n } }, undo: { limits: { stopPct: L.stopPct } }, says: `New buys sell by themselves if they fall ${n}% below the buy price (now ${L.stopPct}%)` };
  }
  if (!(n >= 0.5 && n <= 20)) return { error: 'The daily loss limit is between 0.5% and 20%' };
  return { body: { limits: { dailyLossPct: n } }, undo: { limits: { dailyLossPct: L.dailyLossPct } }, says: `No more buys on a day the account falls ${n}% (now ${L.dailyLossPct}%)` };
}

/** The live status line, from real state only */
export function statusLine(v, { open = null } = {}) {
  if (!v.connected?.paper && !v.connected?.live) return 'Not connected to a broker';
  if (v.killed) return 'Stopped by the kill switch';
  if (v.locked) return 'Locked at your protected floor';
  if (v.dailyStopHit) return 'Halted by the daily stop: no more buys today';
  if (v.limits?.floor == null) return 'Waiting for your protected floor (Safety)';
  const waiting = (v.queue ?? []).filter((q) => q.status === 'waiting').length;
  if (waiting) return `Waiting for your approval (${waiting})`;
  if (open === false) return 'Market closed';
  const held = (v.positions ?? []).filter((p) => p.qty > 0).map((p) => p.symbol);
  const up = (v.signals ?? []).filter((s) => s.trend === 'up').map((s) => s.symbol);
  if (held.length) return `Holding ${held.join(', ')}${up.some((s) => held.includes(s)) ? ': trend still up' : ''}`;
  if (!v.signals?.length) return 'Scanning: no signals worked out yet today';
  return up.length ? `Scanning: trend up on ${up.join(', ')}, waiting for a crossing` : 'Scanning: every trend is down, waiting';
}

/** The filters the running strategy really has, read from its spec (shown read-only) */
export function strategyFilters(strategy) {
  return [
    { id: 'trend', label: 'Trend filter', on: true, says: `Buys only when the ${strategy.fast}-day average is above the ${strategy.slow}-day one` },
    { id: 'chop', label: 'Chop filter', on: false, says: 'The running strategy has none' },
    { id: 'style', label: 'Style', on: true, says: 'Trend, on daily prices (scalping needs minute prices and a strategy that doesn\'t exist yet)' }
  ];
}
