const VERSION = "0.30.0+2026-11-27T04:23:25.802Z";
const FILES = ["./","index.html","assets/fredoka-hebrew-500-normal-C-43HJEL.woff2","assets/fredoka-latin-500-normal-BpYxueJ9.woff2","assets/fredoka-hebrew-500-normal-BkmgaUC6.woff","assets/fredoka-latin-500-normal-CFGu1_I7.woff","assets/App--STTBmYl.css","assets/App-DYGVn_li.css","assets/App-CFF_l0it.css","assets/App-CIR369Tk.css","assets/App-DG0ePsJ1.css","assets/App-BH42PcOY.css","assets/App-BAw3tUlP.css","assets/App-BBGS-z0R.css","assets/Root-BcZusuxK.css","assets/App-C-7Vd7vn.css","assets/index-B-9XXIae.css","assets/index-1U05ovq-.js","assets/sample-DMmI6SIJ.js","assets/index-B5GlYHmH.js","assets/Spinner-CDXcrB0q.js","assets/CountUp-BwS1rNBT.js","assets/clone-c7Mn_h4r.js","assets/SettingsGroup-CtxisWM-.js","assets/EmptyState-BqGFB45h.js","assets/keepScroll-ovc76FGC.js","assets/web-COlVCeDC.js","assets/index-DMeSw7Qh.js","assets/MilestoneBar-BJwPZtiT.js","assets/model-deM3NNVM.js","assets/legacy-Cbf-6Wfh.js","assets/StatTile-DKCHQIti.js","assets/Shimmer-C1H4_sM-.js","assets/App-DjVg1_Xn.js","assets/App-Cv7Pq0iF.js","assets/App-DgR18ujf.js","assets/App-DA1alr3a.js","assets/App-Bhl4a6w0.js","assets/App-BL8oTmuB.js","assets/rfb-CxsXsMUX.js","assets/App-9DDBaMaf.js","assets/App-BFjQkkz4.js","assets/Root-BFoyFrDs.js","assets/App-CD3IjGCp.js","assets/index-B7qCKK28.js","assets/index-YJtorASr.js","apple-touch-icon.png","icon.svg","manifest.webmanifest"];
// Hub's service worker, for the web Hub (mainly the iPhone Home Screen app). Browsers only run it on https (the
// outside link) or on the PC itself, never on the plain home address.
//  - Keeps a copy of the app, so Hub opens with your last saved data while the PC is off or out of reach.
//    The page is fetched fresh whenever the server answers, so updates arrive as usual; the copy is the fallback.
//  - Shows notifications pushed by your server (Web Push), and opens the right page when one is tapped.
// The build (vite.config.ts) writes VERSION and FILES (every file of this version) above this line.
const CACHE = `hub-${VERSION}`;
const at = (f) => new URL(f, self.registration.scope).href;
const PAGE = at('./');
// Never from the copy: your data and sign-in (/api), updates, downloads and the version check
const LIVE = /\/(api|updates|phone)(\/|$)|\/(version\.json|sw\.js)$/;
const SLOW_MS = 5000;

self.addEventListener('install', (e) => {
  self.skipWaiting();
  // One missing file must not stop the rest, so each is added on its own
  e.waitUntil(caches.open(CACHE).then((c) => Promise.allSettled(FILES.map((f) => c.add(new Request(at(f), { cache: 'reload' }))))));
});

self.addEventListener('activate', (e) => e.waitUntil((async () => {
  for (const k of await caches.keys()) if (k.startsWith('hub-') && k !== CACHE) await caches.delete(k);
  await self.clients.claim();
})()));

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (!FILES.length || req.method !== 'GET') return; // the dev server's worker keeps nothing
  const url = new URL(req.url);
  if (url.origin !== self.location.origin || LIVE.test(url.pathname)) return;
  if (req.mode === 'navigate') {
    const fresh = fetch(req).then(async (res) => {
      if (res.ok && !res.redirected) await (await caches.open(CACHE)).put(PAGE, res.clone());
      return res;
    });
    e.waitUntil(fresh.then(() => {}, () => {})); // the fresh page still replaces the copy if it comes late
    e.respondWith(page(fresh));
  } else {
    e.respondWith(file(req));
  }
});

// The page: fresh from the server if it answers within a few seconds, otherwise the copy
async function page(fresh) {
  const copy = () => caches.open(CACHE).then((c) => c.match(PAGE));
  try {
    const res = await Promise.race([fresh, new Promise((_, no) => setTimeout(() => no(new Error('slow')), SLOW_MS))]);
    if (res.ok) return res;
    return (await copy()) || res; // the PC is off: Tailscale answers with an error page
  } catch {
    return (await copy()) || fresh.catch(() => Response.error());
  }
}

// The app's files (their names change with every version): the copy first, else the server (and keep it)
async function file(req) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res.ok && res.type === 'basic') await cache.put(req, res.clone());
  return res;
}

self.addEventListener('push', (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch { d = { body: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.title || 'Hub', {
    body: d.body || '',
    tag: d.tag || undefined,
    icon: 'apple-touch-icon.png',
    badge: 'icon.svg',
    data: { route: d.route || '' }
  }));
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const route = (e.notification.data && e.notification.data.route) || '';
  const url = new URL(route ? `./#/${route}` : './', self.registration.scope).href;
  e.waitUntil((async () => {
    const list = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of list) {
      if ('focus' in c) { if (route && 'navigate' in c) await c.navigate(url).catch(() => {}); return c.focus(); }
    }
    return self.clients.openWindow(url);
  })());
});
